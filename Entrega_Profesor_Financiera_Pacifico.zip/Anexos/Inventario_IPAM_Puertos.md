# Inventario, IPAM y puertos — C5 A/B

Corte 24-10-2026, revisión WAN-2. Tablas de las fichas JSON que usa el simulador. Las reservas Wi-Fi se activan al elegir ese camino. Los nombres de puertos son la especificación educativa, con roles de fabricante donde corresponde.

## Alternativa A

### CM — Santiago Centro

55 PCs y 55 teléfonos existentes.

| Función | ANTES | DESPUÉS |
| --- | --- | --- |
| Routers | 2 × CISCO2911-SEC/K9 | Routing en el par de firewalls |
| Switches | 2 × C9200L-48P-4X-E | C9200L-48P-4X-E + C9200L-48P-4X-E |
| Firewall | 1 × ASA5512-K9 | 2 × PAN-PA-1410 |
| Distribución WAN | MPLS y accesos ISP del escenario base | wanA: CRS310-8G+2S+IN; wanB: E50UG |


| Red | VLAN | Subred | Gateway / roles |
| --- | --- | --- | --- |
| users | 10 | 10.70.0.0/25 | 10.70.0.1 |
| voice | 20 | 10.70.64.0/25 | 10.70.64.1 |
| guests | 40 | 10.70.96.0/26 | 10.70.96.1 |
| wifi_users | 110 | 10.81.0.0/25 | 10.81.0.1 |
| wifi_voice | 120 | 10.82.0.0/25 | 10.82.0.1 |
| management | 130 | 10.80.0.0/27 | 10.80.0.1 |
| servers | 50 | 10.70.200.0/24 | 10.70.200.1 |
| firewall_transit | 131 | 172.31.0.0/29 | stack: 172.31.0.1; ha_firewall: 172.31.0.2 |


| Gestión | Dirección |
| --- | --- |
| sw1 | 10.80.0.1 |
| sw2 | 10.80.0.1 |
| fwA | 10.80.0.2 |
| fwB | 10.80.0.3 |
| wanA | 10.80.0.6 |
| wanB | 10.80.0.7 |
| ap1 | 10.80.0.24 |
| ap2 | 10.80.0.25 |
| ap3 | 10.80.0.26 |
| ap4 | 10.80.0.27 |


| Origen | Puerto | Destino | Puerto | Función | VLAN/red | Mbps | IP / agregado lógico |
| --- | --- | --- | --- | --- | --- | --- | --- |
| cpe:starlink | LAN_2_5G_REQUIRED | wanA | ether1 | WAN_ACCESS | 201 | 2500 | — |
| cpe:leo | LAN_1G_REQUIRED | wanB | ether1 | WAN_ACCESS | 202 | 1000 | — |
| fwA | ethernet1/9 | wanA | ether2 | WAN_ACCESS | 201 | 2500 | — |
| fwA | ethernet1/1 | wanB | ether2 | WAN_ACCESS | 202 | 1000 | — |
| fwA | ethernet1/19 | sw1 | Te1/1/1 | LAN_AGGREGATE | 50, 131 | 10000 | port_channel: Po21; firewall_aggregate: ae1 |
| fwA | ethernet1/20 | sw2 | Te2/1/1 | LAN_AGGREGATE | 50, 131 | 10000 | port_channel: Po21; firewall_aggregate: ae1 |
| fwA | MGT | sw1 | Gi1/0/41 | MANAGEMENT_ACCESS | 130 | 1000 | — |
| fwB | ethernet1/9 | wanA | ether3 | WAN_ACCESS | 201 | 2500 | — |
| fwB | ethernet1/1 | wanB | ether3 | WAN_ACCESS | 202 | 1000 | — |
| fwB | ethernet1/19 | sw1 | Te1/1/2 | LAN_AGGREGATE | 50, 131 | 10000 | port_channel: Po22; firewall_aggregate: ae1 |
| fwB | ethernet1/20 | sw2 | Te2/1/2 | LAN_AGGREGATE | 50, 131 | 10000 | port_channel: Po22; firewall_aggregate: ae1 |
| fwB | MGT | sw2 | Gi2/0/41 | MANAGEMENT_ACCESS | 130 | 1000 | — |
| fwA | HA1-A | fwB | HA1-A | HA1 | — | 1000 | — |
| fwA | HA1-B | fwB | HA1-B | HA1_BACKUP | — | 1000 | — |
| fwA | HSCI | fwB | HSCI | HA2 | — | 10000 | — |
| fwA | ethernet1/8 | fwB | ethernet1/8 | HA2_BACKUP | — | 1000 | — |
| wanA | ether4 | sw1 | Gi1/0/42 | MANAGEMENT_ACCESS | 130 | 1000 | — |
| ap1 | LAN | sw1 | Gi1/0/47 | AP_TRUNK | 40, 110, 120, 130 | 1000 | — |
| ap2 | LAN | sw1 | Gi1/0/48 | AP_TRUNK | 40, 110, 120, 130 | 1000 | — |
| wanB | ether4 | sw2 | Gi2/0/42 | MANAGEMENT_ACCESS | 130 | 1000 | — |
| ap3 | LAN | sw2 | Gi2/0/47 | AP_TRUNK | 40, 110, 120, 130 | 1000 | — |
| ap4 | LAN | sw2 | Gi2/0/48 | AP_TRUNK | 40, 110, 120, 130 | 1000 | — |
| dc1 | NIC1 | sw1 | Gi1/0/43 | SERVER_TRUNK | 50, 130 | 1000 | — |
| dc1 | NIC2 | sw2 | Gi2/0/43 | SERVER_TRUNK | 50, 130 | 1000 | — |
| dc2 | NIC1 | sw1 | Gi1/0/44 | SERVER_TRUNK | 50, 130 | 1000 | — |
| dc2 | NIC2 | sw2 | Gi2/0/44 | SERVER_TRUNK | 50, 130 | 1000 | — |
| backup | NIC1 | sw1 | Gi1/0/45 | SERVER_ACCESS | 50 | 1000 | — |
| backup | NIC2 | sw2 | Gi2/0/45 | SERVER_ACCESS | 50 | 1000 | — |
| sw1 | Stack1 | sw2 | Stack2 | STACK | — | 80000 | — |
| sw1 | Stack2 | sw2 | Stack1 | STACK | — | 80000 | — |


| Puesto | Switch | Puerto | IP PC | IP teléfono | Reserva Wi-Fi PC | Reserva Wi-Fi voz |
| --- | --- | --- | --- | --- | --- | --- |
| cm-pc01 | 1 | 1 | 10.70.0.10 | 10.70.64.10 | 10.81.0.10 | 10.82.0.10 |
| cm-pc02 | 2 | 1 | 10.70.0.11 | 10.70.64.11 | 10.81.0.11 | 10.82.0.11 |
| cm-pc03 | 1 | 2 | 10.70.0.12 | 10.70.64.12 | 10.81.0.12 | 10.82.0.12 |
| cm-pc04 | 2 | 2 | 10.70.0.13 | 10.70.64.13 | 10.81.0.13 | 10.82.0.13 |
| cm-pc05 | 1 | 3 | 10.70.0.14 | 10.70.64.14 | 10.81.0.14 | 10.82.0.14 |
| cm-pc06 | 2 | 3 | 10.70.0.15 | 10.70.64.15 | 10.81.0.15 | 10.82.0.15 |
| cm-pc07 | 1 | 4 | 10.70.0.16 | 10.70.64.16 | 10.81.0.16 | 10.82.0.16 |
| cm-pc08 | 2 | 4 | 10.70.0.17 | 10.70.64.17 | 10.81.0.17 | 10.82.0.17 |
| cm-pc09 | 1 | 5 | 10.70.0.18 | 10.70.64.18 | 10.81.0.18 | 10.82.0.18 |
| cm-pc10 | 2 | 5 | 10.70.0.19 | 10.70.64.19 | 10.81.0.19 | 10.82.0.19 |
| cm-pc11 | 1 | 6 | 10.70.0.20 | 10.70.64.20 | 10.81.0.20 | 10.82.0.20 |
| cm-pc12 | 2 | 6 | 10.70.0.21 | 10.70.64.21 | 10.81.0.21 | 10.82.0.21 |
| cm-pc13 | 1 | 7 | 10.70.0.22 | 10.70.64.22 | 10.81.0.22 | 10.82.0.22 |
| cm-pc14 | 2 | 7 | 10.70.0.23 | 10.70.64.23 | 10.81.0.23 | 10.82.0.23 |
| cm-pc15 | 1 | 8 | 10.70.0.24 | 10.70.64.24 | 10.81.0.24 | 10.82.0.24 |
| cm-pc16 | 2 | 8 | 10.70.0.25 | 10.70.64.25 | 10.81.0.25 | 10.82.0.25 |
| cm-pc17 | 1 | 9 | 10.70.0.26 | 10.70.64.26 | 10.81.0.26 | 10.82.0.26 |
| cm-pc18 | 2 | 9 | 10.70.0.27 | 10.70.64.27 | 10.81.0.27 | 10.82.0.27 |
| cm-pc19 | 1 | 10 | 10.70.0.28 | 10.70.64.28 | 10.81.0.28 | 10.82.0.28 |
| cm-pc20 | 2 | 10 | 10.70.0.29 | 10.70.64.29 | 10.81.0.29 | 10.82.0.29 |
| cm-pc21 | 1 | 11 | 10.70.0.30 | 10.70.64.30 | 10.81.0.30 | 10.82.0.30 |
| cm-pc22 | 2 | 11 | 10.70.0.31 | 10.70.64.31 | 10.81.0.31 | 10.82.0.31 |
| cm-pc23 | 1 | 12 | 10.70.0.32 | 10.70.64.32 | 10.81.0.32 | 10.82.0.32 |
| cm-pc24 | 2 | 12 | 10.70.0.33 | 10.70.64.33 | 10.81.0.33 | 10.82.0.33 |
| cm-pc25 | 1 | 13 | 10.70.0.34 | 10.70.64.34 | 10.81.0.34 | 10.82.0.34 |
| cm-pc26 | 2 | 13 | 10.70.0.35 | 10.70.64.35 | 10.81.0.35 | 10.82.0.35 |
| cm-pc27 | 1 | 14 | 10.70.0.36 | 10.70.64.36 | 10.81.0.36 | 10.82.0.36 |
| cm-pc28 | 2 | 14 | 10.70.0.37 | 10.70.64.37 | 10.81.0.37 | 10.82.0.37 |
| cm-pc29 | 1 | 15 | 10.70.0.38 | 10.70.64.38 | 10.81.0.38 | 10.82.0.38 |
| cm-pc30 | 2 | 15 | 10.70.0.39 | 10.70.64.39 | 10.81.0.39 | 10.82.0.39 |
| cm-pc31 | 1 | 16 | 10.70.0.40 | 10.70.64.40 | 10.81.0.40 | 10.82.0.40 |
| cm-pc32 | 2 | 16 | 10.70.0.41 | 10.70.64.41 | 10.81.0.41 | 10.82.0.41 |
| cm-pc33 | 1 | 17 | 10.70.0.42 | 10.70.64.42 | 10.81.0.42 | 10.82.0.42 |
| cm-pc34 | 2 | 17 | 10.70.0.43 | 10.70.64.43 | 10.81.0.43 | 10.82.0.43 |
| cm-pc35 | 1 | 18 | 10.70.0.44 | 10.70.64.44 | 10.81.0.44 | 10.82.0.44 |
| cm-pc36 | 2 | 18 | 10.70.0.45 | 10.70.64.45 | 10.81.0.45 | 10.82.0.45 |
| cm-pc37 | 1 | 19 | 10.70.0.46 | 10.70.64.46 | 10.81.0.46 | 10.82.0.46 |
| cm-pc38 | 2 | 19 | 10.70.0.47 | 10.70.64.47 | 10.81.0.47 | 10.82.0.47 |
| cm-pc39 | 1 | 20 | 10.70.0.48 | 10.70.64.48 | 10.81.0.48 | 10.82.0.48 |
| cm-pc40 | 2 | 20 | 10.70.0.49 | 10.70.64.49 | 10.81.0.49 | 10.82.0.49 |
| cm-pc41 | 1 | 21 | 10.70.0.50 | 10.70.64.50 | 10.81.0.50 | 10.82.0.50 |
| cm-pc42 | 2 | 21 | 10.70.0.51 | 10.70.64.51 | 10.81.0.51 | 10.82.0.51 |
| cm-pc43 | 1 | 22 | 10.70.0.52 | 10.70.64.52 | 10.81.0.52 | 10.82.0.52 |
| cm-pc44 | 2 | 22 | 10.70.0.53 | 10.70.64.53 | 10.81.0.53 | 10.82.0.53 |
| cm-pc45 | 1 | 23 | 10.70.0.54 | 10.70.64.54 | 10.81.0.54 | 10.82.0.54 |
| cm-pc46 | 2 | 23 | 10.70.0.55 | 10.70.64.55 | 10.81.0.55 | 10.82.0.55 |
| cm-pc47 | 1 | 24 | 10.70.0.56 | 10.70.64.56 | 10.81.0.56 | 10.82.0.56 |
| cm-pc48 | 2 | 24 | 10.70.0.57 | 10.70.64.57 | 10.81.0.57 | 10.82.0.57 |
| cm-pc49 | 1 | 25 | 10.70.0.58 | 10.70.64.58 | 10.81.0.58 | 10.82.0.58 |
| cm-pc50 | 2 | 25 | 10.70.0.59 | 10.70.64.59 | 10.81.0.59 | 10.82.0.59 |
| cm-pc51 | 1 | 26 | 10.70.0.60 | 10.70.64.60 | 10.81.0.60 | 10.82.0.60 |
| cm-pc52 | 2 | 26 | 10.70.0.61 | 10.70.64.61 | 10.81.0.61 | 10.82.0.61 |
| cm-pc53 | 1 | 27 | 10.70.0.62 | 10.70.64.62 | 10.81.0.62 | 10.82.0.62 |
| cm-pc54 | 2 | 27 | 10.70.0.63 | 10.70.64.63 | 10.81.0.63 | 10.82.0.63 |
| cm-pc55 | 1 | 28 | 10.70.0.64 | 10.70.64.64 | 10.81.0.64 | 10.82.0.64 |


**Transporte starlink — VLAN 201 — wanA.**

| Rol de entrega | Dirección |
| --- | --- |
| network | 198.51.100.0/29 |
| cpe | 198.51.100.1 |
| fwA | 198.51.100.2 |
| fwB | 198.51.100.3 |
| vip | 198.51.100.4 |


**Transporte leo — VLAN 202 — wanB.**

| Rol de entrega | Dirección |
| --- | --- |
| network | 203.0.113.0/29 |
| cpe | 203.0.113.1 |
| fwA | 203.0.113.2 |
| fwB | 203.0.113.3 |
| vip | 203.0.113.4 |


| Servidor | Modelo | Gestión | RAM ANTES → DESPUÉS GiB | Útil ANTES → DESPUÉS GB |
| --- | --- | --- | --- | --- |
| DC-01 | Dell PowerEdge R740 | 10.80.0.11 | 64 → 64 | 2000 → 2000 |
| DC-02 | Dell PowerEdge R740 | 10.80.0.12 | 32 → 64 | 1000 → 3840 |
| BKP-01 | Dell PowerEdge R540 | 10.70.200.50 | 16 → 16 | 8000 → 8000 |


| Host normal | Servicio | IP | Puerto |
| --- | --- | --- | --- |
| DC-01 | Aplicación HTTPS | 10.70.200.10 | TCP 443 |
| DC-01 | PostgreSQL | 10.70.200.11 | TCP 5432 |
| DC-02 | PBX | 10.70.200.20 | TCP 5061 / UDP 10000–20000 |
| DC-02 | DNS / NTP | 10.70.200.30 | TCP/UDP 53 / UDP 123 |
| DC-02 | AAA / RADIUS / TACACS+ | 10.70.200.31 | UDP 1812–1813 / TCP 49 |
| DC-02 | NMS / registros | 10.70.200.40 | UDP 161 / TCP 6514 |
| DC-02 | Bastión NOC | 10.80.0.10 | TCP 22 / 443 |
| BKP-01 | Repositorio | 10.70.200.50 | Acceso restringido a los hosts de respaldo |

### S01 — Providencia

30 PCs y 30 teléfonos existentes.

| Función | ANTES | DESPUÉS |
| --- | --- | --- |
| Routers | 1 × CISCO1921-SEC/K9 | 2 × C1121X-8P |
| Switches | 1 × WS-C2960S-48LPS-L | C9200L-24P-4G-E + C9200L-24P-4G-E |
| Firewall | Sin equipo dedicado | Sin appliance remoto; seguridad central |
| Distribución WAN | MPLS y accesos ISP del escenario base | wanA: E50UG; wanB: E50UG |


| Red | VLAN | Subred | Gateway / roles |
| --- | --- | --- | --- |
| users | 10 | 10.70.1.0/25 | 10.70.1.1 |
| voice | 20 | 10.70.65.0/25 | 10.70.65.1 |
| guests | 40 | 10.70.97.0/26 | 10.70.97.1 |
| wifi_users | 110 | 10.81.1.0/25 | 10.81.1.1 |
| wifi_voice | 120 | 10.82.1.0/25 | 10.82.1.1 |
| management | 130 | 10.80.1.0/27 | 10.80.1.1 |


| Gestión | Dirección |
| --- | --- |
| sw1 | 10.80.1.1 |
| sw2 | 10.80.1.1 |
| r1 | 10.80.1.2 |
| r2 | 10.80.1.3 |
| wanA | 10.80.1.6 |
| wanB | 10.80.1.7 |
| ap1 | 10.80.1.24 |
| ap2 | 10.80.1.25 |


| Origen | Puerto | Destino | Puerto | Función | VLAN/red | Mbps | IP / agregado lógico |
| --- | --- | --- | --- | --- | --- | --- | --- |
| cpe:starlink | LAN | wanA | ether1 | WAN_ACCESS | 201 | 1000 | — |
| cpe:entel5g | LAN | wanA | ether2 | WAN_ACCESS | 203 | 1000 | — |
| r1 | GigabitEthernet0/0/0 | wanA | ether3 | WAN_TRUNK | 201, 203 | 1000 | — |
| r2 | GigabitEthernet0/0/0 | wanA | ether4 | WAN_TRUNK | 201, 203 | 1000 | — |
| wanA | ether5 | sw1 | Gi1/0/22 | MANAGEMENT_ACCESS | 130 | 1000 | — |
| cpe:leo | LAN | wanB | ether1 | WAN_ACCESS | 202 | 1000 | — |
| cpe:wom4g | LAN | wanB | ether2 | WAN_ACCESS | 204 | 1000 | — |
| r1 | GigabitEthernet0/0/1 | wanB | ether3 | WAN_TRUNK | 202, 204 | 1000 | — |
| r2 | GigabitEthernet0/0/1 | wanB | ether4 | WAN_TRUNK | 202, 204 | 1000 | — |
| wanB | ether5 | sw2 | Gi2/0/22 | MANAGEMENT_ACCESS | 130 | 1000 | — |
| r1 | GigabitEthernet0/1/0 | sw1 | Gi1/0/19 | LAN_ROUTED | 172.31.1.0/30 | 1000 | router_ip: 172.31.1.1; stack_ip: 172.31.1.2 |
| r1 | GigabitEthernet0/1/1 | sw2 | Gi2/0/19 | LAN_ROUTED | 172.31.1.4/30 | 1000 | router_ip: 172.31.1.5; stack_ip: 172.31.1.6 |
| r1 | GigabitEthernet0/1/2 | sw1 | Gi1/0/21 | MANAGEMENT_ACCESS | 130 | 1000 | — |
| r2 | GigabitEthernet0/1/0 | sw1 | Gi1/0/20 | LAN_ROUTED | 172.31.1.8/30 | 1000 | router_ip: 172.31.1.9; stack_ip: 172.31.1.10 |
| r2 | GigabitEthernet0/1/1 | sw2 | Gi2/0/20 | LAN_ROUTED | 172.31.1.12/30 | 1000 | router_ip: 172.31.1.13; stack_ip: 172.31.1.14 |
| r2 | GigabitEthernet0/1/2 | sw2 | Gi2/0/21 | MANAGEMENT_ACCESS | 130 | 1000 | — |
| ap1 | LAN | sw1 | Gi1/0/24 | AP_TRUNK | 40, 110, 120, 130 | 1000 | — |
| ap2 | LAN | sw2 | Gi2/0/24 | AP_TRUNK | 40, 110, 120, 130 | 1000 | — |
| sw1 | Stack1 | sw2 | Stack2 | STACK | — | 80000 | — |
| sw1 | Stack2 | sw2 | Stack1 | STACK | — | 80000 | — |


| Puesto | Switch | Puerto | IP PC | IP teléfono | Reserva Wi-Fi PC | Reserva Wi-Fi voz |
| --- | --- | --- | --- | --- | --- | --- |
| s01-pc01 | 1 | 1 | 10.70.1.10 | 10.70.65.10 | 10.81.1.10 | 10.82.1.10 |
| s01-pc02 | 2 | 1 | 10.70.1.11 | 10.70.65.11 | 10.81.1.11 | 10.82.1.11 |
| s01-pc03 | 1 | 2 | 10.70.1.12 | 10.70.65.12 | 10.81.1.12 | 10.82.1.12 |
| s01-pc04 | 2 | 2 | 10.70.1.13 | 10.70.65.13 | 10.81.1.13 | 10.82.1.13 |
| s01-pc05 | 1 | 3 | 10.70.1.14 | 10.70.65.14 | 10.81.1.14 | 10.82.1.14 |
| s01-pc06 | 2 | 3 | 10.70.1.15 | 10.70.65.15 | 10.81.1.15 | 10.82.1.15 |
| s01-pc07 | 1 | 4 | 10.70.1.16 | 10.70.65.16 | 10.81.1.16 | 10.82.1.16 |
| s01-pc08 | 2 | 4 | 10.70.1.17 | 10.70.65.17 | 10.81.1.17 | 10.82.1.17 |
| s01-pc09 | 1 | 5 | 10.70.1.18 | 10.70.65.18 | 10.81.1.18 | 10.82.1.18 |
| s01-pc10 | 2 | 5 | 10.70.1.19 | 10.70.65.19 | 10.81.1.19 | 10.82.1.19 |
| s01-pc11 | 1 | 6 | 10.70.1.20 | 10.70.65.20 | 10.81.1.20 | 10.82.1.20 |
| s01-pc12 | 2 | 6 | 10.70.1.21 | 10.70.65.21 | 10.81.1.21 | 10.82.1.21 |
| s01-pc13 | 1 | 7 | 10.70.1.22 | 10.70.65.22 | 10.81.1.22 | 10.82.1.22 |
| s01-pc14 | 2 | 7 | 10.70.1.23 | 10.70.65.23 | 10.81.1.23 | 10.82.1.23 |
| s01-pc15 | 1 | 8 | 10.70.1.24 | 10.70.65.24 | 10.81.1.24 | 10.82.1.24 |
| s01-pc16 | 2 | 8 | 10.70.1.25 | 10.70.65.25 | 10.81.1.25 | 10.82.1.25 |
| s01-pc17 | 1 | 9 | 10.70.1.26 | 10.70.65.26 | 10.81.1.26 | 10.82.1.26 |
| s01-pc18 | 2 | 9 | 10.70.1.27 | 10.70.65.27 | 10.81.1.27 | 10.82.1.27 |
| s01-pc19 | 1 | 10 | 10.70.1.28 | 10.70.65.28 | 10.81.1.28 | 10.82.1.28 |
| s01-pc20 | 2 | 10 | 10.70.1.29 | 10.70.65.29 | 10.81.1.29 | 10.82.1.29 |
| s01-pc21 | 1 | 11 | 10.70.1.30 | 10.70.65.30 | 10.81.1.30 | 10.82.1.30 |
| s01-pc22 | 2 | 11 | 10.70.1.31 | 10.70.65.31 | 10.81.1.31 | 10.82.1.31 |
| s01-pc23 | 1 | 12 | 10.70.1.32 | 10.70.65.32 | 10.81.1.32 | 10.82.1.32 |
| s01-pc24 | 2 | 12 | 10.70.1.33 | 10.70.65.33 | 10.81.1.33 | 10.82.1.33 |
| s01-pc25 | 1 | 13 | 10.70.1.34 | 10.70.65.34 | 10.81.1.34 | 10.82.1.34 |
| s01-pc26 | 2 | 13 | 10.70.1.35 | 10.70.65.35 | 10.81.1.35 | 10.82.1.35 |
| s01-pc27 | 1 | 14 | 10.70.1.36 | 10.70.65.36 | 10.81.1.36 | 10.82.1.36 |
| s01-pc28 | 2 | 14 | 10.70.1.37 | 10.70.65.37 | 10.81.1.37 | 10.82.1.37 |
| s01-pc29 | 1 | 15 | 10.70.1.38 | 10.70.65.38 | 10.81.1.38 | 10.82.1.38 |
| s01-pc30 | 2 | 15 | 10.70.1.39 | 10.70.65.39 | 10.81.1.39 | 10.82.1.39 |


**Transporte starlink — VLAN 201 — wanA.**

| Rol de entrega | Dirección |
| --- | --- |
| network | 10.252.1.0/29 |
| cpe | 10.252.1.1 |
| r1 | 10.252.1.2 |
| r2 | 10.252.1.3 |


**Transporte leo — VLAN 202 — wanB.**

| Rol de entrega | Dirección |
| --- | --- |
| network | 10.252.1.8/29 |
| cpe | 10.252.1.9 |
| r1 | 10.252.1.10 |
| r2 | 10.252.1.11 |


**Transporte entel5g — VLAN 203 — wanA.**

| Rol de entrega | Dirección |
| --- | --- |
| network | 10.252.1.16/29 |
| cpe | 10.252.1.17 |
| r1 | 10.252.1.18 |
| r2 | 10.252.1.19 |


**Transporte wom4g — VLAN 204 — wanB.**

| Rol de entrega | Dirección |
| --- | --- |
| network | 10.252.1.24/29 |
| cpe | 10.252.1.25 |
| r1 | 10.252.1.26 |
| r2 | 10.252.1.27 |


**Reservas de túneles (numeración según lista de la ficha).**

| Rol / candidato | Dirección |
| --- | --- |
| .1.hub_public_ip | 198.51.100.4 |
| .1.network | 10.253.1.0/30 |
| .1.branch_ip | 10.253.1.1 |
| .1.hub_ip | 10.253.1.2 |
| .2.hub_public_ip | 203.0.113.4 |
| .2.network | 10.253.1.4/30 |
| .2.branch_ip | 10.253.1.5 |
| .2.hub_ip | 10.253.1.6 |
| .3.hub_public_ip | 198.51.100.4 |
| .3.network | 10.253.1.8/30 |
| .3.branch_ip | 10.253.1.9 |
| .3.hub_ip | 10.253.1.10 |
| .4.hub_public_ip | 203.0.113.4 |
| .4.network | 10.253.1.12/30 |
| .4.branch_ip | 10.253.1.13 |
| .4.hub_ip | 10.253.1.14 |
| .5.hub_public_ip | 198.51.100.4 |
| .5.network | 10.253.1.16/30 |
| .5.branch_ip | 10.253.1.17 |
| .5.hub_ip | 10.253.1.18 |
| .6.hub_public_ip | 203.0.113.4 |
| .6.network | 10.253.1.20/30 |
| .6.branch_ip | 10.253.1.21 |
| .6.hub_ip | 10.253.1.22 |
| .7.hub_public_ip | 198.51.100.4 |
| .7.network | 10.253.1.24/30 |
| .7.branch_ip | 10.253.1.25 |
| .7.hub_ip | 10.253.1.26 |
| .8.hub_public_ip | 203.0.113.4 |
| .8.network | 10.253.1.28/30 |
| .8.branch_ip | 10.253.1.29 |
| .8.hub_ip | 10.253.1.30 |
| .9.hub_public_ip | 198.51.100.4 |
| .9.network | 10.253.1.32/30 |
| .9.branch_ip | 10.253.1.33 |
| .9.hub_ip | 10.253.1.34 |
| .10.hub_public_ip | 203.0.113.4 |
| .10.network | 10.253.1.36/30 |
| .10.branch_ip | 10.253.1.37 |
| .10.hub_ip | 10.253.1.38 |
| .11.hub_public_ip | 198.51.100.4 |
| .11.network | 10.253.1.40/30 |
| .11.branch_ip | 10.253.1.41 |
| .11.hub_ip | 10.253.1.42 |
| .12.hub_public_ip | 203.0.113.4 |
| .12.network | 10.253.1.44/30 |
| .12.branch_ip | 10.253.1.45 |
| .12.hub_ip | 10.253.1.46 |
| .13.hub_public_ip | 198.51.100.4 |
| .13.network | 10.253.1.48/30 |
| .13.branch_ip | 10.253.1.49 |
| .13.hub_ip | 10.253.1.50 |
| .14.hub_public_ip | 203.0.113.4 |
| .14.network | 10.253.1.52/30 |
| .14.branch_ip | 10.253.1.53 |
| .14.hub_ip | 10.253.1.54 |
| .15.hub_public_ip | 198.51.100.4 |
| .15.network | 10.253.1.56/30 |
| .15.branch_ip | 10.253.1.57 |
| .15.hub_ip | 10.253.1.58 |
| .16.hub_public_ip | 203.0.113.4 |
| .16.network | 10.253.1.60/30 |
| .16.branch_ip | 10.253.1.61 |
| .16.hub_ip | 10.253.1.62 |

### S02 — Las Condes

30 PCs y 30 teléfonos existentes.

| Función | ANTES | DESPUÉS |
| --- | --- | --- |
| Routers | 1 × ISR4321/K9 | 2 × C1121X-8P |
| Switches | 1 × C9200L-48P-4G-E | C9200L-48P-4G-E + C9200L-24P-4G-E |
| Firewall | Sin equipo dedicado | Sin appliance remoto; seguridad central |
| Distribución WAN | MPLS y accesos ISP del escenario base | wanA: E50UG; wanB: E50UG |


| Red | VLAN | Subred | Gateway / roles |
| --- | --- | --- | --- |
| users | 10 | 10.70.2.0/25 | 10.70.2.1 |
| voice | 20 | 10.70.66.0/25 | 10.70.66.1 |
| guests | 40 | 10.70.98.0/26 | 10.70.98.1 |
| wifi_users | 110 | 10.81.2.0/25 | 10.81.2.1 |
| wifi_voice | 120 | 10.82.2.0/25 | 10.82.2.1 |
| management | 130 | 10.80.2.0/27 | 10.80.2.1 |


| Gestión | Dirección |
| --- | --- |
| sw1 | 10.80.2.1 |
| sw2 | 10.80.2.1 |
| r1 | 10.80.2.2 |
| r2 | 10.80.2.3 |
| wanA | 10.80.2.6 |
| wanB | 10.80.2.7 |
| ap1 | 10.80.2.24 |
| ap2 | 10.80.2.25 |


| Origen | Puerto | Destino | Puerto | Función | VLAN/red | Mbps | IP / agregado lógico |
| --- | --- | --- | --- | --- | --- | --- | --- |
| cpe:starlink | LAN | wanA | ether1 | WAN_ACCESS | 201 | 1000 | — |
| cpe:entel5g | LAN | wanA | ether2 | WAN_ACCESS | 203 | 1000 | — |
| r1 | GigabitEthernet0/0/0 | wanA | ether3 | WAN_TRUNK | 201, 203 | 1000 | — |
| r2 | GigabitEthernet0/0/0 | wanA | ether4 | WAN_TRUNK | 201, 203 | 1000 | — |
| wanA | ether5 | sw1 | Gi1/0/22 | MANAGEMENT_ACCESS | 130 | 1000 | — |
| cpe:leo | LAN | wanB | ether1 | WAN_ACCESS | 202 | 1000 | — |
| cpe:wom4g | LAN | wanB | ether2 | WAN_ACCESS | 204 | 1000 | — |
| r1 | GigabitEthernet0/0/1 | wanB | ether3 | WAN_TRUNK | 202, 204 | 1000 | — |
| r2 | GigabitEthernet0/0/1 | wanB | ether4 | WAN_TRUNK | 202, 204 | 1000 | — |
| wanB | ether5 | sw2 | Gi2/0/22 | MANAGEMENT_ACCESS | 130 | 1000 | — |
| r1 | GigabitEthernet0/1/0 | sw1 | Gi1/0/19 | LAN_ROUTED | 172.31.2.0/30 | 1000 | router_ip: 172.31.2.1; stack_ip: 172.31.2.2 |
| r1 | GigabitEthernet0/1/1 | sw2 | Gi2/0/19 | LAN_ROUTED | 172.31.2.4/30 | 1000 | router_ip: 172.31.2.5; stack_ip: 172.31.2.6 |
| r1 | GigabitEthernet0/1/2 | sw1 | Gi1/0/21 | MANAGEMENT_ACCESS | 130 | 1000 | — |
| r2 | GigabitEthernet0/1/0 | sw1 | Gi1/0/20 | LAN_ROUTED | 172.31.2.8/30 | 1000 | router_ip: 172.31.2.9; stack_ip: 172.31.2.10 |
| r2 | GigabitEthernet0/1/1 | sw2 | Gi2/0/20 | LAN_ROUTED | 172.31.2.12/30 | 1000 | router_ip: 172.31.2.13; stack_ip: 172.31.2.14 |
| r2 | GigabitEthernet0/1/2 | sw2 | Gi2/0/21 | MANAGEMENT_ACCESS | 130 | 1000 | — |
| ap1 | LAN | sw1 | Gi1/0/24 | AP_TRUNK | 40, 110, 120, 130 | 1000 | — |
| ap2 | LAN | sw2 | Gi2/0/24 | AP_TRUNK | 40, 110, 120, 130 | 1000 | — |
| sw1 | Stack1 | sw2 | Stack2 | STACK | — | 80000 | — |
| sw1 | Stack2 | sw2 | Stack1 | STACK | — | 80000 | — |


| Puesto | Switch | Puerto | IP PC | IP teléfono | Reserva Wi-Fi PC | Reserva Wi-Fi voz |
| --- | --- | --- | --- | --- | --- | --- |
| s02-pc01 | 1 | 1 | 10.70.2.10 | 10.70.66.10 | 10.81.2.10 | 10.82.2.10 |
| s02-pc02 | 2 | 1 | 10.70.2.11 | 10.70.66.11 | 10.81.2.11 | 10.82.2.11 |
| s02-pc03 | 1 | 2 | 10.70.2.12 | 10.70.66.12 | 10.81.2.12 | 10.82.2.12 |
| s02-pc04 | 2 | 2 | 10.70.2.13 | 10.70.66.13 | 10.81.2.13 | 10.82.2.13 |
| s02-pc05 | 1 | 3 | 10.70.2.14 | 10.70.66.14 | 10.81.2.14 | 10.82.2.14 |
| s02-pc06 | 2 | 3 | 10.70.2.15 | 10.70.66.15 | 10.81.2.15 | 10.82.2.15 |
| s02-pc07 | 1 | 4 | 10.70.2.16 | 10.70.66.16 | 10.81.2.16 | 10.82.2.16 |
| s02-pc08 | 2 | 4 | 10.70.2.17 | 10.70.66.17 | 10.81.2.17 | 10.82.2.17 |
| s02-pc09 | 1 | 5 | 10.70.2.18 | 10.70.66.18 | 10.81.2.18 | 10.82.2.18 |
| s02-pc10 | 2 | 5 | 10.70.2.19 | 10.70.66.19 | 10.81.2.19 | 10.82.2.19 |
| s02-pc11 | 1 | 6 | 10.70.2.20 | 10.70.66.20 | 10.81.2.20 | 10.82.2.20 |
| s02-pc12 | 2 | 6 | 10.70.2.21 | 10.70.66.21 | 10.81.2.21 | 10.82.2.21 |
| s02-pc13 | 1 | 7 | 10.70.2.22 | 10.70.66.22 | 10.81.2.22 | 10.82.2.22 |
| s02-pc14 | 2 | 7 | 10.70.2.23 | 10.70.66.23 | 10.81.2.23 | 10.82.2.23 |
| s02-pc15 | 1 | 8 | 10.70.2.24 | 10.70.66.24 | 10.81.2.24 | 10.82.2.24 |
| s02-pc16 | 2 | 8 | 10.70.2.25 | 10.70.66.25 | 10.81.2.25 | 10.82.2.25 |
| s02-pc17 | 1 | 9 | 10.70.2.26 | 10.70.66.26 | 10.81.2.26 | 10.82.2.26 |
| s02-pc18 | 2 | 9 | 10.70.2.27 | 10.70.66.27 | 10.81.2.27 | 10.82.2.27 |
| s02-pc19 | 1 | 10 | 10.70.2.28 | 10.70.66.28 | 10.81.2.28 | 10.82.2.28 |
| s02-pc20 | 2 | 10 | 10.70.2.29 | 10.70.66.29 | 10.81.2.29 | 10.82.2.29 |
| s02-pc21 | 1 | 11 | 10.70.2.30 | 10.70.66.30 | 10.81.2.30 | 10.82.2.30 |
| s02-pc22 | 2 | 11 | 10.70.2.31 | 10.70.66.31 | 10.81.2.31 | 10.82.2.31 |
| s02-pc23 | 1 | 12 | 10.70.2.32 | 10.70.66.32 | 10.81.2.32 | 10.82.2.32 |
| s02-pc24 | 2 | 12 | 10.70.2.33 | 10.70.66.33 | 10.81.2.33 | 10.82.2.33 |
| s02-pc25 | 1 | 13 | 10.70.2.34 | 10.70.66.34 | 10.81.2.34 | 10.82.2.34 |
| s02-pc26 | 2 | 13 | 10.70.2.35 | 10.70.66.35 | 10.81.2.35 | 10.82.2.35 |
| s02-pc27 | 1 | 14 | 10.70.2.36 | 10.70.66.36 | 10.81.2.36 | 10.82.2.36 |
| s02-pc28 | 2 | 14 | 10.70.2.37 | 10.70.66.37 | 10.81.2.37 | 10.82.2.37 |
| s02-pc29 | 1 | 15 | 10.70.2.38 | 10.70.66.38 | 10.81.2.38 | 10.82.2.38 |
| s02-pc30 | 2 | 15 | 10.70.2.39 | 10.70.66.39 | 10.81.2.39 | 10.82.2.39 |


**Transporte starlink — VLAN 201 — wanA.**

| Rol de entrega | Dirección |
| --- | --- |
| network | 10.252.2.0/29 |
| cpe | 10.252.2.1 |
| r1 | 10.252.2.2 |
| r2 | 10.252.2.3 |


**Transporte leo — VLAN 202 — wanB.**

| Rol de entrega | Dirección |
| --- | --- |
| network | 10.252.2.8/29 |
| cpe | 10.252.2.9 |
| r1 | 10.252.2.10 |
| r2 | 10.252.2.11 |


**Transporte entel5g — VLAN 203 — wanA.**

| Rol de entrega | Dirección |
| --- | --- |
| network | 10.252.2.16/29 |
| cpe | 10.252.2.17 |
| r1 | 10.252.2.18 |
| r2 | 10.252.2.19 |


**Transporte wom4g — VLAN 204 — wanB.**

| Rol de entrega | Dirección |
| --- | --- |
| network | 10.252.2.24/29 |
| cpe | 10.252.2.25 |
| r1 | 10.252.2.26 |
| r2 | 10.252.2.27 |


**Reservas de túneles (numeración según lista de la ficha).**

| Rol / candidato | Dirección |
| --- | --- |
| .1.hub_public_ip | 198.51.100.4 |
| .1.network | 10.253.2.0/30 |
| .1.branch_ip | 10.253.2.1 |
| .1.hub_ip | 10.253.2.2 |
| .2.hub_public_ip | 203.0.113.4 |
| .2.network | 10.253.2.4/30 |
| .2.branch_ip | 10.253.2.5 |
| .2.hub_ip | 10.253.2.6 |
| .3.hub_public_ip | 198.51.100.4 |
| .3.network | 10.253.2.8/30 |
| .3.branch_ip | 10.253.2.9 |
| .3.hub_ip | 10.253.2.10 |
| .4.hub_public_ip | 203.0.113.4 |
| .4.network | 10.253.2.12/30 |
| .4.branch_ip | 10.253.2.13 |
| .4.hub_ip | 10.253.2.14 |
| .5.hub_public_ip | 198.51.100.4 |
| .5.network | 10.253.2.16/30 |
| .5.branch_ip | 10.253.2.17 |
| .5.hub_ip | 10.253.2.18 |
| .6.hub_public_ip | 203.0.113.4 |
| .6.network | 10.253.2.20/30 |
| .6.branch_ip | 10.253.2.21 |
| .6.hub_ip | 10.253.2.22 |
| .7.hub_public_ip | 198.51.100.4 |
| .7.network | 10.253.2.24/30 |
| .7.branch_ip | 10.253.2.25 |
| .7.hub_ip | 10.253.2.26 |
| .8.hub_public_ip | 203.0.113.4 |
| .8.network | 10.253.2.28/30 |
| .8.branch_ip | 10.253.2.29 |
| .8.hub_ip | 10.253.2.30 |
| .9.hub_public_ip | 198.51.100.4 |
| .9.network | 10.253.2.32/30 |
| .9.branch_ip | 10.253.2.33 |
| .9.hub_ip | 10.253.2.34 |
| .10.hub_public_ip | 203.0.113.4 |
| .10.network | 10.253.2.36/30 |
| .10.branch_ip | 10.253.2.37 |
| .10.hub_ip | 10.253.2.38 |
| .11.hub_public_ip | 198.51.100.4 |
| .11.network | 10.253.2.40/30 |
| .11.branch_ip | 10.253.2.41 |
| .11.hub_ip | 10.253.2.42 |
| .12.hub_public_ip | 203.0.113.4 |
| .12.network | 10.253.2.44/30 |
| .12.branch_ip | 10.253.2.45 |
| .12.hub_ip | 10.253.2.46 |
| .13.hub_public_ip | 198.51.100.4 |
| .13.network | 10.253.2.48/30 |
| .13.branch_ip | 10.253.2.49 |
| .13.hub_ip | 10.253.2.50 |
| .14.hub_public_ip | 203.0.113.4 |
| .14.network | 10.253.2.52/30 |
| .14.branch_ip | 10.253.2.53 |
| .14.hub_ip | 10.253.2.54 |
| .15.hub_public_ip | 198.51.100.4 |
| .15.network | 10.253.2.56/30 |
| .15.branch_ip | 10.253.2.57 |
| .15.hub_ip | 10.253.2.58 |
| .16.hub_public_ip | 203.0.113.4 |
| .16.network | 10.253.2.60/30 |
| .16.branch_ip | 10.253.2.61 |
| .16.hub_ip | 10.253.2.62 |

### S03 — Maipú

30 PCs y 30 teléfonos existentes.

| Función | ANTES | DESPUÉS |
| --- | --- | --- |
| Routers | 1 × CISCO1921-SEC/K9 | 2 × C1121X-8P |
| Switches | 1 × WS-C2960S-48LPS-L | C9200L-24P-4G-E + C9200L-24P-4G-E |
| Firewall | Sin equipo dedicado | Sin appliance remoto; seguridad central |
| Distribución WAN | MPLS y accesos ISP del escenario base | wanA: E50UG; wanB: E50UG |


| Red | VLAN | Subred | Gateway / roles |
| --- | --- | --- | --- |
| users | 10 | 10.70.3.0/25 | 10.70.3.1 |
| voice | 20 | 10.70.67.0/25 | 10.70.67.1 |
| guests | 40 | 10.70.99.0/26 | 10.70.99.1 |
| wifi_users | 110 | 10.81.3.0/25 | 10.81.3.1 |
| wifi_voice | 120 | 10.82.3.0/25 | 10.82.3.1 |
| management | 130 | 10.80.3.0/27 | 10.80.3.1 |


| Gestión | Dirección |
| --- | --- |
| sw1 | 10.80.3.1 |
| sw2 | 10.80.3.1 |
| r1 | 10.80.3.2 |
| r2 | 10.80.3.3 |
| wanA | 10.80.3.6 |
| wanB | 10.80.3.7 |
| ap1 | 10.80.3.24 |
| ap2 | 10.80.3.25 |


| Origen | Puerto | Destino | Puerto | Función | VLAN/red | Mbps | IP / agregado lógico |
| --- | --- | --- | --- | --- | --- | --- | --- |
| cpe:starlink | LAN | wanA | ether1 | WAN_ACCESS | 201 | 1000 | — |
| cpe:entel5g | LAN | wanA | ether2 | WAN_ACCESS | 203 | 1000 | — |
| r1 | GigabitEthernet0/0/0 | wanA | ether3 | WAN_TRUNK | 201, 203 | 1000 | — |
| r2 | GigabitEthernet0/0/0 | wanA | ether4 | WAN_TRUNK | 201, 203 | 1000 | — |
| wanA | ether5 | sw1 | Gi1/0/22 | MANAGEMENT_ACCESS | 130 | 1000 | — |
| cpe:leo | LAN | wanB | ether1 | WAN_ACCESS | 202 | 1000 | — |
| cpe:wom4g | LAN | wanB | ether2 | WAN_ACCESS | 204 | 1000 | — |
| r1 | GigabitEthernet0/0/1 | wanB | ether3 | WAN_TRUNK | 202, 204 | 1000 | — |
| r2 | GigabitEthernet0/0/1 | wanB | ether4 | WAN_TRUNK | 202, 204 | 1000 | — |
| wanB | ether5 | sw2 | Gi2/0/22 | MANAGEMENT_ACCESS | 130 | 1000 | — |
| r1 | GigabitEthernet0/1/0 | sw1 | Gi1/0/19 | LAN_ROUTED | 172.31.3.0/30 | 1000 | router_ip: 172.31.3.1; stack_ip: 172.31.3.2 |
| r1 | GigabitEthernet0/1/1 | sw2 | Gi2/0/19 | LAN_ROUTED | 172.31.3.4/30 | 1000 | router_ip: 172.31.3.5; stack_ip: 172.31.3.6 |
| r1 | GigabitEthernet0/1/2 | sw1 | Gi1/0/21 | MANAGEMENT_ACCESS | 130 | 1000 | — |
| r2 | GigabitEthernet0/1/0 | sw1 | Gi1/0/20 | LAN_ROUTED | 172.31.3.8/30 | 1000 | router_ip: 172.31.3.9; stack_ip: 172.31.3.10 |
| r2 | GigabitEthernet0/1/1 | sw2 | Gi2/0/20 | LAN_ROUTED | 172.31.3.12/30 | 1000 | router_ip: 172.31.3.13; stack_ip: 172.31.3.14 |
| r2 | GigabitEthernet0/1/2 | sw2 | Gi2/0/21 | MANAGEMENT_ACCESS | 130 | 1000 | — |
| ap1 | LAN | sw1 | Gi1/0/24 | AP_TRUNK | 40, 110, 120, 130 | 1000 | — |
| ap2 | LAN | sw2 | Gi2/0/24 | AP_TRUNK | 40, 110, 120, 130 | 1000 | — |
| sw1 | Stack1 | sw2 | Stack2 | STACK | — | 80000 | — |
| sw1 | Stack2 | sw2 | Stack1 | STACK | — | 80000 | — |


| Puesto | Switch | Puerto | IP PC | IP teléfono | Reserva Wi-Fi PC | Reserva Wi-Fi voz |
| --- | --- | --- | --- | --- | --- | --- |
| s03-pc01 | 1 | 1 | 10.70.3.10 | 10.70.67.10 | 10.81.3.10 | 10.82.3.10 |
| s03-pc02 | 2 | 1 | 10.70.3.11 | 10.70.67.11 | 10.81.3.11 | 10.82.3.11 |
| s03-pc03 | 1 | 2 | 10.70.3.12 | 10.70.67.12 | 10.81.3.12 | 10.82.3.12 |
| s03-pc04 | 2 | 2 | 10.70.3.13 | 10.70.67.13 | 10.81.3.13 | 10.82.3.13 |
| s03-pc05 | 1 | 3 | 10.70.3.14 | 10.70.67.14 | 10.81.3.14 | 10.82.3.14 |
| s03-pc06 | 2 | 3 | 10.70.3.15 | 10.70.67.15 | 10.81.3.15 | 10.82.3.15 |
| s03-pc07 | 1 | 4 | 10.70.3.16 | 10.70.67.16 | 10.81.3.16 | 10.82.3.16 |
| s03-pc08 | 2 | 4 | 10.70.3.17 | 10.70.67.17 | 10.81.3.17 | 10.82.3.17 |
| s03-pc09 | 1 | 5 | 10.70.3.18 | 10.70.67.18 | 10.81.3.18 | 10.82.3.18 |
| s03-pc10 | 2 | 5 | 10.70.3.19 | 10.70.67.19 | 10.81.3.19 | 10.82.3.19 |
| s03-pc11 | 1 | 6 | 10.70.3.20 | 10.70.67.20 | 10.81.3.20 | 10.82.3.20 |
| s03-pc12 | 2 | 6 | 10.70.3.21 | 10.70.67.21 | 10.81.3.21 | 10.82.3.21 |
| s03-pc13 | 1 | 7 | 10.70.3.22 | 10.70.67.22 | 10.81.3.22 | 10.82.3.22 |
| s03-pc14 | 2 | 7 | 10.70.3.23 | 10.70.67.23 | 10.81.3.23 | 10.82.3.23 |
| s03-pc15 | 1 | 8 | 10.70.3.24 | 10.70.67.24 | 10.81.3.24 | 10.82.3.24 |
| s03-pc16 | 2 | 8 | 10.70.3.25 | 10.70.67.25 | 10.81.3.25 | 10.82.3.25 |
| s03-pc17 | 1 | 9 | 10.70.3.26 | 10.70.67.26 | 10.81.3.26 | 10.82.3.26 |
| s03-pc18 | 2 | 9 | 10.70.3.27 | 10.70.67.27 | 10.81.3.27 | 10.82.3.27 |
| s03-pc19 | 1 | 10 | 10.70.3.28 | 10.70.67.28 | 10.81.3.28 | 10.82.3.28 |
| s03-pc20 | 2 | 10 | 10.70.3.29 | 10.70.67.29 | 10.81.3.29 | 10.82.3.29 |
| s03-pc21 | 1 | 11 | 10.70.3.30 | 10.70.67.30 | 10.81.3.30 | 10.82.3.30 |
| s03-pc22 | 2 | 11 | 10.70.3.31 | 10.70.67.31 | 10.81.3.31 | 10.82.3.31 |
| s03-pc23 | 1 | 12 | 10.70.3.32 | 10.70.67.32 | 10.81.3.32 | 10.82.3.32 |
| s03-pc24 | 2 | 12 | 10.70.3.33 | 10.70.67.33 | 10.81.3.33 | 10.82.3.33 |
| s03-pc25 | 1 | 13 | 10.70.3.34 | 10.70.67.34 | 10.81.3.34 | 10.82.3.34 |
| s03-pc26 | 2 | 13 | 10.70.3.35 | 10.70.67.35 | 10.81.3.35 | 10.82.3.35 |
| s03-pc27 | 1 | 14 | 10.70.3.36 | 10.70.67.36 | 10.81.3.36 | 10.82.3.36 |
| s03-pc28 | 2 | 14 | 10.70.3.37 | 10.70.67.37 | 10.81.3.37 | 10.82.3.37 |
| s03-pc29 | 1 | 15 | 10.70.3.38 | 10.70.67.38 | 10.81.3.38 | 10.82.3.38 |
| s03-pc30 | 2 | 15 | 10.70.3.39 | 10.70.67.39 | 10.81.3.39 | 10.82.3.39 |


**Transporte starlink — VLAN 201 — wanA.**

| Rol de entrega | Dirección |
| --- | --- |
| network | 10.252.3.0/29 |
| cpe | 10.252.3.1 |
| r1 | 10.252.3.2 |
| r2 | 10.252.3.3 |


**Transporte leo — VLAN 202 — wanB.**

| Rol de entrega | Dirección |
| --- | --- |
| network | 10.252.3.8/29 |
| cpe | 10.252.3.9 |
| r1 | 10.252.3.10 |
| r2 | 10.252.3.11 |


**Transporte entel5g — VLAN 203 — wanA.**

| Rol de entrega | Dirección |
| --- | --- |
| network | 10.252.3.16/29 |
| cpe | 10.252.3.17 |
| r1 | 10.252.3.18 |
| r2 | 10.252.3.19 |


**Transporte wom4g — VLAN 204 — wanB.**

| Rol de entrega | Dirección |
| --- | --- |
| network | 10.252.3.24/29 |
| cpe | 10.252.3.25 |
| r1 | 10.252.3.26 |
| r2 | 10.252.3.27 |


**Reservas de túneles (numeración según lista de la ficha).**

| Rol / candidato | Dirección |
| --- | --- |
| .1.hub_public_ip | 198.51.100.4 |
| .1.network | 10.253.3.0/30 |
| .1.branch_ip | 10.253.3.1 |
| .1.hub_ip | 10.253.3.2 |
| .2.hub_public_ip | 203.0.113.4 |
| .2.network | 10.253.3.4/30 |
| .2.branch_ip | 10.253.3.5 |
| .2.hub_ip | 10.253.3.6 |
| .3.hub_public_ip | 198.51.100.4 |
| .3.network | 10.253.3.8/30 |
| .3.branch_ip | 10.253.3.9 |
| .3.hub_ip | 10.253.3.10 |
| .4.hub_public_ip | 203.0.113.4 |
| .4.network | 10.253.3.12/30 |
| .4.branch_ip | 10.253.3.13 |
| .4.hub_ip | 10.253.3.14 |
| .5.hub_public_ip | 198.51.100.4 |
| .5.network | 10.253.3.16/30 |
| .5.branch_ip | 10.253.3.17 |
| .5.hub_ip | 10.253.3.18 |
| .6.hub_public_ip | 203.0.113.4 |
| .6.network | 10.253.3.20/30 |
| .6.branch_ip | 10.253.3.21 |
| .6.hub_ip | 10.253.3.22 |
| .7.hub_public_ip | 198.51.100.4 |
| .7.network | 10.253.3.24/30 |
| .7.branch_ip | 10.253.3.25 |
| .7.hub_ip | 10.253.3.26 |
| .8.hub_public_ip | 203.0.113.4 |
| .8.network | 10.253.3.28/30 |
| .8.branch_ip | 10.253.3.29 |
| .8.hub_ip | 10.253.3.30 |
| .9.hub_public_ip | 198.51.100.4 |
| .9.network | 10.253.3.32/30 |
| .9.branch_ip | 10.253.3.33 |
| .9.hub_ip | 10.253.3.34 |
| .10.hub_public_ip | 203.0.113.4 |
| .10.network | 10.253.3.36/30 |
| .10.branch_ip | 10.253.3.37 |
| .10.hub_ip | 10.253.3.38 |
| .11.hub_public_ip | 198.51.100.4 |
| .11.network | 10.253.3.40/30 |
| .11.branch_ip | 10.253.3.41 |
| .11.hub_ip | 10.253.3.42 |
| .12.hub_public_ip | 203.0.113.4 |
| .12.network | 10.253.3.44/30 |
| .12.branch_ip | 10.253.3.45 |
| .12.hub_ip | 10.253.3.46 |
| .13.hub_public_ip | 198.51.100.4 |
| .13.network | 10.253.3.48/30 |
| .13.branch_ip | 10.253.3.49 |
| .13.hub_ip | 10.253.3.50 |
| .14.hub_public_ip | 203.0.113.4 |
| .14.network | 10.253.3.52/30 |
| .14.branch_ip | 10.253.3.53 |
| .14.hub_ip | 10.253.3.54 |
| .15.hub_public_ip | 198.51.100.4 |
| .15.network | 10.253.3.56/30 |
| .15.branch_ip | 10.253.3.57 |
| .15.hub_ip | 10.253.3.58 |
| .16.hub_public_ip | 203.0.113.4 |
| .16.network | 10.253.3.60/30 |
| .16.branch_ip | 10.253.3.61 |
| .16.hub_ip | 10.253.3.62 |

### S04 — Puente Alto

30 PCs y 30 teléfonos existentes.

| Función | ANTES | DESPUÉS |
| --- | --- | --- |
| Routers | 1 × ISR4321/K9 | 2 × C1121X-8P |
| Switches | 1 × C9200L-48P-4G-E | C9200L-48P-4G-E + C9200L-24P-4G-E |
| Firewall | Sin equipo dedicado | Sin appliance remoto; seguridad central |
| Distribución WAN | MPLS y accesos ISP del escenario base | wanA: E50UG; wanB: E50UG |


| Red | VLAN | Subred | Gateway / roles |
| --- | --- | --- | --- |
| users | 10 | 10.70.4.0/25 | 10.70.4.1 |
| voice | 20 | 10.70.68.0/25 | 10.70.68.1 |
| guests | 40 | 10.70.100.0/26 | 10.70.100.1 |
| wifi_users | 110 | 10.81.4.0/25 | 10.81.4.1 |
| wifi_voice | 120 | 10.82.4.0/25 | 10.82.4.1 |
| management | 130 | 10.80.4.0/27 | 10.80.4.1 |


| Gestión | Dirección |
| --- | --- |
| sw1 | 10.80.4.1 |
| sw2 | 10.80.4.1 |
| r1 | 10.80.4.2 |
| r2 | 10.80.4.3 |
| wanA | 10.80.4.6 |
| wanB | 10.80.4.7 |
| ap1 | 10.80.4.24 |
| ap2 | 10.80.4.25 |


| Origen | Puerto | Destino | Puerto | Función | VLAN/red | Mbps | IP / agregado lógico |
| --- | --- | --- | --- | --- | --- | --- | --- |
| cpe:starlink | LAN | wanA | ether1 | WAN_ACCESS | 201 | 1000 | — |
| cpe:entel5g | LAN | wanA | ether2 | WAN_ACCESS | 203 | 1000 | — |
| r1 | GigabitEthernet0/0/0 | wanA | ether3 | WAN_TRUNK | 201, 203 | 1000 | — |
| r2 | GigabitEthernet0/0/0 | wanA | ether4 | WAN_TRUNK | 201, 203 | 1000 | — |
| wanA | ether5 | sw1 | Gi1/0/22 | MANAGEMENT_ACCESS | 130 | 1000 | — |
| cpe:leo | LAN | wanB | ether1 | WAN_ACCESS | 202 | 1000 | — |
| cpe:wom4g | LAN | wanB | ether2 | WAN_ACCESS | 204 | 1000 | — |
| r1 | GigabitEthernet0/0/1 | wanB | ether3 | WAN_TRUNK | 202, 204 | 1000 | — |
| r2 | GigabitEthernet0/0/1 | wanB | ether4 | WAN_TRUNK | 202, 204 | 1000 | — |
| wanB | ether5 | sw2 | Gi2/0/22 | MANAGEMENT_ACCESS | 130 | 1000 | — |
| r1 | GigabitEthernet0/1/0 | sw1 | Gi1/0/19 | LAN_ROUTED | 172.31.4.0/30 | 1000 | router_ip: 172.31.4.1; stack_ip: 172.31.4.2 |
| r1 | GigabitEthernet0/1/1 | sw2 | Gi2/0/19 | LAN_ROUTED | 172.31.4.4/30 | 1000 | router_ip: 172.31.4.5; stack_ip: 172.31.4.6 |
| r1 | GigabitEthernet0/1/2 | sw1 | Gi1/0/21 | MANAGEMENT_ACCESS | 130 | 1000 | — |
| r2 | GigabitEthernet0/1/0 | sw1 | Gi1/0/20 | LAN_ROUTED | 172.31.4.8/30 | 1000 | router_ip: 172.31.4.9; stack_ip: 172.31.4.10 |
| r2 | GigabitEthernet0/1/1 | sw2 | Gi2/0/20 | LAN_ROUTED | 172.31.4.12/30 | 1000 | router_ip: 172.31.4.13; stack_ip: 172.31.4.14 |
| r2 | GigabitEthernet0/1/2 | sw2 | Gi2/0/21 | MANAGEMENT_ACCESS | 130 | 1000 | — |
| ap1 | LAN | sw1 | Gi1/0/24 | AP_TRUNK | 40, 110, 120, 130 | 1000 | — |
| ap2 | LAN | sw2 | Gi2/0/24 | AP_TRUNK | 40, 110, 120, 130 | 1000 | — |
| sw1 | Stack1 | sw2 | Stack2 | STACK | — | 80000 | — |
| sw1 | Stack2 | sw2 | Stack1 | STACK | — | 80000 | — |


| Puesto | Switch | Puerto | IP PC | IP teléfono | Reserva Wi-Fi PC | Reserva Wi-Fi voz |
| --- | --- | --- | --- | --- | --- | --- |
| s04-pc01 | 1 | 1 | 10.70.4.10 | 10.70.68.10 | 10.81.4.10 | 10.82.4.10 |
| s04-pc02 | 2 | 1 | 10.70.4.11 | 10.70.68.11 | 10.81.4.11 | 10.82.4.11 |
| s04-pc03 | 1 | 2 | 10.70.4.12 | 10.70.68.12 | 10.81.4.12 | 10.82.4.12 |
| s04-pc04 | 2 | 2 | 10.70.4.13 | 10.70.68.13 | 10.81.4.13 | 10.82.4.13 |
| s04-pc05 | 1 | 3 | 10.70.4.14 | 10.70.68.14 | 10.81.4.14 | 10.82.4.14 |
| s04-pc06 | 2 | 3 | 10.70.4.15 | 10.70.68.15 | 10.81.4.15 | 10.82.4.15 |
| s04-pc07 | 1 | 4 | 10.70.4.16 | 10.70.68.16 | 10.81.4.16 | 10.82.4.16 |
| s04-pc08 | 2 | 4 | 10.70.4.17 | 10.70.68.17 | 10.81.4.17 | 10.82.4.17 |
| s04-pc09 | 1 | 5 | 10.70.4.18 | 10.70.68.18 | 10.81.4.18 | 10.82.4.18 |
| s04-pc10 | 2 | 5 | 10.70.4.19 | 10.70.68.19 | 10.81.4.19 | 10.82.4.19 |
| s04-pc11 | 1 | 6 | 10.70.4.20 | 10.70.68.20 | 10.81.4.20 | 10.82.4.20 |
| s04-pc12 | 2 | 6 | 10.70.4.21 | 10.70.68.21 | 10.81.4.21 | 10.82.4.21 |
| s04-pc13 | 1 | 7 | 10.70.4.22 | 10.70.68.22 | 10.81.4.22 | 10.82.4.22 |
| s04-pc14 | 2 | 7 | 10.70.4.23 | 10.70.68.23 | 10.81.4.23 | 10.82.4.23 |
| s04-pc15 | 1 | 8 | 10.70.4.24 | 10.70.68.24 | 10.81.4.24 | 10.82.4.24 |
| s04-pc16 | 2 | 8 | 10.70.4.25 | 10.70.68.25 | 10.81.4.25 | 10.82.4.25 |
| s04-pc17 | 1 | 9 | 10.70.4.26 | 10.70.68.26 | 10.81.4.26 | 10.82.4.26 |
| s04-pc18 | 2 | 9 | 10.70.4.27 | 10.70.68.27 | 10.81.4.27 | 10.82.4.27 |
| s04-pc19 | 1 | 10 | 10.70.4.28 | 10.70.68.28 | 10.81.4.28 | 10.82.4.28 |
| s04-pc20 | 2 | 10 | 10.70.4.29 | 10.70.68.29 | 10.81.4.29 | 10.82.4.29 |
| s04-pc21 | 1 | 11 | 10.70.4.30 | 10.70.68.30 | 10.81.4.30 | 10.82.4.30 |
| s04-pc22 | 2 | 11 | 10.70.4.31 | 10.70.68.31 | 10.81.4.31 | 10.82.4.31 |
| s04-pc23 | 1 | 12 | 10.70.4.32 | 10.70.68.32 | 10.81.4.32 | 10.82.4.32 |
| s04-pc24 | 2 | 12 | 10.70.4.33 | 10.70.68.33 | 10.81.4.33 | 10.82.4.33 |
| s04-pc25 | 1 | 13 | 10.70.4.34 | 10.70.68.34 | 10.81.4.34 | 10.82.4.34 |
| s04-pc26 | 2 | 13 | 10.70.4.35 | 10.70.68.35 | 10.81.4.35 | 10.82.4.35 |
| s04-pc27 | 1 | 14 | 10.70.4.36 | 10.70.68.36 | 10.81.4.36 | 10.82.4.36 |
| s04-pc28 | 2 | 14 | 10.70.4.37 | 10.70.68.37 | 10.81.4.37 | 10.82.4.37 |
| s04-pc29 | 1 | 15 | 10.70.4.38 | 10.70.68.38 | 10.81.4.38 | 10.82.4.38 |
| s04-pc30 | 2 | 15 | 10.70.4.39 | 10.70.68.39 | 10.81.4.39 | 10.82.4.39 |


**Transporte starlink — VLAN 201 — wanA.**

| Rol de entrega | Dirección |
| --- | --- |
| network | 10.252.4.0/29 |
| cpe | 10.252.4.1 |
| r1 | 10.252.4.2 |
| r2 | 10.252.4.3 |


**Transporte leo — VLAN 202 — wanB.**

| Rol de entrega | Dirección |
| --- | --- |
| network | 10.252.4.8/29 |
| cpe | 10.252.4.9 |
| r1 | 10.252.4.10 |
| r2 | 10.252.4.11 |


**Transporte entel5g — VLAN 203 — wanA.**

| Rol de entrega | Dirección |
| --- | --- |
| network | 10.252.4.16/29 |
| cpe | 10.252.4.17 |
| r1 | 10.252.4.18 |
| r2 | 10.252.4.19 |


**Transporte wom4g — VLAN 204 — wanB.**

| Rol de entrega | Dirección |
| --- | --- |
| network | 10.252.4.24/29 |
| cpe | 10.252.4.25 |
| r1 | 10.252.4.26 |
| r2 | 10.252.4.27 |


**Reservas de túneles (numeración según lista de la ficha).**

| Rol / candidato | Dirección |
| --- | --- |
| .1.hub_public_ip | 198.51.100.4 |
| .1.network | 10.253.4.0/30 |
| .1.branch_ip | 10.253.4.1 |
| .1.hub_ip | 10.253.4.2 |
| .2.hub_public_ip | 203.0.113.4 |
| .2.network | 10.253.4.4/30 |
| .2.branch_ip | 10.253.4.5 |
| .2.hub_ip | 10.253.4.6 |
| .3.hub_public_ip | 198.51.100.4 |
| .3.network | 10.253.4.8/30 |
| .3.branch_ip | 10.253.4.9 |
| .3.hub_ip | 10.253.4.10 |
| .4.hub_public_ip | 203.0.113.4 |
| .4.network | 10.253.4.12/30 |
| .4.branch_ip | 10.253.4.13 |
| .4.hub_ip | 10.253.4.14 |
| .5.hub_public_ip | 198.51.100.4 |
| .5.network | 10.253.4.16/30 |
| .5.branch_ip | 10.253.4.17 |
| .5.hub_ip | 10.253.4.18 |
| .6.hub_public_ip | 203.0.113.4 |
| .6.network | 10.253.4.20/30 |
| .6.branch_ip | 10.253.4.21 |
| .6.hub_ip | 10.253.4.22 |
| .7.hub_public_ip | 198.51.100.4 |
| .7.network | 10.253.4.24/30 |
| .7.branch_ip | 10.253.4.25 |
| .7.hub_ip | 10.253.4.26 |
| .8.hub_public_ip | 203.0.113.4 |
| .8.network | 10.253.4.28/30 |
| .8.branch_ip | 10.253.4.29 |
| .8.hub_ip | 10.253.4.30 |
| .9.hub_public_ip | 198.51.100.4 |
| .9.network | 10.253.4.32/30 |
| .9.branch_ip | 10.253.4.33 |
| .9.hub_ip | 10.253.4.34 |
| .10.hub_public_ip | 203.0.113.4 |
| .10.network | 10.253.4.36/30 |
| .10.branch_ip | 10.253.4.37 |
| .10.hub_ip | 10.253.4.38 |
| .11.hub_public_ip | 198.51.100.4 |
| .11.network | 10.253.4.40/30 |
| .11.branch_ip | 10.253.4.41 |
| .11.hub_ip | 10.253.4.42 |
| .12.hub_public_ip | 203.0.113.4 |
| .12.network | 10.253.4.44/30 |
| .12.branch_ip | 10.253.4.45 |
| .12.hub_ip | 10.253.4.46 |
| .13.hub_public_ip | 198.51.100.4 |
| .13.network | 10.253.4.48/30 |
| .13.branch_ip | 10.253.4.49 |
| .13.hub_ip | 10.253.4.50 |
| .14.hub_public_ip | 203.0.113.4 |
| .14.network | 10.253.4.52/30 |
| .14.branch_ip | 10.253.4.53 |
| .14.hub_ip | 10.253.4.54 |
| .15.hub_public_ip | 198.51.100.4 |
| .15.network | 10.253.4.56/30 |
| .15.branch_ip | 10.253.4.57 |
| .15.hub_ip | 10.253.4.58 |
| .16.hub_public_ip | 203.0.113.4 |
| .16.network | 10.253.4.60/30 |
| .16.branch_ip | 10.253.4.61 |
| .16.hub_ip | 10.253.4.62 |

### S05 — La Florida

30 PCs y 30 teléfonos existentes.

| Función | ANTES | DESPUÉS |
| --- | --- | --- |
| Routers | 1 × ISR4321/K9 | 2 × C1121X-8P |
| Switches | 1 × C9200L-48P-4G-E | C9200L-48P-4G-E + C9200L-24P-4G-E |
| Firewall | Sin equipo dedicado | Sin appliance remoto; seguridad central |
| Distribución WAN | MPLS y accesos ISP del escenario base | wanA: E50UG; wanB: E50UG |


| Red | VLAN | Subred | Gateway / roles |
| --- | --- | --- | --- |
| users | 10 | 10.70.5.0/25 | 10.70.5.1 |
| voice | 20 | 10.70.69.0/25 | 10.70.69.1 |
| guests | 40 | 10.70.101.0/26 | 10.70.101.1 |
| wifi_users | 110 | 10.81.5.0/25 | 10.81.5.1 |
| wifi_voice | 120 | 10.82.5.0/25 | 10.82.5.1 |
| management | 130 | 10.80.5.0/27 | 10.80.5.1 |


| Gestión | Dirección |
| --- | --- |
| sw1 | 10.80.5.1 |
| sw2 | 10.80.5.1 |
| r1 | 10.80.5.2 |
| r2 | 10.80.5.3 |
| wanA | 10.80.5.6 |
| wanB | 10.80.5.7 |
| ap1 | 10.80.5.24 |
| ap2 | 10.80.5.25 |


| Origen | Puerto | Destino | Puerto | Función | VLAN/red | Mbps | IP / agregado lógico |
| --- | --- | --- | --- | --- | --- | --- | --- |
| cpe:starlink | LAN | wanA | ether1 | WAN_ACCESS | 201 | 1000 | — |
| cpe:entel5g | LAN | wanA | ether2 | WAN_ACCESS | 203 | 1000 | — |
| r1 | GigabitEthernet0/0/0 | wanA | ether3 | WAN_TRUNK | 201, 203 | 1000 | — |
| r2 | GigabitEthernet0/0/0 | wanA | ether4 | WAN_TRUNK | 201, 203 | 1000 | — |
| wanA | ether5 | sw1 | Gi1/0/22 | MANAGEMENT_ACCESS | 130 | 1000 | — |
| cpe:leo | LAN | wanB | ether1 | WAN_ACCESS | 202 | 1000 | — |
| cpe:wom4g | LAN | wanB | ether2 | WAN_ACCESS | 204 | 1000 | — |
| r1 | GigabitEthernet0/0/1 | wanB | ether3 | WAN_TRUNK | 202, 204 | 1000 | — |
| r2 | GigabitEthernet0/0/1 | wanB | ether4 | WAN_TRUNK | 202, 204 | 1000 | — |
| wanB | ether5 | sw2 | Gi2/0/22 | MANAGEMENT_ACCESS | 130 | 1000 | — |
| r1 | GigabitEthernet0/1/0 | sw1 | Gi1/0/19 | LAN_ROUTED | 172.31.5.0/30 | 1000 | router_ip: 172.31.5.1; stack_ip: 172.31.5.2 |
| r1 | GigabitEthernet0/1/1 | sw2 | Gi2/0/19 | LAN_ROUTED | 172.31.5.4/30 | 1000 | router_ip: 172.31.5.5; stack_ip: 172.31.5.6 |
| r1 | GigabitEthernet0/1/2 | sw1 | Gi1/0/21 | MANAGEMENT_ACCESS | 130 | 1000 | — |
| r2 | GigabitEthernet0/1/0 | sw1 | Gi1/0/20 | LAN_ROUTED | 172.31.5.8/30 | 1000 | router_ip: 172.31.5.9; stack_ip: 172.31.5.10 |
| r2 | GigabitEthernet0/1/1 | sw2 | Gi2/0/20 | LAN_ROUTED | 172.31.5.12/30 | 1000 | router_ip: 172.31.5.13; stack_ip: 172.31.5.14 |
| r2 | GigabitEthernet0/1/2 | sw2 | Gi2/0/21 | MANAGEMENT_ACCESS | 130 | 1000 | — |
| ap1 | LAN | sw1 | Gi1/0/24 | AP_TRUNK | 40, 110, 120, 130 | 1000 | — |
| ap2 | LAN | sw2 | Gi2/0/24 | AP_TRUNK | 40, 110, 120, 130 | 1000 | — |
| sw1 | Stack1 | sw2 | Stack2 | STACK | — | 80000 | — |
| sw1 | Stack2 | sw2 | Stack1 | STACK | — | 80000 | — |


| Puesto | Switch | Puerto | IP PC | IP teléfono | Reserva Wi-Fi PC | Reserva Wi-Fi voz |
| --- | --- | --- | --- | --- | --- | --- |
| s05-pc01 | 1 | 1 | 10.70.5.10 | 10.70.69.10 | 10.81.5.10 | 10.82.5.10 |
| s05-pc02 | 2 | 1 | 10.70.5.11 | 10.70.69.11 | 10.81.5.11 | 10.82.5.11 |
| s05-pc03 | 1 | 2 | 10.70.5.12 | 10.70.69.12 | 10.81.5.12 | 10.82.5.12 |
| s05-pc04 | 2 | 2 | 10.70.5.13 | 10.70.69.13 | 10.81.5.13 | 10.82.5.13 |
| s05-pc05 | 1 | 3 | 10.70.5.14 | 10.70.69.14 | 10.81.5.14 | 10.82.5.14 |
| s05-pc06 | 2 | 3 | 10.70.5.15 | 10.70.69.15 | 10.81.5.15 | 10.82.5.15 |
| s05-pc07 | 1 | 4 | 10.70.5.16 | 10.70.69.16 | 10.81.5.16 | 10.82.5.16 |
| s05-pc08 | 2 | 4 | 10.70.5.17 | 10.70.69.17 | 10.81.5.17 | 10.82.5.17 |
| s05-pc09 | 1 | 5 | 10.70.5.18 | 10.70.69.18 | 10.81.5.18 | 10.82.5.18 |
| s05-pc10 | 2 | 5 | 10.70.5.19 | 10.70.69.19 | 10.81.5.19 | 10.82.5.19 |
| s05-pc11 | 1 | 6 | 10.70.5.20 | 10.70.69.20 | 10.81.5.20 | 10.82.5.20 |
| s05-pc12 | 2 | 6 | 10.70.5.21 | 10.70.69.21 | 10.81.5.21 | 10.82.5.21 |
| s05-pc13 | 1 | 7 | 10.70.5.22 | 10.70.69.22 | 10.81.5.22 | 10.82.5.22 |
| s05-pc14 | 2 | 7 | 10.70.5.23 | 10.70.69.23 | 10.81.5.23 | 10.82.5.23 |
| s05-pc15 | 1 | 8 | 10.70.5.24 | 10.70.69.24 | 10.81.5.24 | 10.82.5.24 |
| s05-pc16 | 2 | 8 | 10.70.5.25 | 10.70.69.25 | 10.81.5.25 | 10.82.5.25 |
| s05-pc17 | 1 | 9 | 10.70.5.26 | 10.70.69.26 | 10.81.5.26 | 10.82.5.26 |
| s05-pc18 | 2 | 9 | 10.70.5.27 | 10.70.69.27 | 10.81.5.27 | 10.82.5.27 |
| s05-pc19 | 1 | 10 | 10.70.5.28 | 10.70.69.28 | 10.81.5.28 | 10.82.5.28 |
| s05-pc20 | 2 | 10 | 10.70.5.29 | 10.70.69.29 | 10.81.5.29 | 10.82.5.29 |
| s05-pc21 | 1 | 11 | 10.70.5.30 | 10.70.69.30 | 10.81.5.30 | 10.82.5.30 |
| s05-pc22 | 2 | 11 | 10.70.5.31 | 10.70.69.31 | 10.81.5.31 | 10.82.5.31 |
| s05-pc23 | 1 | 12 | 10.70.5.32 | 10.70.69.32 | 10.81.5.32 | 10.82.5.32 |
| s05-pc24 | 2 | 12 | 10.70.5.33 | 10.70.69.33 | 10.81.5.33 | 10.82.5.33 |
| s05-pc25 | 1 | 13 | 10.70.5.34 | 10.70.69.34 | 10.81.5.34 | 10.82.5.34 |
| s05-pc26 | 2 | 13 | 10.70.5.35 | 10.70.69.35 | 10.81.5.35 | 10.82.5.35 |
| s05-pc27 | 1 | 14 | 10.70.5.36 | 10.70.69.36 | 10.81.5.36 | 10.82.5.36 |
| s05-pc28 | 2 | 14 | 10.70.5.37 | 10.70.69.37 | 10.81.5.37 | 10.82.5.37 |
| s05-pc29 | 1 | 15 | 10.70.5.38 | 10.70.69.38 | 10.81.5.38 | 10.82.5.38 |
| s05-pc30 | 2 | 15 | 10.70.5.39 | 10.70.69.39 | 10.81.5.39 | 10.82.5.39 |


**Transporte starlink — VLAN 201 — wanA.**

| Rol de entrega | Dirección |
| --- | --- |
| network | 10.252.5.0/29 |
| cpe | 10.252.5.1 |
| r1 | 10.252.5.2 |
| r2 | 10.252.5.3 |


**Transporte leo — VLAN 202 — wanB.**

| Rol de entrega | Dirección |
| --- | --- |
| network | 10.252.5.8/29 |
| cpe | 10.252.5.9 |
| r1 | 10.252.5.10 |
| r2 | 10.252.5.11 |


**Transporte entel5g — VLAN 203 — wanA.**

| Rol de entrega | Dirección |
| --- | --- |
| network | 10.252.5.16/29 |
| cpe | 10.252.5.17 |
| r1 | 10.252.5.18 |
| r2 | 10.252.5.19 |


**Transporte wom4g — VLAN 204 — wanB.**

| Rol de entrega | Dirección |
| --- | --- |
| network | 10.252.5.24/29 |
| cpe | 10.252.5.25 |
| r1 | 10.252.5.26 |
| r2 | 10.252.5.27 |


**Reservas de túneles (numeración según lista de la ficha).**

| Rol / candidato | Dirección |
| --- | --- |
| .1.hub_public_ip | 198.51.100.4 |
| .1.network | 10.253.5.0/30 |
| .1.branch_ip | 10.253.5.1 |
| .1.hub_ip | 10.253.5.2 |
| .2.hub_public_ip | 203.0.113.4 |
| .2.network | 10.253.5.4/30 |
| .2.branch_ip | 10.253.5.5 |
| .2.hub_ip | 10.253.5.6 |
| .3.hub_public_ip | 198.51.100.4 |
| .3.network | 10.253.5.8/30 |
| .3.branch_ip | 10.253.5.9 |
| .3.hub_ip | 10.253.5.10 |
| .4.hub_public_ip | 203.0.113.4 |
| .4.network | 10.253.5.12/30 |
| .4.branch_ip | 10.253.5.13 |
| .4.hub_ip | 10.253.5.14 |
| .5.hub_public_ip | 198.51.100.4 |
| .5.network | 10.253.5.16/30 |
| .5.branch_ip | 10.253.5.17 |
| .5.hub_ip | 10.253.5.18 |
| .6.hub_public_ip | 203.0.113.4 |
| .6.network | 10.253.5.20/30 |
| .6.branch_ip | 10.253.5.21 |
| .6.hub_ip | 10.253.5.22 |
| .7.hub_public_ip | 198.51.100.4 |
| .7.network | 10.253.5.24/30 |
| .7.branch_ip | 10.253.5.25 |
| .7.hub_ip | 10.253.5.26 |
| .8.hub_public_ip | 203.0.113.4 |
| .8.network | 10.253.5.28/30 |
| .8.branch_ip | 10.253.5.29 |
| .8.hub_ip | 10.253.5.30 |
| .9.hub_public_ip | 198.51.100.4 |
| .9.network | 10.253.5.32/30 |
| .9.branch_ip | 10.253.5.33 |
| .9.hub_ip | 10.253.5.34 |
| .10.hub_public_ip | 203.0.113.4 |
| .10.network | 10.253.5.36/30 |
| .10.branch_ip | 10.253.5.37 |
| .10.hub_ip | 10.253.5.38 |
| .11.hub_public_ip | 198.51.100.4 |
| .11.network | 10.253.5.40/30 |
| .11.branch_ip | 10.253.5.41 |
| .11.hub_ip | 10.253.5.42 |
| .12.hub_public_ip | 203.0.113.4 |
| .12.network | 10.253.5.44/30 |
| .12.branch_ip | 10.253.5.45 |
| .12.hub_ip | 10.253.5.46 |
| .13.hub_public_ip | 198.51.100.4 |
| .13.network | 10.253.5.48/30 |
| .13.branch_ip | 10.253.5.49 |
| .13.hub_ip | 10.253.5.50 |
| .14.hub_public_ip | 203.0.113.4 |
| .14.network | 10.253.5.52/30 |
| .14.branch_ip | 10.253.5.53 |
| .14.hub_ip | 10.253.5.54 |
| .15.hub_public_ip | 198.51.100.4 |
| .15.network | 10.253.5.56/30 |
| .15.branch_ip | 10.253.5.57 |
| .15.hub_ip | 10.253.5.58 |
| .16.hub_public_ip | 203.0.113.4 |
| .16.network | 10.253.5.60/30 |
| .16.branch_ip | 10.253.5.61 |
| .16.hub_ip | 10.253.5.62 |

### S06 — Arica

28 PCs y 28 teléfonos existentes.

| Función | ANTES | DESPUÉS |
| --- | --- | --- |
| Routers | 1 × ISR4321/K9 | 2 × C1121X-8P |
| Switches | 1 × C9200L-48P-4G-E | C9200L-48P-4G-E + C9200L-24P-4G-E |
| Firewall | Sin equipo dedicado | Sin appliance remoto; seguridad central |
| Distribución WAN | MPLS y accesos ISP del escenario base | wanA: E50UG; wanB: E50UG |


| Red | VLAN | Subred | Gateway / roles |
| --- | --- | --- | --- |
| users | 10 | 10.70.6.0/25 | 10.70.6.1 |
| voice | 20 | 10.70.70.0/25 | 10.70.70.1 |
| guests | 40 | 10.70.102.0/26 | 10.70.102.1 |
| wifi_users | 110 | 10.81.6.0/25 | 10.81.6.1 |
| wifi_voice | 120 | 10.82.6.0/25 | 10.82.6.1 |
| management | 130 | 10.80.6.0/27 | 10.80.6.1 |


| Gestión | Dirección |
| --- | --- |
| sw1 | 10.80.6.1 |
| sw2 | 10.80.6.1 |
| r1 | 10.80.6.2 |
| r2 | 10.80.6.3 |
| wanA | 10.80.6.6 |
| wanB | 10.80.6.7 |
| ap1 | 10.80.6.24 |
| ap2 | 10.80.6.25 |


| Origen | Puerto | Destino | Puerto | Función | VLAN/red | Mbps | IP / agregado lógico |
| --- | --- | --- | --- | --- | --- | --- | --- |
| cpe:starlink | LAN | wanA | ether1 | WAN_ACCESS | 201 | 1000 | — |
| cpe:entel5g | LAN | wanA | ether2 | WAN_ACCESS | 203 | 1000 | — |
| r1 | GigabitEthernet0/0/0 | wanA | ether3 | WAN_TRUNK | 201, 203 | 1000 | — |
| r2 | GigabitEthernet0/0/0 | wanA | ether4 | WAN_TRUNK | 201, 203 | 1000 | — |
| wanA | ether5 | sw1 | Gi1/0/22 | MANAGEMENT_ACCESS | 130 | 1000 | — |
| cpe:leo | LAN | wanB | ether1 | WAN_ACCESS | 202 | 1000 | — |
| cpe:wom4g | LAN | wanB | ether2 | WAN_ACCESS | 204 | 1000 | — |
| r1 | GigabitEthernet0/0/1 | wanB | ether3 | WAN_TRUNK | 202, 204 | 1000 | — |
| r2 | GigabitEthernet0/0/1 | wanB | ether4 | WAN_TRUNK | 202, 204 | 1000 | — |
| wanB | ether5 | sw2 | Gi2/0/22 | MANAGEMENT_ACCESS | 130 | 1000 | — |
| r1 | GigabitEthernet0/1/0 | sw1 | Gi1/0/19 | LAN_ROUTED | 172.31.6.0/30 | 1000 | router_ip: 172.31.6.1; stack_ip: 172.31.6.2 |
| r1 | GigabitEthernet0/1/1 | sw2 | Gi2/0/19 | LAN_ROUTED | 172.31.6.4/30 | 1000 | router_ip: 172.31.6.5; stack_ip: 172.31.6.6 |
| r1 | GigabitEthernet0/1/2 | sw1 | Gi1/0/21 | MANAGEMENT_ACCESS | 130 | 1000 | — |
| r2 | GigabitEthernet0/1/0 | sw1 | Gi1/0/20 | LAN_ROUTED | 172.31.6.8/30 | 1000 | router_ip: 172.31.6.9; stack_ip: 172.31.6.10 |
| r2 | GigabitEthernet0/1/1 | sw2 | Gi2/0/20 | LAN_ROUTED | 172.31.6.12/30 | 1000 | router_ip: 172.31.6.13; stack_ip: 172.31.6.14 |
| r2 | GigabitEthernet0/1/2 | sw2 | Gi2/0/21 | MANAGEMENT_ACCESS | 130 | 1000 | — |
| ap1 | LAN | sw1 | Gi1/0/24 | AP_TRUNK | 40, 110, 120, 130 | 1000 | — |
| ap2 | LAN | sw2 | Gi2/0/24 | AP_TRUNK | 40, 110, 120, 130 | 1000 | — |
| sw1 | Stack1 | sw2 | Stack2 | STACK | — | 80000 | — |
| sw1 | Stack2 | sw2 | Stack1 | STACK | — | 80000 | — |


| Puesto | Switch | Puerto | IP PC | IP teléfono | Reserva Wi-Fi PC | Reserva Wi-Fi voz |
| --- | --- | --- | --- | --- | --- | --- |
| s06-pc01 | 1 | 1 | 10.70.6.10 | 10.70.70.10 | 10.81.6.10 | 10.82.6.10 |
| s06-pc02 | 2 | 1 | 10.70.6.11 | 10.70.70.11 | 10.81.6.11 | 10.82.6.11 |
| s06-pc03 | 1 | 2 | 10.70.6.12 | 10.70.70.12 | 10.81.6.12 | 10.82.6.12 |
| s06-pc04 | 2 | 2 | 10.70.6.13 | 10.70.70.13 | 10.81.6.13 | 10.82.6.13 |
| s06-pc05 | 1 | 3 | 10.70.6.14 | 10.70.70.14 | 10.81.6.14 | 10.82.6.14 |
| s06-pc06 | 2 | 3 | 10.70.6.15 | 10.70.70.15 | 10.81.6.15 | 10.82.6.15 |
| s06-pc07 | 1 | 4 | 10.70.6.16 | 10.70.70.16 | 10.81.6.16 | 10.82.6.16 |
| s06-pc08 | 2 | 4 | 10.70.6.17 | 10.70.70.17 | 10.81.6.17 | 10.82.6.17 |
| s06-pc09 | 1 | 5 | 10.70.6.18 | 10.70.70.18 | 10.81.6.18 | 10.82.6.18 |
| s06-pc10 | 2 | 5 | 10.70.6.19 | 10.70.70.19 | 10.81.6.19 | 10.82.6.19 |
| s06-pc11 | 1 | 6 | 10.70.6.20 | 10.70.70.20 | 10.81.6.20 | 10.82.6.20 |
| s06-pc12 | 2 | 6 | 10.70.6.21 | 10.70.70.21 | 10.81.6.21 | 10.82.6.21 |
| s06-pc13 | 1 | 7 | 10.70.6.22 | 10.70.70.22 | 10.81.6.22 | 10.82.6.22 |
| s06-pc14 | 2 | 7 | 10.70.6.23 | 10.70.70.23 | 10.81.6.23 | 10.82.6.23 |
| s06-pc15 | 1 | 8 | 10.70.6.24 | 10.70.70.24 | 10.81.6.24 | 10.82.6.24 |
| s06-pc16 | 2 | 8 | 10.70.6.25 | 10.70.70.25 | 10.81.6.25 | 10.82.6.25 |
| s06-pc17 | 1 | 9 | 10.70.6.26 | 10.70.70.26 | 10.81.6.26 | 10.82.6.26 |
| s06-pc18 | 2 | 9 | 10.70.6.27 | 10.70.70.27 | 10.81.6.27 | 10.82.6.27 |
| s06-pc19 | 1 | 10 | 10.70.6.28 | 10.70.70.28 | 10.81.6.28 | 10.82.6.28 |
| s06-pc20 | 2 | 10 | 10.70.6.29 | 10.70.70.29 | 10.81.6.29 | 10.82.6.29 |
| s06-pc21 | 1 | 11 | 10.70.6.30 | 10.70.70.30 | 10.81.6.30 | 10.82.6.30 |
| s06-pc22 | 2 | 11 | 10.70.6.31 | 10.70.70.31 | 10.81.6.31 | 10.82.6.31 |
| s06-pc23 | 1 | 12 | 10.70.6.32 | 10.70.70.32 | 10.81.6.32 | 10.82.6.32 |
| s06-pc24 | 2 | 12 | 10.70.6.33 | 10.70.70.33 | 10.81.6.33 | 10.82.6.33 |
| s06-pc25 | 1 | 13 | 10.70.6.34 | 10.70.70.34 | 10.81.6.34 | 10.82.6.34 |
| s06-pc26 | 2 | 13 | 10.70.6.35 | 10.70.70.35 | 10.81.6.35 | 10.82.6.35 |
| s06-pc27 | 1 | 14 | 10.70.6.36 | 10.70.70.36 | 10.81.6.36 | 10.82.6.36 |
| s06-pc28 | 2 | 14 | 10.70.6.37 | 10.70.70.37 | 10.81.6.37 | 10.82.6.37 |


**Transporte starlink — VLAN 201 — wanA.**

| Rol de entrega | Dirección |
| --- | --- |
| network | 10.252.6.0/29 |
| cpe | 10.252.6.1 |
| r1 | 10.252.6.2 |
| r2 | 10.252.6.3 |


**Transporte leo — VLAN 202 — wanB.**

| Rol de entrega | Dirección |
| --- | --- |
| network | 10.252.6.8/29 |
| cpe | 10.252.6.9 |
| r1 | 10.252.6.10 |
| r2 | 10.252.6.11 |


**Transporte entel5g — VLAN 203 — wanA.**

| Rol de entrega | Dirección |
| --- | --- |
| network | 10.252.6.16/29 |
| cpe | 10.252.6.17 |
| r1 | 10.252.6.18 |
| r2 | 10.252.6.19 |


**Transporte wom4g — VLAN 204 — wanB.**

| Rol de entrega | Dirección |
| --- | --- |
| network | 10.252.6.24/29 |
| cpe | 10.252.6.25 |
| r1 | 10.252.6.26 |
| r2 | 10.252.6.27 |


**Reservas de túneles (numeración según lista de la ficha).**

| Rol / candidato | Dirección |
| --- | --- |
| .1.hub_public_ip | 198.51.100.4 |
| .1.network | 10.253.6.0/30 |
| .1.branch_ip | 10.253.6.1 |
| .1.hub_ip | 10.253.6.2 |
| .2.hub_public_ip | 203.0.113.4 |
| .2.network | 10.253.6.4/30 |
| .2.branch_ip | 10.253.6.5 |
| .2.hub_ip | 10.253.6.6 |
| .3.hub_public_ip | 198.51.100.4 |
| .3.network | 10.253.6.8/30 |
| .3.branch_ip | 10.253.6.9 |
| .3.hub_ip | 10.253.6.10 |
| .4.hub_public_ip | 203.0.113.4 |
| .4.network | 10.253.6.12/30 |
| .4.branch_ip | 10.253.6.13 |
| .4.hub_ip | 10.253.6.14 |
| .5.hub_public_ip | 198.51.100.4 |
| .5.network | 10.253.6.16/30 |
| .5.branch_ip | 10.253.6.17 |
| .5.hub_ip | 10.253.6.18 |
| .6.hub_public_ip | 203.0.113.4 |
| .6.network | 10.253.6.20/30 |
| .6.branch_ip | 10.253.6.21 |
| .6.hub_ip | 10.253.6.22 |
| .7.hub_public_ip | 198.51.100.4 |
| .7.network | 10.253.6.24/30 |
| .7.branch_ip | 10.253.6.25 |
| .7.hub_ip | 10.253.6.26 |
| .8.hub_public_ip | 203.0.113.4 |
| .8.network | 10.253.6.28/30 |
| .8.branch_ip | 10.253.6.29 |
| .8.hub_ip | 10.253.6.30 |
| .9.hub_public_ip | 198.51.100.4 |
| .9.network | 10.253.6.32/30 |
| .9.branch_ip | 10.253.6.33 |
| .9.hub_ip | 10.253.6.34 |
| .10.hub_public_ip | 203.0.113.4 |
| .10.network | 10.253.6.36/30 |
| .10.branch_ip | 10.253.6.37 |
| .10.hub_ip | 10.253.6.38 |
| .11.hub_public_ip | 198.51.100.4 |
| .11.network | 10.253.6.40/30 |
| .11.branch_ip | 10.253.6.41 |
| .11.hub_ip | 10.253.6.42 |
| .12.hub_public_ip | 203.0.113.4 |
| .12.network | 10.253.6.44/30 |
| .12.branch_ip | 10.253.6.45 |
| .12.hub_ip | 10.253.6.46 |
| .13.hub_public_ip | 198.51.100.4 |
| .13.network | 10.253.6.48/30 |
| .13.branch_ip | 10.253.6.49 |
| .13.hub_ip | 10.253.6.50 |
| .14.hub_public_ip | 203.0.113.4 |
| .14.network | 10.253.6.52/30 |
| .14.branch_ip | 10.253.6.53 |
| .14.hub_ip | 10.253.6.54 |
| .15.hub_public_ip | 198.51.100.4 |
| .15.network | 10.253.6.56/30 |
| .15.branch_ip | 10.253.6.57 |
| .15.hub_ip | 10.253.6.58 |
| .16.hub_public_ip | 203.0.113.4 |
| .16.network | 10.253.6.60/30 |
| .16.branch_ip | 10.253.6.61 |
| .16.hub_ip | 10.253.6.62 |

### S07 — Iquique

28 PCs y 28 teléfonos existentes.

| Función | ANTES | DESPUÉS |
| --- | --- | --- |
| Routers | 1 × ISR4321/K9 | 2 × C1121X-8P |
| Switches | 1 × C9200L-48P-4G-E | C9200L-48P-4G-E + C9200L-24P-4G-E |
| Firewall | Sin equipo dedicado | Sin appliance remoto; seguridad central |
| Distribución WAN | MPLS y accesos ISP del escenario base | wanA: E50UG; wanB: E50UG |


| Red | VLAN | Subred | Gateway / roles |
| --- | --- | --- | --- |
| users | 10 | 10.70.7.0/25 | 10.70.7.1 |
| voice | 20 | 10.70.71.0/25 | 10.70.71.1 |
| guests | 40 | 10.70.103.0/26 | 10.70.103.1 |
| wifi_users | 110 | 10.81.7.0/25 | 10.81.7.1 |
| wifi_voice | 120 | 10.82.7.0/25 | 10.82.7.1 |
| management | 130 | 10.80.7.0/27 | 10.80.7.1 |


| Gestión | Dirección |
| --- | --- |
| sw1 | 10.80.7.1 |
| sw2 | 10.80.7.1 |
| r1 | 10.80.7.2 |
| r2 | 10.80.7.3 |
| wanA | 10.80.7.6 |
| wanB | 10.80.7.7 |
| ap1 | 10.80.7.24 |
| ap2 | 10.80.7.25 |


| Origen | Puerto | Destino | Puerto | Función | VLAN/red | Mbps | IP / agregado lógico |
| --- | --- | --- | --- | --- | --- | --- | --- |
| cpe:starlink | LAN | wanA | ether1 | WAN_ACCESS | 201 | 1000 | — |
| cpe:entel5g | LAN | wanA | ether2 | WAN_ACCESS | 203 | 1000 | — |
| r1 | GigabitEthernet0/0/0 | wanA | ether3 | WAN_TRUNK | 201, 203 | 1000 | — |
| r2 | GigabitEthernet0/0/0 | wanA | ether4 | WAN_TRUNK | 201, 203 | 1000 | — |
| wanA | ether5 | sw1 | Gi1/0/22 | MANAGEMENT_ACCESS | 130 | 1000 | — |
| cpe:leo | LAN | wanB | ether1 | WAN_ACCESS | 202 | 1000 | — |
| cpe:wom4g | LAN | wanB | ether2 | WAN_ACCESS | 204 | 1000 | — |
| r1 | GigabitEthernet0/0/1 | wanB | ether3 | WAN_TRUNK | 202, 204 | 1000 | — |
| r2 | GigabitEthernet0/0/1 | wanB | ether4 | WAN_TRUNK | 202, 204 | 1000 | — |
| wanB | ether5 | sw2 | Gi2/0/22 | MANAGEMENT_ACCESS | 130 | 1000 | — |
| r1 | GigabitEthernet0/1/0 | sw1 | Gi1/0/19 | LAN_ROUTED | 172.31.7.0/30 | 1000 | router_ip: 172.31.7.1; stack_ip: 172.31.7.2 |
| r1 | GigabitEthernet0/1/1 | sw2 | Gi2/0/19 | LAN_ROUTED | 172.31.7.4/30 | 1000 | router_ip: 172.31.7.5; stack_ip: 172.31.7.6 |
| r1 | GigabitEthernet0/1/2 | sw1 | Gi1/0/21 | MANAGEMENT_ACCESS | 130 | 1000 | — |
| r2 | GigabitEthernet0/1/0 | sw1 | Gi1/0/20 | LAN_ROUTED | 172.31.7.8/30 | 1000 | router_ip: 172.31.7.9; stack_ip: 172.31.7.10 |
| r2 | GigabitEthernet0/1/1 | sw2 | Gi2/0/20 | LAN_ROUTED | 172.31.7.12/30 | 1000 | router_ip: 172.31.7.13; stack_ip: 172.31.7.14 |
| r2 | GigabitEthernet0/1/2 | sw2 | Gi2/0/21 | MANAGEMENT_ACCESS | 130 | 1000 | — |
| ap1 | LAN | sw1 | Gi1/0/24 | AP_TRUNK | 40, 110, 120, 130 | 1000 | — |
| ap2 | LAN | sw2 | Gi2/0/24 | AP_TRUNK | 40, 110, 120, 130 | 1000 | — |
| sw1 | Stack1 | sw2 | Stack2 | STACK | — | 80000 | — |
| sw1 | Stack2 | sw2 | Stack1 | STACK | — | 80000 | — |


| Puesto | Switch | Puerto | IP PC | IP teléfono | Reserva Wi-Fi PC | Reserva Wi-Fi voz |
| --- | --- | --- | --- | --- | --- | --- |
| s07-pc01 | 1 | 1 | 10.70.7.10 | 10.70.71.10 | 10.81.7.10 | 10.82.7.10 |
| s07-pc02 | 2 | 1 | 10.70.7.11 | 10.70.71.11 | 10.81.7.11 | 10.82.7.11 |
| s07-pc03 | 1 | 2 | 10.70.7.12 | 10.70.71.12 | 10.81.7.12 | 10.82.7.12 |
| s07-pc04 | 2 | 2 | 10.70.7.13 | 10.70.71.13 | 10.81.7.13 | 10.82.7.13 |
| s07-pc05 | 1 | 3 | 10.70.7.14 | 10.70.71.14 | 10.81.7.14 | 10.82.7.14 |
| s07-pc06 | 2 | 3 | 10.70.7.15 | 10.70.71.15 | 10.81.7.15 | 10.82.7.15 |
| s07-pc07 | 1 | 4 | 10.70.7.16 | 10.70.71.16 | 10.81.7.16 | 10.82.7.16 |
| s07-pc08 | 2 | 4 | 10.70.7.17 | 10.70.71.17 | 10.81.7.17 | 10.82.7.17 |
| s07-pc09 | 1 | 5 | 10.70.7.18 | 10.70.71.18 | 10.81.7.18 | 10.82.7.18 |
| s07-pc10 | 2 | 5 | 10.70.7.19 | 10.70.71.19 | 10.81.7.19 | 10.82.7.19 |
| s07-pc11 | 1 | 6 | 10.70.7.20 | 10.70.71.20 | 10.81.7.20 | 10.82.7.20 |
| s07-pc12 | 2 | 6 | 10.70.7.21 | 10.70.71.21 | 10.81.7.21 | 10.82.7.21 |
| s07-pc13 | 1 | 7 | 10.70.7.22 | 10.70.71.22 | 10.81.7.22 | 10.82.7.22 |
| s07-pc14 | 2 | 7 | 10.70.7.23 | 10.70.71.23 | 10.81.7.23 | 10.82.7.23 |
| s07-pc15 | 1 | 8 | 10.70.7.24 | 10.70.71.24 | 10.81.7.24 | 10.82.7.24 |
| s07-pc16 | 2 | 8 | 10.70.7.25 | 10.70.71.25 | 10.81.7.25 | 10.82.7.25 |
| s07-pc17 | 1 | 9 | 10.70.7.26 | 10.70.71.26 | 10.81.7.26 | 10.82.7.26 |
| s07-pc18 | 2 | 9 | 10.70.7.27 | 10.70.71.27 | 10.81.7.27 | 10.82.7.27 |
| s07-pc19 | 1 | 10 | 10.70.7.28 | 10.70.71.28 | 10.81.7.28 | 10.82.7.28 |
| s07-pc20 | 2 | 10 | 10.70.7.29 | 10.70.71.29 | 10.81.7.29 | 10.82.7.29 |
| s07-pc21 | 1 | 11 | 10.70.7.30 | 10.70.71.30 | 10.81.7.30 | 10.82.7.30 |
| s07-pc22 | 2 | 11 | 10.70.7.31 | 10.70.71.31 | 10.81.7.31 | 10.82.7.31 |
| s07-pc23 | 1 | 12 | 10.70.7.32 | 10.70.71.32 | 10.81.7.32 | 10.82.7.32 |
| s07-pc24 | 2 | 12 | 10.70.7.33 | 10.70.71.33 | 10.81.7.33 | 10.82.7.33 |
| s07-pc25 | 1 | 13 | 10.70.7.34 | 10.70.71.34 | 10.81.7.34 | 10.82.7.34 |
| s07-pc26 | 2 | 13 | 10.70.7.35 | 10.70.71.35 | 10.81.7.35 | 10.82.7.35 |
| s07-pc27 | 1 | 14 | 10.70.7.36 | 10.70.71.36 | 10.81.7.36 | 10.82.7.36 |
| s07-pc28 | 2 | 14 | 10.70.7.37 | 10.70.71.37 | 10.81.7.37 | 10.82.7.37 |


**Transporte starlink — VLAN 201 — wanA.**

| Rol de entrega | Dirección |
| --- | --- |
| network | 10.252.7.0/29 |
| cpe | 10.252.7.1 |
| r1 | 10.252.7.2 |
| r2 | 10.252.7.3 |


**Transporte leo — VLAN 202 — wanB.**

| Rol de entrega | Dirección |
| --- | --- |
| network | 10.252.7.8/29 |
| cpe | 10.252.7.9 |
| r1 | 10.252.7.10 |
| r2 | 10.252.7.11 |


**Transporte entel5g — VLAN 203 — wanA.**

| Rol de entrega | Dirección |
| --- | --- |
| network | 10.252.7.16/29 |
| cpe | 10.252.7.17 |
| r1 | 10.252.7.18 |
| r2 | 10.252.7.19 |


**Transporte wom4g — VLAN 204 — wanB.**

| Rol de entrega | Dirección |
| --- | --- |
| network | 10.252.7.24/29 |
| cpe | 10.252.7.25 |
| r1 | 10.252.7.26 |
| r2 | 10.252.7.27 |


**Reservas de túneles (numeración según lista de la ficha).**

| Rol / candidato | Dirección |
| --- | --- |
| .1.hub_public_ip | 198.51.100.4 |
| .1.network | 10.253.7.0/30 |
| .1.branch_ip | 10.253.7.1 |
| .1.hub_ip | 10.253.7.2 |
| .2.hub_public_ip | 203.0.113.4 |
| .2.network | 10.253.7.4/30 |
| .2.branch_ip | 10.253.7.5 |
| .2.hub_ip | 10.253.7.6 |
| .3.hub_public_ip | 198.51.100.4 |
| .3.network | 10.253.7.8/30 |
| .3.branch_ip | 10.253.7.9 |
| .3.hub_ip | 10.253.7.10 |
| .4.hub_public_ip | 203.0.113.4 |
| .4.network | 10.253.7.12/30 |
| .4.branch_ip | 10.253.7.13 |
| .4.hub_ip | 10.253.7.14 |
| .5.hub_public_ip | 198.51.100.4 |
| .5.network | 10.253.7.16/30 |
| .5.branch_ip | 10.253.7.17 |
| .5.hub_ip | 10.253.7.18 |
| .6.hub_public_ip | 203.0.113.4 |
| .6.network | 10.253.7.20/30 |
| .6.branch_ip | 10.253.7.21 |
| .6.hub_ip | 10.253.7.22 |
| .7.hub_public_ip | 198.51.100.4 |
| .7.network | 10.253.7.24/30 |
| .7.branch_ip | 10.253.7.25 |
| .7.hub_ip | 10.253.7.26 |
| .8.hub_public_ip | 203.0.113.4 |
| .8.network | 10.253.7.28/30 |
| .8.branch_ip | 10.253.7.29 |
| .8.hub_ip | 10.253.7.30 |
| .9.hub_public_ip | 198.51.100.4 |
| .9.network | 10.253.7.32/30 |
| .9.branch_ip | 10.253.7.33 |
| .9.hub_ip | 10.253.7.34 |
| .10.hub_public_ip | 203.0.113.4 |
| .10.network | 10.253.7.36/30 |
| .10.branch_ip | 10.253.7.37 |
| .10.hub_ip | 10.253.7.38 |
| .11.hub_public_ip | 198.51.100.4 |
| .11.network | 10.253.7.40/30 |
| .11.branch_ip | 10.253.7.41 |
| .11.hub_ip | 10.253.7.42 |
| .12.hub_public_ip | 203.0.113.4 |
| .12.network | 10.253.7.44/30 |
| .12.branch_ip | 10.253.7.45 |
| .12.hub_ip | 10.253.7.46 |
| .13.hub_public_ip | 198.51.100.4 |
| .13.network | 10.253.7.48/30 |
| .13.branch_ip | 10.253.7.49 |
| .13.hub_ip | 10.253.7.50 |
| .14.hub_public_ip | 203.0.113.4 |
| .14.network | 10.253.7.52/30 |
| .14.branch_ip | 10.253.7.53 |
| .14.hub_ip | 10.253.7.54 |
| .15.hub_public_ip | 198.51.100.4 |
| .15.network | 10.253.7.56/30 |
| .15.branch_ip | 10.253.7.57 |
| .15.hub_ip | 10.253.7.58 |
| .16.hub_public_ip | 203.0.113.4 |
| .16.network | 10.253.7.60/30 |
| .16.branch_ip | 10.253.7.61 |
| .16.hub_ip | 10.253.7.62 |

### S08 — Antofagasta

28 PCs y 28 teléfonos existentes.

| Función | ANTES | DESPUÉS |
| --- | --- | --- |
| Routers | 1 × ISR4321/K9 | 2 × C1121X-8P |
| Switches | 1 × C9200L-48P-4G-E | C9200L-48P-4G-E + C9200L-24P-4G-E |
| Firewall | Sin equipo dedicado | Sin appliance remoto; seguridad central |
| Distribución WAN | MPLS y accesos ISP del escenario base | wanA: E50UG; wanB: E50UG |


| Red | VLAN | Subred | Gateway / roles |
| --- | --- | --- | --- |
| users | 10 | 10.70.8.0/25 | 10.70.8.1 |
| voice | 20 | 10.70.72.0/25 | 10.70.72.1 |
| guests | 40 | 10.70.104.0/26 | 10.70.104.1 |
| wifi_users | 110 | 10.81.8.0/25 | 10.81.8.1 |
| wifi_voice | 120 | 10.82.8.0/25 | 10.82.8.1 |
| management | 130 | 10.80.8.0/27 | 10.80.8.1 |


| Gestión | Dirección |
| --- | --- |
| sw1 | 10.80.8.1 |
| sw2 | 10.80.8.1 |
| r1 | 10.80.8.2 |
| r2 | 10.80.8.3 |
| wanA | 10.80.8.6 |
| wanB | 10.80.8.7 |
| ap1 | 10.80.8.24 |
| ap2 | 10.80.8.25 |


| Origen | Puerto | Destino | Puerto | Función | VLAN/red | Mbps | IP / agregado lógico |
| --- | --- | --- | --- | --- | --- | --- | --- |
| cpe:starlink | LAN | wanA | ether1 | WAN_ACCESS | 201 | 1000 | — |
| cpe:entel5g | LAN | wanA | ether2 | WAN_ACCESS | 203 | 1000 | — |
| r1 | GigabitEthernet0/0/0 | wanA | ether3 | WAN_TRUNK | 201, 203 | 1000 | — |
| r2 | GigabitEthernet0/0/0 | wanA | ether4 | WAN_TRUNK | 201, 203 | 1000 | — |
| wanA | ether5 | sw1 | Gi1/0/22 | MANAGEMENT_ACCESS | 130 | 1000 | — |
| cpe:leo | LAN | wanB | ether1 | WAN_ACCESS | 202 | 1000 | — |
| cpe:wom4g | LAN | wanB | ether2 | WAN_ACCESS | 204 | 1000 | — |
| r1 | GigabitEthernet0/0/1 | wanB | ether3 | WAN_TRUNK | 202, 204 | 1000 | — |
| r2 | GigabitEthernet0/0/1 | wanB | ether4 | WAN_TRUNK | 202, 204 | 1000 | — |
| wanB | ether5 | sw2 | Gi2/0/22 | MANAGEMENT_ACCESS | 130 | 1000 | — |
| r1 | GigabitEthernet0/1/0 | sw1 | Gi1/0/19 | LAN_ROUTED | 172.31.8.0/30 | 1000 | router_ip: 172.31.8.1; stack_ip: 172.31.8.2 |
| r1 | GigabitEthernet0/1/1 | sw2 | Gi2/0/19 | LAN_ROUTED | 172.31.8.4/30 | 1000 | router_ip: 172.31.8.5; stack_ip: 172.31.8.6 |
| r1 | GigabitEthernet0/1/2 | sw1 | Gi1/0/21 | MANAGEMENT_ACCESS | 130 | 1000 | — |
| r2 | GigabitEthernet0/1/0 | sw1 | Gi1/0/20 | LAN_ROUTED | 172.31.8.8/30 | 1000 | router_ip: 172.31.8.9; stack_ip: 172.31.8.10 |
| r2 | GigabitEthernet0/1/1 | sw2 | Gi2/0/20 | LAN_ROUTED | 172.31.8.12/30 | 1000 | router_ip: 172.31.8.13; stack_ip: 172.31.8.14 |
| r2 | GigabitEthernet0/1/2 | sw2 | Gi2/0/21 | MANAGEMENT_ACCESS | 130 | 1000 | — |
| ap1 | LAN | sw1 | Gi1/0/24 | AP_TRUNK | 40, 110, 120, 130 | 1000 | — |
| ap2 | LAN | sw2 | Gi2/0/24 | AP_TRUNK | 40, 110, 120, 130 | 1000 | — |
| sw1 | Stack1 | sw2 | Stack2 | STACK | — | 80000 | — |
| sw1 | Stack2 | sw2 | Stack1 | STACK | — | 80000 | — |


| Puesto | Switch | Puerto | IP PC | IP teléfono | Reserva Wi-Fi PC | Reserva Wi-Fi voz |
| --- | --- | --- | --- | --- | --- | --- |
| s08-pc01 | 1 | 1 | 10.70.8.10 | 10.70.72.10 | 10.81.8.10 | 10.82.8.10 |
| s08-pc02 | 2 | 1 | 10.70.8.11 | 10.70.72.11 | 10.81.8.11 | 10.82.8.11 |
| s08-pc03 | 1 | 2 | 10.70.8.12 | 10.70.72.12 | 10.81.8.12 | 10.82.8.12 |
| s08-pc04 | 2 | 2 | 10.70.8.13 | 10.70.72.13 | 10.81.8.13 | 10.82.8.13 |
| s08-pc05 | 1 | 3 | 10.70.8.14 | 10.70.72.14 | 10.81.8.14 | 10.82.8.14 |
| s08-pc06 | 2 | 3 | 10.70.8.15 | 10.70.72.15 | 10.81.8.15 | 10.82.8.15 |
| s08-pc07 | 1 | 4 | 10.70.8.16 | 10.70.72.16 | 10.81.8.16 | 10.82.8.16 |
| s08-pc08 | 2 | 4 | 10.70.8.17 | 10.70.72.17 | 10.81.8.17 | 10.82.8.17 |
| s08-pc09 | 1 | 5 | 10.70.8.18 | 10.70.72.18 | 10.81.8.18 | 10.82.8.18 |
| s08-pc10 | 2 | 5 | 10.70.8.19 | 10.70.72.19 | 10.81.8.19 | 10.82.8.19 |
| s08-pc11 | 1 | 6 | 10.70.8.20 | 10.70.72.20 | 10.81.8.20 | 10.82.8.20 |
| s08-pc12 | 2 | 6 | 10.70.8.21 | 10.70.72.21 | 10.81.8.21 | 10.82.8.21 |
| s08-pc13 | 1 | 7 | 10.70.8.22 | 10.70.72.22 | 10.81.8.22 | 10.82.8.22 |
| s08-pc14 | 2 | 7 | 10.70.8.23 | 10.70.72.23 | 10.81.8.23 | 10.82.8.23 |
| s08-pc15 | 1 | 8 | 10.70.8.24 | 10.70.72.24 | 10.81.8.24 | 10.82.8.24 |
| s08-pc16 | 2 | 8 | 10.70.8.25 | 10.70.72.25 | 10.81.8.25 | 10.82.8.25 |
| s08-pc17 | 1 | 9 | 10.70.8.26 | 10.70.72.26 | 10.81.8.26 | 10.82.8.26 |
| s08-pc18 | 2 | 9 | 10.70.8.27 | 10.70.72.27 | 10.81.8.27 | 10.82.8.27 |
| s08-pc19 | 1 | 10 | 10.70.8.28 | 10.70.72.28 | 10.81.8.28 | 10.82.8.28 |
| s08-pc20 | 2 | 10 | 10.70.8.29 | 10.70.72.29 | 10.81.8.29 | 10.82.8.29 |
| s08-pc21 | 1 | 11 | 10.70.8.30 | 10.70.72.30 | 10.81.8.30 | 10.82.8.30 |
| s08-pc22 | 2 | 11 | 10.70.8.31 | 10.70.72.31 | 10.81.8.31 | 10.82.8.31 |
| s08-pc23 | 1 | 12 | 10.70.8.32 | 10.70.72.32 | 10.81.8.32 | 10.82.8.32 |
| s08-pc24 | 2 | 12 | 10.70.8.33 | 10.70.72.33 | 10.81.8.33 | 10.82.8.33 |
| s08-pc25 | 1 | 13 | 10.70.8.34 | 10.70.72.34 | 10.81.8.34 | 10.82.8.34 |
| s08-pc26 | 2 | 13 | 10.70.8.35 | 10.70.72.35 | 10.81.8.35 | 10.82.8.35 |
| s08-pc27 | 1 | 14 | 10.70.8.36 | 10.70.72.36 | 10.81.8.36 | 10.82.8.36 |
| s08-pc28 | 2 | 14 | 10.70.8.37 | 10.70.72.37 | 10.81.8.37 | 10.82.8.37 |


**Transporte starlink — VLAN 201 — wanA.**

| Rol de entrega | Dirección |
| --- | --- |
| network | 10.252.8.0/29 |
| cpe | 10.252.8.1 |
| r1 | 10.252.8.2 |
| r2 | 10.252.8.3 |


**Transporte leo — VLAN 202 — wanB.**

| Rol de entrega | Dirección |
| --- | --- |
| network | 10.252.8.8/29 |
| cpe | 10.252.8.9 |
| r1 | 10.252.8.10 |
| r2 | 10.252.8.11 |


**Transporte entel5g — VLAN 203 — wanA.**

| Rol de entrega | Dirección |
| --- | --- |
| network | 10.252.8.16/29 |
| cpe | 10.252.8.17 |
| r1 | 10.252.8.18 |
| r2 | 10.252.8.19 |


**Transporte wom4g — VLAN 204 — wanB.**

| Rol de entrega | Dirección |
| --- | --- |
| network | 10.252.8.24/29 |
| cpe | 10.252.8.25 |
| r1 | 10.252.8.26 |
| r2 | 10.252.8.27 |


**Reservas de túneles (numeración según lista de la ficha).**

| Rol / candidato | Dirección |
| --- | --- |
| .1.hub_public_ip | 198.51.100.4 |
| .1.network | 10.253.8.0/30 |
| .1.branch_ip | 10.253.8.1 |
| .1.hub_ip | 10.253.8.2 |
| .2.hub_public_ip | 203.0.113.4 |
| .2.network | 10.253.8.4/30 |
| .2.branch_ip | 10.253.8.5 |
| .2.hub_ip | 10.253.8.6 |
| .3.hub_public_ip | 198.51.100.4 |
| .3.network | 10.253.8.8/30 |
| .3.branch_ip | 10.253.8.9 |
| .3.hub_ip | 10.253.8.10 |
| .4.hub_public_ip | 203.0.113.4 |
| .4.network | 10.253.8.12/30 |
| .4.branch_ip | 10.253.8.13 |
| .4.hub_ip | 10.253.8.14 |
| .5.hub_public_ip | 198.51.100.4 |
| .5.network | 10.253.8.16/30 |
| .5.branch_ip | 10.253.8.17 |
| .5.hub_ip | 10.253.8.18 |
| .6.hub_public_ip | 203.0.113.4 |
| .6.network | 10.253.8.20/30 |
| .6.branch_ip | 10.253.8.21 |
| .6.hub_ip | 10.253.8.22 |
| .7.hub_public_ip | 198.51.100.4 |
| .7.network | 10.253.8.24/30 |
| .7.branch_ip | 10.253.8.25 |
| .7.hub_ip | 10.253.8.26 |
| .8.hub_public_ip | 203.0.113.4 |
| .8.network | 10.253.8.28/30 |
| .8.branch_ip | 10.253.8.29 |
| .8.hub_ip | 10.253.8.30 |
| .9.hub_public_ip | 198.51.100.4 |
| .9.network | 10.253.8.32/30 |
| .9.branch_ip | 10.253.8.33 |
| .9.hub_ip | 10.253.8.34 |
| .10.hub_public_ip | 203.0.113.4 |
| .10.network | 10.253.8.36/30 |
| .10.branch_ip | 10.253.8.37 |
| .10.hub_ip | 10.253.8.38 |
| .11.hub_public_ip | 198.51.100.4 |
| .11.network | 10.253.8.40/30 |
| .11.branch_ip | 10.253.8.41 |
| .11.hub_ip | 10.253.8.42 |
| .12.hub_public_ip | 203.0.113.4 |
| .12.network | 10.253.8.44/30 |
| .12.branch_ip | 10.253.8.45 |
| .12.hub_ip | 10.253.8.46 |
| .13.hub_public_ip | 198.51.100.4 |
| .13.network | 10.253.8.48/30 |
| .13.branch_ip | 10.253.8.49 |
| .13.hub_ip | 10.253.8.50 |
| .14.hub_public_ip | 203.0.113.4 |
| .14.network | 10.253.8.52/30 |
| .14.branch_ip | 10.253.8.53 |
| .14.hub_ip | 10.253.8.54 |
| .15.hub_public_ip | 198.51.100.4 |
| .15.network | 10.253.8.56/30 |
| .15.branch_ip | 10.253.8.57 |
| .15.hub_ip | 10.253.8.58 |
| .16.hub_public_ip | 203.0.113.4 |
| .16.network | 10.253.8.60/30 |
| .16.branch_ip | 10.253.8.61 |
| .16.hub_ip | 10.253.8.62 |

### S09 — Copiapó

28 PCs y 28 teléfonos existentes.

| Función | ANTES | DESPUÉS |
| --- | --- | --- |
| Routers | 1 × C1121X-8P | 2 × C1121X-8P |
| Switches | 1 × C9200L-48P-4G-E | C9200L-48P-4G-E + C9200L-24P-4G-E |
| Firewall | Sin equipo dedicado | Sin appliance remoto; seguridad central |
| Distribución WAN | MPLS y accesos ISP del escenario base | wanA: E50UG; wanB: E50UG |


| Red | VLAN | Subred | Gateway / roles |
| --- | --- | --- | --- |
| users | 10 | 10.70.9.0/25 | 10.70.9.1 |
| voice | 20 | 10.70.73.0/25 | 10.70.73.1 |
| guests | 40 | 10.70.105.0/26 | 10.70.105.1 |
| wifi_users | 110 | 10.81.9.0/25 | 10.81.9.1 |
| wifi_voice | 120 | 10.82.9.0/25 | 10.82.9.1 |
| management | 130 | 10.80.9.0/27 | 10.80.9.1 |


| Gestión | Dirección |
| --- | --- |
| sw1 | 10.80.9.1 |
| sw2 | 10.80.9.1 |
| r1 | 10.80.9.2 |
| r2 | 10.80.9.3 |
| wanA | 10.80.9.6 |
| wanB | 10.80.9.7 |
| ap1 | 10.80.9.24 |
| ap2 | 10.80.9.25 |


| Origen | Puerto | Destino | Puerto | Función | VLAN/red | Mbps | IP / agregado lógico |
| --- | --- | --- | --- | --- | --- | --- | --- |
| cpe:starlink | LAN | wanA | ether1 | WAN_ACCESS | 201 | 1000 | — |
| cpe:entel5g | LAN | wanA | ether2 | WAN_ACCESS | 203 | 1000 | — |
| r1 | GigabitEthernet0/0/0 | wanA | ether3 | WAN_TRUNK | 201, 203 | 1000 | — |
| r2 | GigabitEthernet0/0/0 | wanA | ether4 | WAN_TRUNK | 201, 203 | 1000 | — |
| wanA | ether5 | sw1 | Gi1/0/22 | MANAGEMENT_ACCESS | 130 | 1000 | — |
| cpe:leo | LAN | wanB | ether1 | WAN_ACCESS | 202 | 1000 | — |
| cpe:wom4g | LAN | wanB | ether2 | WAN_ACCESS | 204 | 1000 | — |
| r1 | GigabitEthernet0/0/1 | wanB | ether3 | WAN_TRUNK | 202, 204 | 1000 | — |
| r2 | GigabitEthernet0/0/1 | wanB | ether4 | WAN_TRUNK | 202, 204 | 1000 | — |
| wanB | ether5 | sw2 | Gi2/0/22 | MANAGEMENT_ACCESS | 130 | 1000 | — |
| r1 | GigabitEthernet0/1/0 | sw1 | Gi1/0/19 | LAN_ROUTED | 172.31.9.0/30 | 1000 | router_ip: 172.31.9.1; stack_ip: 172.31.9.2 |
| r1 | GigabitEthernet0/1/1 | sw2 | Gi2/0/19 | LAN_ROUTED | 172.31.9.4/30 | 1000 | router_ip: 172.31.9.5; stack_ip: 172.31.9.6 |
| r1 | GigabitEthernet0/1/2 | sw1 | Gi1/0/21 | MANAGEMENT_ACCESS | 130 | 1000 | — |
| r2 | GigabitEthernet0/1/0 | sw1 | Gi1/0/20 | LAN_ROUTED | 172.31.9.8/30 | 1000 | router_ip: 172.31.9.9; stack_ip: 172.31.9.10 |
| r2 | GigabitEthernet0/1/1 | sw2 | Gi2/0/20 | LAN_ROUTED | 172.31.9.12/30 | 1000 | router_ip: 172.31.9.13; stack_ip: 172.31.9.14 |
| r2 | GigabitEthernet0/1/2 | sw2 | Gi2/0/21 | MANAGEMENT_ACCESS | 130 | 1000 | — |
| ap1 | LAN | sw1 | Gi1/0/24 | AP_TRUNK | 40, 110, 120, 130 | 1000 | — |
| ap2 | LAN | sw2 | Gi2/0/24 | AP_TRUNK | 40, 110, 120, 130 | 1000 | — |
| sw1 | Stack1 | sw2 | Stack2 | STACK | — | 80000 | — |
| sw1 | Stack2 | sw2 | Stack1 | STACK | — | 80000 | — |


| Puesto | Switch | Puerto | IP PC | IP teléfono | Reserva Wi-Fi PC | Reserva Wi-Fi voz |
| --- | --- | --- | --- | --- | --- | --- |
| s09-pc01 | 1 | 1 | 10.70.9.10 | 10.70.73.10 | 10.81.9.10 | 10.82.9.10 |
| s09-pc02 | 2 | 1 | 10.70.9.11 | 10.70.73.11 | 10.81.9.11 | 10.82.9.11 |
| s09-pc03 | 1 | 2 | 10.70.9.12 | 10.70.73.12 | 10.81.9.12 | 10.82.9.12 |
| s09-pc04 | 2 | 2 | 10.70.9.13 | 10.70.73.13 | 10.81.9.13 | 10.82.9.13 |
| s09-pc05 | 1 | 3 | 10.70.9.14 | 10.70.73.14 | 10.81.9.14 | 10.82.9.14 |
| s09-pc06 | 2 | 3 | 10.70.9.15 | 10.70.73.15 | 10.81.9.15 | 10.82.9.15 |
| s09-pc07 | 1 | 4 | 10.70.9.16 | 10.70.73.16 | 10.81.9.16 | 10.82.9.16 |
| s09-pc08 | 2 | 4 | 10.70.9.17 | 10.70.73.17 | 10.81.9.17 | 10.82.9.17 |
| s09-pc09 | 1 | 5 | 10.70.9.18 | 10.70.73.18 | 10.81.9.18 | 10.82.9.18 |
| s09-pc10 | 2 | 5 | 10.70.9.19 | 10.70.73.19 | 10.81.9.19 | 10.82.9.19 |
| s09-pc11 | 1 | 6 | 10.70.9.20 | 10.70.73.20 | 10.81.9.20 | 10.82.9.20 |
| s09-pc12 | 2 | 6 | 10.70.9.21 | 10.70.73.21 | 10.81.9.21 | 10.82.9.21 |
| s09-pc13 | 1 | 7 | 10.70.9.22 | 10.70.73.22 | 10.81.9.22 | 10.82.9.22 |
| s09-pc14 | 2 | 7 | 10.70.9.23 | 10.70.73.23 | 10.81.9.23 | 10.82.9.23 |
| s09-pc15 | 1 | 8 | 10.70.9.24 | 10.70.73.24 | 10.81.9.24 | 10.82.9.24 |
| s09-pc16 | 2 | 8 | 10.70.9.25 | 10.70.73.25 | 10.81.9.25 | 10.82.9.25 |
| s09-pc17 | 1 | 9 | 10.70.9.26 | 10.70.73.26 | 10.81.9.26 | 10.82.9.26 |
| s09-pc18 | 2 | 9 | 10.70.9.27 | 10.70.73.27 | 10.81.9.27 | 10.82.9.27 |
| s09-pc19 | 1 | 10 | 10.70.9.28 | 10.70.73.28 | 10.81.9.28 | 10.82.9.28 |
| s09-pc20 | 2 | 10 | 10.70.9.29 | 10.70.73.29 | 10.81.9.29 | 10.82.9.29 |
| s09-pc21 | 1 | 11 | 10.70.9.30 | 10.70.73.30 | 10.81.9.30 | 10.82.9.30 |
| s09-pc22 | 2 | 11 | 10.70.9.31 | 10.70.73.31 | 10.81.9.31 | 10.82.9.31 |
| s09-pc23 | 1 | 12 | 10.70.9.32 | 10.70.73.32 | 10.81.9.32 | 10.82.9.32 |
| s09-pc24 | 2 | 12 | 10.70.9.33 | 10.70.73.33 | 10.81.9.33 | 10.82.9.33 |
| s09-pc25 | 1 | 13 | 10.70.9.34 | 10.70.73.34 | 10.81.9.34 | 10.82.9.34 |
| s09-pc26 | 2 | 13 | 10.70.9.35 | 10.70.73.35 | 10.81.9.35 | 10.82.9.35 |
| s09-pc27 | 1 | 14 | 10.70.9.36 | 10.70.73.36 | 10.81.9.36 | 10.82.9.36 |
| s09-pc28 | 2 | 14 | 10.70.9.37 | 10.70.73.37 | 10.81.9.37 | 10.82.9.37 |


**Transporte starlink — VLAN 201 — wanA.**

| Rol de entrega | Dirección |
| --- | --- |
| network | 10.252.9.0/29 |
| cpe | 10.252.9.1 |
| r1 | 10.252.9.2 |
| r2 | 10.252.9.3 |


**Transporte leo — VLAN 202 — wanB.**

| Rol de entrega | Dirección |
| --- | --- |
| network | 10.252.9.8/29 |
| cpe | 10.252.9.9 |
| r1 | 10.252.9.10 |
| r2 | 10.252.9.11 |


**Transporte entel5g — VLAN 203 — wanA.**

| Rol de entrega | Dirección |
| --- | --- |
| network | 10.252.9.16/29 |
| cpe | 10.252.9.17 |
| r1 | 10.252.9.18 |
| r2 | 10.252.9.19 |


**Transporte wom4g — VLAN 204 — wanB.**

| Rol de entrega | Dirección |
| --- | --- |
| network | 10.252.9.24/29 |
| cpe | 10.252.9.25 |
| r1 | 10.252.9.26 |
| r2 | 10.252.9.27 |


**Reservas de túneles (numeración según lista de la ficha).**

| Rol / candidato | Dirección |
| --- | --- |
| .1.hub_public_ip | 198.51.100.4 |
| .1.network | 10.253.9.0/30 |
| .1.branch_ip | 10.253.9.1 |
| .1.hub_ip | 10.253.9.2 |
| .2.hub_public_ip | 203.0.113.4 |
| .2.network | 10.253.9.4/30 |
| .2.branch_ip | 10.253.9.5 |
| .2.hub_ip | 10.253.9.6 |
| .3.hub_public_ip | 198.51.100.4 |
| .3.network | 10.253.9.8/30 |
| .3.branch_ip | 10.253.9.9 |
| .3.hub_ip | 10.253.9.10 |
| .4.hub_public_ip | 203.0.113.4 |
| .4.network | 10.253.9.12/30 |
| .4.branch_ip | 10.253.9.13 |
| .4.hub_ip | 10.253.9.14 |
| .5.hub_public_ip | 198.51.100.4 |
| .5.network | 10.253.9.16/30 |
| .5.branch_ip | 10.253.9.17 |
| .5.hub_ip | 10.253.9.18 |
| .6.hub_public_ip | 203.0.113.4 |
| .6.network | 10.253.9.20/30 |
| .6.branch_ip | 10.253.9.21 |
| .6.hub_ip | 10.253.9.22 |
| .7.hub_public_ip | 198.51.100.4 |
| .7.network | 10.253.9.24/30 |
| .7.branch_ip | 10.253.9.25 |
| .7.hub_ip | 10.253.9.26 |
| .8.hub_public_ip | 203.0.113.4 |
| .8.network | 10.253.9.28/30 |
| .8.branch_ip | 10.253.9.29 |
| .8.hub_ip | 10.253.9.30 |
| .9.hub_public_ip | 198.51.100.4 |
| .9.network | 10.253.9.32/30 |
| .9.branch_ip | 10.253.9.33 |
| .9.hub_ip | 10.253.9.34 |
| .10.hub_public_ip | 203.0.113.4 |
| .10.network | 10.253.9.36/30 |
| .10.branch_ip | 10.253.9.37 |
| .10.hub_ip | 10.253.9.38 |
| .11.hub_public_ip | 198.51.100.4 |
| .11.network | 10.253.9.40/30 |
| .11.branch_ip | 10.253.9.41 |
| .11.hub_ip | 10.253.9.42 |
| .12.hub_public_ip | 203.0.113.4 |
| .12.network | 10.253.9.44/30 |
| .12.branch_ip | 10.253.9.45 |
| .12.hub_ip | 10.253.9.46 |
| .13.hub_public_ip | 198.51.100.4 |
| .13.network | 10.253.9.48/30 |
| .13.branch_ip | 10.253.9.49 |
| .13.hub_ip | 10.253.9.50 |
| .14.hub_public_ip | 203.0.113.4 |
| .14.network | 10.253.9.52/30 |
| .14.branch_ip | 10.253.9.53 |
| .14.hub_ip | 10.253.9.54 |
| .15.hub_public_ip | 198.51.100.4 |
| .15.network | 10.253.9.56/30 |
| .15.branch_ip | 10.253.9.57 |
| .15.hub_ip | 10.253.9.58 |
| .16.hub_public_ip | 203.0.113.4 |
| .16.network | 10.253.9.60/30 |
| .16.branch_ip | 10.253.9.61 |
| .16.hub_ip | 10.253.9.62 |

### S10 — La Serena

28 PCs y 28 teléfonos existentes.

| Función | ANTES | DESPUÉS |
| --- | --- | --- |
| Routers | 1 × ISR4321/K9 | 2 × C1121X-8P |
| Switches | 1 × C9200L-48P-4G-E | C9200L-48P-4G-E + C9200L-24P-4G-E |
| Firewall | Sin equipo dedicado | Sin appliance remoto; seguridad central |
| Distribución WAN | MPLS y accesos ISP del escenario base | wanA: E50UG; wanB: E50UG |


| Red | VLAN | Subred | Gateway / roles |
| --- | --- | --- | --- |
| users | 10 | 10.70.10.0/25 | 10.70.10.1 |
| voice | 20 | 10.70.74.0/25 | 10.70.74.1 |
| guests | 40 | 10.70.106.0/26 | 10.70.106.1 |
| wifi_users | 110 | 10.81.10.0/25 | 10.81.10.1 |
| wifi_voice | 120 | 10.82.10.0/25 | 10.82.10.1 |
| management | 130 | 10.80.10.0/27 | 10.80.10.1 |


| Gestión | Dirección |
| --- | --- |
| sw1 | 10.80.10.1 |
| sw2 | 10.80.10.1 |
| r1 | 10.80.10.2 |
| r2 | 10.80.10.3 |
| wanA | 10.80.10.6 |
| wanB | 10.80.10.7 |
| ap1 | 10.80.10.24 |
| ap2 | 10.80.10.25 |


| Origen | Puerto | Destino | Puerto | Función | VLAN/red | Mbps | IP / agregado lógico |
| --- | --- | --- | --- | --- | --- | --- | --- |
| cpe:starlink | LAN | wanA | ether1 | WAN_ACCESS | 201 | 1000 | — |
| cpe:entel5g | LAN | wanA | ether2 | WAN_ACCESS | 203 | 1000 | — |
| r1 | GigabitEthernet0/0/0 | wanA | ether3 | WAN_TRUNK | 201, 203 | 1000 | — |
| r2 | GigabitEthernet0/0/0 | wanA | ether4 | WAN_TRUNK | 201, 203 | 1000 | — |
| wanA | ether5 | sw1 | Gi1/0/22 | MANAGEMENT_ACCESS | 130 | 1000 | — |
| cpe:leo | LAN | wanB | ether1 | WAN_ACCESS | 202 | 1000 | — |
| cpe:wom4g | LAN | wanB | ether2 | WAN_ACCESS | 204 | 1000 | — |
| r1 | GigabitEthernet0/0/1 | wanB | ether3 | WAN_TRUNK | 202, 204 | 1000 | — |
| r2 | GigabitEthernet0/0/1 | wanB | ether4 | WAN_TRUNK | 202, 204 | 1000 | — |
| wanB | ether5 | sw2 | Gi2/0/22 | MANAGEMENT_ACCESS | 130 | 1000 | — |
| r1 | GigabitEthernet0/1/0 | sw1 | Gi1/0/19 | LAN_ROUTED | 172.31.10.0/30 | 1000 | router_ip: 172.31.10.1; stack_ip: 172.31.10.2 |
| r1 | GigabitEthernet0/1/1 | sw2 | Gi2/0/19 | LAN_ROUTED | 172.31.10.4/30 | 1000 | router_ip: 172.31.10.5; stack_ip: 172.31.10.6 |
| r1 | GigabitEthernet0/1/2 | sw1 | Gi1/0/21 | MANAGEMENT_ACCESS | 130 | 1000 | — |
| r2 | GigabitEthernet0/1/0 | sw1 | Gi1/0/20 | LAN_ROUTED | 172.31.10.8/30 | 1000 | router_ip: 172.31.10.9; stack_ip: 172.31.10.10 |
| r2 | GigabitEthernet0/1/1 | sw2 | Gi2/0/20 | LAN_ROUTED | 172.31.10.12/30 | 1000 | router_ip: 172.31.10.13; stack_ip: 172.31.10.14 |
| r2 | GigabitEthernet0/1/2 | sw2 | Gi2/0/21 | MANAGEMENT_ACCESS | 130 | 1000 | — |
| ap1 | LAN | sw1 | Gi1/0/24 | AP_TRUNK | 40, 110, 120, 130 | 1000 | — |
| ap2 | LAN | sw2 | Gi2/0/24 | AP_TRUNK | 40, 110, 120, 130 | 1000 | — |
| sw1 | Stack1 | sw2 | Stack2 | STACK | — | 80000 | — |
| sw1 | Stack2 | sw2 | Stack1 | STACK | — | 80000 | — |


| Puesto | Switch | Puerto | IP PC | IP teléfono | Reserva Wi-Fi PC | Reserva Wi-Fi voz |
| --- | --- | --- | --- | --- | --- | --- |
| s10-pc01 | 1 | 1 | 10.70.10.10 | 10.70.74.10 | 10.81.10.10 | 10.82.10.10 |
| s10-pc02 | 2 | 1 | 10.70.10.11 | 10.70.74.11 | 10.81.10.11 | 10.82.10.11 |
| s10-pc03 | 1 | 2 | 10.70.10.12 | 10.70.74.12 | 10.81.10.12 | 10.82.10.12 |
| s10-pc04 | 2 | 2 | 10.70.10.13 | 10.70.74.13 | 10.81.10.13 | 10.82.10.13 |
| s10-pc05 | 1 | 3 | 10.70.10.14 | 10.70.74.14 | 10.81.10.14 | 10.82.10.14 |
| s10-pc06 | 2 | 3 | 10.70.10.15 | 10.70.74.15 | 10.81.10.15 | 10.82.10.15 |
| s10-pc07 | 1 | 4 | 10.70.10.16 | 10.70.74.16 | 10.81.10.16 | 10.82.10.16 |
| s10-pc08 | 2 | 4 | 10.70.10.17 | 10.70.74.17 | 10.81.10.17 | 10.82.10.17 |
| s10-pc09 | 1 | 5 | 10.70.10.18 | 10.70.74.18 | 10.81.10.18 | 10.82.10.18 |
| s10-pc10 | 2 | 5 | 10.70.10.19 | 10.70.74.19 | 10.81.10.19 | 10.82.10.19 |
| s10-pc11 | 1 | 6 | 10.70.10.20 | 10.70.74.20 | 10.81.10.20 | 10.82.10.20 |
| s10-pc12 | 2 | 6 | 10.70.10.21 | 10.70.74.21 | 10.81.10.21 | 10.82.10.21 |
| s10-pc13 | 1 | 7 | 10.70.10.22 | 10.70.74.22 | 10.81.10.22 | 10.82.10.22 |
| s10-pc14 | 2 | 7 | 10.70.10.23 | 10.70.74.23 | 10.81.10.23 | 10.82.10.23 |
| s10-pc15 | 1 | 8 | 10.70.10.24 | 10.70.74.24 | 10.81.10.24 | 10.82.10.24 |
| s10-pc16 | 2 | 8 | 10.70.10.25 | 10.70.74.25 | 10.81.10.25 | 10.82.10.25 |
| s10-pc17 | 1 | 9 | 10.70.10.26 | 10.70.74.26 | 10.81.10.26 | 10.82.10.26 |
| s10-pc18 | 2 | 9 | 10.70.10.27 | 10.70.74.27 | 10.81.10.27 | 10.82.10.27 |
| s10-pc19 | 1 | 10 | 10.70.10.28 | 10.70.74.28 | 10.81.10.28 | 10.82.10.28 |
| s10-pc20 | 2 | 10 | 10.70.10.29 | 10.70.74.29 | 10.81.10.29 | 10.82.10.29 |
| s10-pc21 | 1 | 11 | 10.70.10.30 | 10.70.74.30 | 10.81.10.30 | 10.82.10.30 |
| s10-pc22 | 2 | 11 | 10.70.10.31 | 10.70.74.31 | 10.81.10.31 | 10.82.10.31 |
| s10-pc23 | 1 | 12 | 10.70.10.32 | 10.70.74.32 | 10.81.10.32 | 10.82.10.32 |
| s10-pc24 | 2 | 12 | 10.70.10.33 | 10.70.74.33 | 10.81.10.33 | 10.82.10.33 |
| s10-pc25 | 1 | 13 | 10.70.10.34 | 10.70.74.34 | 10.81.10.34 | 10.82.10.34 |
| s10-pc26 | 2 | 13 | 10.70.10.35 | 10.70.74.35 | 10.81.10.35 | 10.82.10.35 |
| s10-pc27 | 1 | 14 | 10.70.10.36 | 10.70.74.36 | 10.81.10.36 | 10.82.10.36 |
| s10-pc28 | 2 | 14 | 10.70.10.37 | 10.70.74.37 | 10.81.10.37 | 10.82.10.37 |


**Transporte starlink — VLAN 201 — wanA.**

| Rol de entrega | Dirección |
| --- | --- |
| network | 10.252.10.0/29 |
| cpe | 10.252.10.1 |
| r1 | 10.252.10.2 |
| r2 | 10.252.10.3 |


**Transporte leo — VLAN 202 — wanB.**

| Rol de entrega | Dirección |
| --- | --- |
| network | 10.252.10.8/29 |
| cpe | 10.252.10.9 |
| r1 | 10.252.10.10 |
| r2 | 10.252.10.11 |


**Transporte entel5g — VLAN 203 — wanA.**

| Rol de entrega | Dirección |
| --- | --- |
| network | 10.252.10.16/29 |
| cpe | 10.252.10.17 |
| r1 | 10.252.10.18 |
| r2 | 10.252.10.19 |


**Transporte wom4g — VLAN 204 — wanB.**

| Rol de entrega | Dirección |
| --- | --- |
| network | 10.252.10.24/29 |
| cpe | 10.252.10.25 |
| r1 | 10.252.10.26 |
| r2 | 10.252.10.27 |


**Reservas de túneles (numeración según lista de la ficha).**

| Rol / candidato | Dirección |
| --- | --- |
| .1.hub_public_ip | 198.51.100.4 |
| .1.network | 10.253.10.0/30 |
| .1.branch_ip | 10.253.10.1 |
| .1.hub_ip | 10.253.10.2 |
| .2.hub_public_ip | 203.0.113.4 |
| .2.network | 10.253.10.4/30 |
| .2.branch_ip | 10.253.10.5 |
| .2.hub_ip | 10.253.10.6 |
| .3.hub_public_ip | 198.51.100.4 |
| .3.network | 10.253.10.8/30 |
| .3.branch_ip | 10.253.10.9 |
| .3.hub_ip | 10.253.10.10 |
| .4.hub_public_ip | 203.0.113.4 |
| .4.network | 10.253.10.12/30 |
| .4.branch_ip | 10.253.10.13 |
| .4.hub_ip | 10.253.10.14 |
| .5.hub_public_ip | 198.51.100.4 |
| .5.network | 10.253.10.16/30 |
| .5.branch_ip | 10.253.10.17 |
| .5.hub_ip | 10.253.10.18 |
| .6.hub_public_ip | 203.0.113.4 |
| .6.network | 10.253.10.20/30 |
| .6.branch_ip | 10.253.10.21 |
| .6.hub_ip | 10.253.10.22 |
| .7.hub_public_ip | 198.51.100.4 |
| .7.network | 10.253.10.24/30 |
| .7.branch_ip | 10.253.10.25 |
| .7.hub_ip | 10.253.10.26 |
| .8.hub_public_ip | 203.0.113.4 |
| .8.network | 10.253.10.28/30 |
| .8.branch_ip | 10.253.10.29 |
| .8.hub_ip | 10.253.10.30 |
| .9.hub_public_ip | 198.51.100.4 |
| .9.network | 10.253.10.32/30 |
| .9.branch_ip | 10.253.10.33 |
| .9.hub_ip | 10.253.10.34 |
| .10.hub_public_ip | 203.0.113.4 |
| .10.network | 10.253.10.36/30 |
| .10.branch_ip | 10.253.10.37 |
| .10.hub_ip | 10.253.10.38 |
| .11.hub_public_ip | 198.51.100.4 |
| .11.network | 10.253.10.40/30 |
| .11.branch_ip | 10.253.10.41 |
| .11.hub_ip | 10.253.10.42 |
| .12.hub_public_ip | 203.0.113.4 |
| .12.network | 10.253.10.44/30 |
| .12.branch_ip | 10.253.10.45 |
| .12.hub_ip | 10.253.10.46 |
| .13.hub_public_ip | 198.51.100.4 |
| .13.network | 10.253.10.48/30 |
| .13.branch_ip | 10.253.10.49 |
| .13.hub_ip | 10.253.10.50 |
| .14.hub_public_ip | 203.0.113.4 |
| .14.network | 10.253.10.52/30 |
| .14.branch_ip | 10.253.10.53 |
| .14.hub_ip | 10.253.10.54 |
| .15.hub_public_ip | 198.51.100.4 |
| .15.network | 10.253.10.56/30 |
| .15.branch_ip | 10.253.10.57 |
| .15.hub_ip | 10.253.10.58 |
| .16.hub_public_ip | 203.0.113.4 |
| .16.network | 10.253.10.60/30 |
| .16.branch_ip | 10.253.10.61 |
| .16.hub_ip | 10.253.10.62 |

### S11 — Valparaíso

28 PCs y 28 teléfonos existentes.

| Función | ANTES | DESPUÉS |
| --- | --- | --- |
| Routers | 1 × CISCO1921-SEC/K9 | 2 × C1121X-8P |
| Switches | 1 × WS-C2960S-48LPS-L | C9200L-24P-4G-E + C9200L-24P-4G-E |
| Firewall | Sin equipo dedicado | Sin appliance remoto; seguridad central |
| Distribución WAN | MPLS y accesos ISP del escenario base | wanA: E50UG; wanB: E50UG |


| Red | VLAN | Subred | Gateway / roles |
| --- | --- | --- | --- |
| users | 10 | 10.70.11.0/25 | 10.70.11.1 |
| voice | 20 | 10.70.75.0/25 | 10.70.75.1 |
| guests | 40 | 10.70.107.0/26 | 10.70.107.1 |
| wifi_users | 110 | 10.81.11.0/25 | 10.81.11.1 |
| wifi_voice | 120 | 10.82.11.0/25 | 10.82.11.1 |
| management | 130 | 10.80.11.0/27 | 10.80.11.1 |


| Gestión | Dirección |
| --- | --- |
| sw1 | 10.80.11.1 |
| sw2 | 10.80.11.1 |
| r1 | 10.80.11.2 |
| r2 | 10.80.11.3 |
| wanA | 10.80.11.6 |
| wanB | 10.80.11.7 |
| ap1 | 10.80.11.24 |
| ap2 | 10.80.11.25 |


| Origen | Puerto | Destino | Puerto | Función | VLAN/red | Mbps | IP / agregado lógico |
| --- | --- | --- | --- | --- | --- | --- | --- |
| cpe:starlink | LAN | wanA | ether1 | WAN_ACCESS | 201 | 1000 | — |
| cpe:entel5g | LAN | wanA | ether2 | WAN_ACCESS | 203 | 1000 | — |
| r1 | GigabitEthernet0/0/0 | wanA | ether3 | WAN_TRUNK | 201, 203 | 1000 | — |
| r2 | GigabitEthernet0/0/0 | wanA | ether4 | WAN_TRUNK | 201, 203 | 1000 | — |
| wanA | ether5 | sw1 | Gi1/0/22 | MANAGEMENT_ACCESS | 130 | 1000 | — |
| cpe:leo | LAN | wanB | ether1 | WAN_ACCESS | 202 | 1000 | — |
| cpe:wom4g | LAN | wanB | ether2 | WAN_ACCESS | 204 | 1000 | — |
| r1 | GigabitEthernet0/0/1 | wanB | ether3 | WAN_TRUNK | 202, 204 | 1000 | — |
| r2 | GigabitEthernet0/0/1 | wanB | ether4 | WAN_TRUNK | 202, 204 | 1000 | — |
| wanB | ether5 | sw2 | Gi2/0/22 | MANAGEMENT_ACCESS | 130 | 1000 | — |
| r1 | GigabitEthernet0/1/0 | sw1 | Gi1/0/19 | LAN_ROUTED | 172.31.11.0/30 | 1000 | router_ip: 172.31.11.1; stack_ip: 172.31.11.2 |
| r1 | GigabitEthernet0/1/1 | sw2 | Gi2/0/19 | LAN_ROUTED | 172.31.11.4/30 | 1000 | router_ip: 172.31.11.5; stack_ip: 172.31.11.6 |
| r1 | GigabitEthernet0/1/2 | sw1 | Gi1/0/21 | MANAGEMENT_ACCESS | 130 | 1000 | — |
| r2 | GigabitEthernet0/1/0 | sw1 | Gi1/0/20 | LAN_ROUTED | 172.31.11.8/30 | 1000 | router_ip: 172.31.11.9; stack_ip: 172.31.11.10 |
| r2 | GigabitEthernet0/1/1 | sw2 | Gi2/0/20 | LAN_ROUTED | 172.31.11.12/30 | 1000 | router_ip: 172.31.11.13; stack_ip: 172.31.11.14 |
| r2 | GigabitEthernet0/1/2 | sw2 | Gi2/0/21 | MANAGEMENT_ACCESS | 130 | 1000 | — |
| ap1 | LAN | sw1 | Gi1/0/24 | AP_TRUNK | 40, 110, 120, 130 | 1000 | — |
| ap2 | LAN | sw2 | Gi2/0/24 | AP_TRUNK | 40, 110, 120, 130 | 1000 | — |
| sw1 | Stack1 | sw2 | Stack2 | STACK | — | 80000 | — |
| sw1 | Stack2 | sw2 | Stack1 | STACK | — | 80000 | — |


| Puesto | Switch | Puerto | IP PC | IP teléfono | Reserva Wi-Fi PC | Reserva Wi-Fi voz |
| --- | --- | --- | --- | --- | --- | --- |
| s11-pc01 | 1 | 1 | 10.70.11.10 | 10.70.75.10 | 10.81.11.10 | 10.82.11.10 |
| s11-pc02 | 2 | 1 | 10.70.11.11 | 10.70.75.11 | 10.81.11.11 | 10.82.11.11 |
| s11-pc03 | 1 | 2 | 10.70.11.12 | 10.70.75.12 | 10.81.11.12 | 10.82.11.12 |
| s11-pc04 | 2 | 2 | 10.70.11.13 | 10.70.75.13 | 10.81.11.13 | 10.82.11.13 |
| s11-pc05 | 1 | 3 | 10.70.11.14 | 10.70.75.14 | 10.81.11.14 | 10.82.11.14 |
| s11-pc06 | 2 | 3 | 10.70.11.15 | 10.70.75.15 | 10.81.11.15 | 10.82.11.15 |
| s11-pc07 | 1 | 4 | 10.70.11.16 | 10.70.75.16 | 10.81.11.16 | 10.82.11.16 |
| s11-pc08 | 2 | 4 | 10.70.11.17 | 10.70.75.17 | 10.81.11.17 | 10.82.11.17 |
| s11-pc09 | 1 | 5 | 10.70.11.18 | 10.70.75.18 | 10.81.11.18 | 10.82.11.18 |
| s11-pc10 | 2 | 5 | 10.70.11.19 | 10.70.75.19 | 10.81.11.19 | 10.82.11.19 |
| s11-pc11 | 1 | 6 | 10.70.11.20 | 10.70.75.20 | 10.81.11.20 | 10.82.11.20 |
| s11-pc12 | 2 | 6 | 10.70.11.21 | 10.70.75.21 | 10.81.11.21 | 10.82.11.21 |
| s11-pc13 | 1 | 7 | 10.70.11.22 | 10.70.75.22 | 10.81.11.22 | 10.82.11.22 |
| s11-pc14 | 2 | 7 | 10.70.11.23 | 10.70.75.23 | 10.81.11.23 | 10.82.11.23 |
| s11-pc15 | 1 | 8 | 10.70.11.24 | 10.70.75.24 | 10.81.11.24 | 10.82.11.24 |
| s11-pc16 | 2 | 8 | 10.70.11.25 | 10.70.75.25 | 10.81.11.25 | 10.82.11.25 |
| s11-pc17 | 1 | 9 | 10.70.11.26 | 10.70.75.26 | 10.81.11.26 | 10.82.11.26 |
| s11-pc18 | 2 | 9 | 10.70.11.27 | 10.70.75.27 | 10.81.11.27 | 10.82.11.27 |
| s11-pc19 | 1 | 10 | 10.70.11.28 | 10.70.75.28 | 10.81.11.28 | 10.82.11.28 |
| s11-pc20 | 2 | 10 | 10.70.11.29 | 10.70.75.29 | 10.81.11.29 | 10.82.11.29 |
| s11-pc21 | 1 | 11 | 10.70.11.30 | 10.70.75.30 | 10.81.11.30 | 10.82.11.30 |
| s11-pc22 | 2 | 11 | 10.70.11.31 | 10.70.75.31 | 10.81.11.31 | 10.82.11.31 |
| s11-pc23 | 1 | 12 | 10.70.11.32 | 10.70.75.32 | 10.81.11.32 | 10.82.11.32 |
| s11-pc24 | 2 | 12 | 10.70.11.33 | 10.70.75.33 | 10.81.11.33 | 10.82.11.33 |
| s11-pc25 | 1 | 13 | 10.70.11.34 | 10.70.75.34 | 10.81.11.34 | 10.82.11.34 |
| s11-pc26 | 2 | 13 | 10.70.11.35 | 10.70.75.35 | 10.81.11.35 | 10.82.11.35 |
| s11-pc27 | 1 | 14 | 10.70.11.36 | 10.70.75.36 | 10.81.11.36 | 10.82.11.36 |
| s11-pc28 | 2 | 14 | 10.70.11.37 | 10.70.75.37 | 10.81.11.37 | 10.82.11.37 |


**Transporte starlink — VLAN 201 — wanA.**

| Rol de entrega | Dirección |
| --- | --- |
| network | 10.252.11.0/29 |
| cpe | 10.252.11.1 |
| r1 | 10.252.11.2 |
| r2 | 10.252.11.3 |


**Transporte leo — VLAN 202 — wanB.**

| Rol de entrega | Dirección |
| --- | --- |
| network | 10.252.11.8/29 |
| cpe | 10.252.11.9 |
| r1 | 10.252.11.10 |
| r2 | 10.252.11.11 |


**Transporte entel5g — VLAN 203 — wanA.**

| Rol de entrega | Dirección |
| --- | --- |
| network | 10.252.11.16/29 |
| cpe | 10.252.11.17 |
| r1 | 10.252.11.18 |
| r2 | 10.252.11.19 |


**Transporte wom4g — VLAN 204 — wanB.**

| Rol de entrega | Dirección |
| --- | --- |
| network | 10.252.11.24/29 |
| cpe | 10.252.11.25 |
| r1 | 10.252.11.26 |
| r2 | 10.252.11.27 |


**Reservas de túneles (numeración según lista de la ficha).**

| Rol / candidato | Dirección |
| --- | --- |
| .1.hub_public_ip | 198.51.100.4 |
| .1.network | 10.253.11.0/30 |
| .1.branch_ip | 10.253.11.1 |
| .1.hub_ip | 10.253.11.2 |
| .2.hub_public_ip | 203.0.113.4 |
| .2.network | 10.253.11.4/30 |
| .2.branch_ip | 10.253.11.5 |
| .2.hub_ip | 10.253.11.6 |
| .3.hub_public_ip | 198.51.100.4 |
| .3.network | 10.253.11.8/30 |
| .3.branch_ip | 10.253.11.9 |
| .3.hub_ip | 10.253.11.10 |
| .4.hub_public_ip | 203.0.113.4 |
| .4.network | 10.253.11.12/30 |
| .4.branch_ip | 10.253.11.13 |
| .4.hub_ip | 10.253.11.14 |
| .5.hub_public_ip | 198.51.100.4 |
| .5.network | 10.253.11.16/30 |
| .5.branch_ip | 10.253.11.17 |
| .5.hub_ip | 10.253.11.18 |
| .6.hub_public_ip | 203.0.113.4 |
| .6.network | 10.253.11.20/30 |
| .6.branch_ip | 10.253.11.21 |
| .6.hub_ip | 10.253.11.22 |
| .7.hub_public_ip | 198.51.100.4 |
| .7.network | 10.253.11.24/30 |
| .7.branch_ip | 10.253.11.25 |
| .7.hub_ip | 10.253.11.26 |
| .8.hub_public_ip | 203.0.113.4 |
| .8.network | 10.253.11.28/30 |
| .8.branch_ip | 10.253.11.29 |
| .8.hub_ip | 10.253.11.30 |
| .9.hub_public_ip | 198.51.100.4 |
| .9.network | 10.253.11.32/30 |
| .9.branch_ip | 10.253.11.33 |
| .9.hub_ip | 10.253.11.34 |
| .10.hub_public_ip | 203.0.113.4 |
| .10.network | 10.253.11.36/30 |
| .10.branch_ip | 10.253.11.37 |
| .10.hub_ip | 10.253.11.38 |
| .11.hub_public_ip | 198.51.100.4 |
| .11.network | 10.253.11.40/30 |
| .11.branch_ip | 10.253.11.41 |
| .11.hub_ip | 10.253.11.42 |
| .12.hub_public_ip | 203.0.113.4 |
| .12.network | 10.253.11.44/30 |
| .12.branch_ip | 10.253.11.45 |
| .12.hub_ip | 10.253.11.46 |
| .13.hub_public_ip | 198.51.100.4 |
| .13.network | 10.253.11.48/30 |
| .13.branch_ip | 10.253.11.49 |
| .13.hub_ip | 10.253.11.50 |
| .14.hub_public_ip | 203.0.113.4 |
| .14.network | 10.253.11.52/30 |
| .14.branch_ip | 10.253.11.53 |
| .14.hub_ip | 10.253.11.54 |
| .15.hub_public_ip | 198.51.100.4 |
| .15.network | 10.253.11.56/30 |
| .15.branch_ip | 10.253.11.57 |
| .15.hub_ip | 10.253.11.58 |
| .16.hub_public_ip | 203.0.113.4 |
| .16.network | 10.253.11.60/30 |
| .16.branch_ip | 10.253.11.61 |
| .16.hub_ip | 10.253.11.62 |

### S12 — Rancagua

28 PCs y 28 teléfonos existentes.

| Función | ANTES | DESPUÉS |
| --- | --- | --- |
| Routers | 1 × CISCO1921-SEC/K9 | 2 × C1121X-8P |
| Switches | 1 × WS-C2960S-48LPS-L | C9200L-24P-4G-E + C9200L-24P-4G-E |
| Firewall | Sin equipo dedicado | Sin appliance remoto; seguridad central |
| Distribución WAN | MPLS y accesos ISP del escenario base | wanA: E50UG; wanB: E50UG |


| Red | VLAN | Subred | Gateway / roles |
| --- | --- | --- | --- |
| users | 10 | 10.70.12.0/25 | 10.70.12.1 |
| voice | 20 | 10.70.76.0/25 | 10.70.76.1 |
| guests | 40 | 10.70.108.0/26 | 10.70.108.1 |
| wifi_users | 110 | 10.81.12.0/25 | 10.81.12.1 |
| wifi_voice | 120 | 10.82.12.0/25 | 10.82.12.1 |
| management | 130 | 10.80.12.0/27 | 10.80.12.1 |


| Gestión | Dirección |
| --- | --- |
| sw1 | 10.80.12.1 |
| sw2 | 10.80.12.1 |
| r1 | 10.80.12.2 |
| r2 | 10.80.12.3 |
| wanA | 10.80.12.6 |
| wanB | 10.80.12.7 |
| ap1 | 10.80.12.24 |
| ap2 | 10.80.12.25 |


| Origen | Puerto | Destino | Puerto | Función | VLAN/red | Mbps | IP / agregado lógico |
| --- | --- | --- | --- | --- | --- | --- | --- |
| cpe:starlink | LAN | wanA | ether1 | WAN_ACCESS | 201 | 1000 | — |
| cpe:entel5g | LAN | wanA | ether2 | WAN_ACCESS | 203 | 1000 | — |
| r1 | GigabitEthernet0/0/0 | wanA | ether3 | WAN_TRUNK | 201, 203 | 1000 | — |
| r2 | GigabitEthernet0/0/0 | wanA | ether4 | WAN_TRUNK | 201, 203 | 1000 | — |
| wanA | ether5 | sw1 | Gi1/0/22 | MANAGEMENT_ACCESS | 130 | 1000 | — |
| cpe:leo | LAN | wanB | ether1 | WAN_ACCESS | 202 | 1000 | — |
| cpe:wom4g | LAN | wanB | ether2 | WAN_ACCESS | 204 | 1000 | — |
| r1 | GigabitEthernet0/0/1 | wanB | ether3 | WAN_TRUNK | 202, 204 | 1000 | — |
| r2 | GigabitEthernet0/0/1 | wanB | ether4 | WAN_TRUNK | 202, 204 | 1000 | — |
| wanB | ether5 | sw2 | Gi2/0/22 | MANAGEMENT_ACCESS | 130 | 1000 | — |
| r1 | GigabitEthernet0/1/0 | sw1 | Gi1/0/19 | LAN_ROUTED | 172.31.12.0/30 | 1000 | router_ip: 172.31.12.1; stack_ip: 172.31.12.2 |
| r1 | GigabitEthernet0/1/1 | sw2 | Gi2/0/19 | LAN_ROUTED | 172.31.12.4/30 | 1000 | router_ip: 172.31.12.5; stack_ip: 172.31.12.6 |
| r1 | GigabitEthernet0/1/2 | sw1 | Gi1/0/21 | MANAGEMENT_ACCESS | 130 | 1000 | — |
| r2 | GigabitEthernet0/1/0 | sw1 | Gi1/0/20 | LAN_ROUTED | 172.31.12.8/30 | 1000 | router_ip: 172.31.12.9; stack_ip: 172.31.12.10 |
| r2 | GigabitEthernet0/1/1 | sw2 | Gi2/0/20 | LAN_ROUTED | 172.31.12.12/30 | 1000 | router_ip: 172.31.12.13; stack_ip: 172.31.12.14 |
| r2 | GigabitEthernet0/1/2 | sw2 | Gi2/0/21 | MANAGEMENT_ACCESS | 130 | 1000 | — |
| ap1 | LAN | sw1 | Gi1/0/24 | AP_TRUNK | 40, 110, 120, 130 | 1000 | — |
| ap2 | LAN | sw2 | Gi2/0/24 | AP_TRUNK | 40, 110, 120, 130 | 1000 | — |
| sw1 | Stack1 | sw2 | Stack2 | STACK | — | 80000 | — |
| sw1 | Stack2 | sw2 | Stack1 | STACK | — | 80000 | — |


| Puesto | Switch | Puerto | IP PC | IP teléfono | Reserva Wi-Fi PC | Reserva Wi-Fi voz |
| --- | --- | --- | --- | --- | --- | --- |
| s12-pc01 | 1 | 1 | 10.70.12.10 | 10.70.76.10 | 10.81.12.10 | 10.82.12.10 |
| s12-pc02 | 2 | 1 | 10.70.12.11 | 10.70.76.11 | 10.81.12.11 | 10.82.12.11 |
| s12-pc03 | 1 | 2 | 10.70.12.12 | 10.70.76.12 | 10.81.12.12 | 10.82.12.12 |
| s12-pc04 | 2 | 2 | 10.70.12.13 | 10.70.76.13 | 10.81.12.13 | 10.82.12.13 |
| s12-pc05 | 1 | 3 | 10.70.12.14 | 10.70.76.14 | 10.81.12.14 | 10.82.12.14 |
| s12-pc06 | 2 | 3 | 10.70.12.15 | 10.70.76.15 | 10.81.12.15 | 10.82.12.15 |
| s12-pc07 | 1 | 4 | 10.70.12.16 | 10.70.76.16 | 10.81.12.16 | 10.82.12.16 |
| s12-pc08 | 2 | 4 | 10.70.12.17 | 10.70.76.17 | 10.81.12.17 | 10.82.12.17 |
| s12-pc09 | 1 | 5 | 10.70.12.18 | 10.70.76.18 | 10.81.12.18 | 10.82.12.18 |
| s12-pc10 | 2 | 5 | 10.70.12.19 | 10.70.76.19 | 10.81.12.19 | 10.82.12.19 |
| s12-pc11 | 1 | 6 | 10.70.12.20 | 10.70.76.20 | 10.81.12.20 | 10.82.12.20 |
| s12-pc12 | 2 | 6 | 10.70.12.21 | 10.70.76.21 | 10.81.12.21 | 10.82.12.21 |
| s12-pc13 | 1 | 7 | 10.70.12.22 | 10.70.76.22 | 10.81.12.22 | 10.82.12.22 |
| s12-pc14 | 2 | 7 | 10.70.12.23 | 10.70.76.23 | 10.81.12.23 | 10.82.12.23 |
| s12-pc15 | 1 | 8 | 10.70.12.24 | 10.70.76.24 | 10.81.12.24 | 10.82.12.24 |
| s12-pc16 | 2 | 8 | 10.70.12.25 | 10.70.76.25 | 10.81.12.25 | 10.82.12.25 |
| s12-pc17 | 1 | 9 | 10.70.12.26 | 10.70.76.26 | 10.81.12.26 | 10.82.12.26 |
| s12-pc18 | 2 | 9 | 10.70.12.27 | 10.70.76.27 | 10.81.12.27 | 10.82.12.27 |
| s12-pc19 | 1 | 10 | 10.70.12.28 | 10.70.76.28 | 10.81.12.28 | 10.82.12.28 |
| s12-pc20 | 2 | 10 | 10.70.12.29 | 10.70.76.29 | 10.81.12.29 | 10.82.12.29 |
| s12-pc21 | 1 | 11 | 10.70.12.30 | 10.70.76.30 | 10.81.12.30 | 10.82.12.30 |
| s12-pc22 | 2 | 11 | 10.70.12.31 | 10.70.76.31 | 10.81.12.31 | 10.82.12.31 |
| s12-pc23 | 1 | 12 | 10.70.12.32 | 10.70.76.32 | 10.81.12.32 | 10.82.12.32 |
| s12-pc24 | 2 | 12 | 10.70.12.33 | 10.70.76.33 | 10.81.12.33 | 10.82.12.33 |
| s12-pc25 | 1 | 13 | 10.70.12.34 | 10.70.76.34 | 10.81.12.34 | 10.82.12.34 |
| s12-pc26 | 2 | 13 | 10.70.12.35 | 10.70.76.35 | 10.81.12.35 | 10.82.12.35 |
| s12-pc27 | 1 | 14 | 10.70.12.36 | 10.70.76.36 | 10.81.12.36 | 10.82.12.36 |
| s12-pc28 | 2 | 14 | 10.70.12.37 | 10.70.76.37 | 10.81.12.37 | 10.82.12.37 |


**Transporte starlink — VLAN 201 — wanA.**

| Rol de entrega | Dirección |
| --- | --- |
| network | 10.252.12.0/29 |
| cpe | 10.252.12.1 |
| r1 | 10.252.12.2 |
| r2 | 10.252.12.3 |


**Transporte leo — VLAN 202 — wanB.**

| Rol de entrega | Dirección |
| --- | --- |
| network | 10.252.12.8/29 |
| cpe | 10.252.12.9 |
| r1 | 10.252.12.10 |
| r2 | 10.252.12.11 |


**Transporte entel5g — VLAN 203 — wanA.**

| Rol de entrega | Dirección |
| --- | --- |
| network | 10.252.12.16/29 |
| cpe | 10.252.12.17 |
| r1 | 10.252.12.18 |
| r2 | 10.252.12.19 |


**Transporte wom4g — VLAN 204 — wanB.**

| Rol de entrega | Dirección |
| --- | --- |
| network | 10.252.12.24/29 |
| cpe | 10.252.12.25 |
| r1 | 10.252.12.26 |
| r2 | 10.252.12.27 |


**Reservas de túneles (numeración según lista de la ficha).**

| Rol / candidato | Dirección |
| --- | --- |
| .1.hub_public_ip | 198.51.100.4 |
| .1.network | 10.253.12.0/30 |
| .1.branch_ip | 10.253.12.1 |
| .1.hub_ip | 10.253.12.2 |
| .2.hub_public_ip | 203.0.113.4 |
| .2.network | 10.253.12.4/30 |
| .2.branch_ip | 10.253.12.5 |
| .2.hub_ip | 10.253.12.6 |
| .3.hub_public_ip | 198.51.100.4 |
| .3.network | 10.253.12.8/30 |
| .3.branch_ip | 10.253.12.9 |
| .3.hub_ip | 10.253.12.10 |
| .4.hub_public_ip | 203.0.113.4 |
| .4.network | 10.253.12.12/30 |
| .4.branch_ip | 10.253.12.13 |
| .4.hub_ip | 10.253.12.14 |
| .5.hub_public_ip | 198.51.100.4 |
| .5.network | 10.253.12.16/30 |
| .5.branch_ip | 10.253.12.17 |
| .5.hub_ip | 10.253.12.18 |
| .6.hub_public_ip | 203.0.113.4 |
| .6.network | 10.253.12.20/30 |
| .6.branch_ip | 10.253.12.21 |
| .6.hub_ip | 10.253.12.22 |
| .7.hub_public_ip | 198.51.100.4 |
| .7.network | 10.253.12.24/30 |
| .7.branch_ip | 10.253.12.25 |
| .7.hub_ip | 10.253.12.26 |
| .8.hub_public_ip | 203.0.113.4 |
| .8.network | 10.253.12.28/30 |
| .8.branch_ip | 10.253.12.29 |
| .8.hub_ip | 10.253.12.30 |
| .9.hub_public_ip | 198.51.100.4 |
| .9.network | 10.253.12.32/30 |
| .9.branch_ip | 10.253.12.33 |
| .9.hub_ip | 10.253.12.34 |
| .10.hub_public_ip | 203.0.113.4 |
| .10.network | 10.253.12.36/30 |
| .10.branch_ip | 10.253.12.37 |
| .10.hub_ip | 10.253.12.38 |
| .11.hub_public_ip | 198.51.100.4 |
| .11.network | 10.253.12.40/30 |
| .11.branch_ip | 10.253.12.41 |
| .11.hub_ip | 10.253.12.42 |
| .12.hub_public_ip | 203.0.113.4 |
| .12.network | 10.253.12.44/30 |
| .12.branch_ip | 10.253.12.45 |
| .12.hub_ip | 10.253.12.46 |
| .13.hub_public_ip | 198.51.100.4 |
| .13.network | 10.253.12.48/30 |
| .13.branch_ip | 10.253.12.49 |
| .13.hub_ip | 10.253.12.50 |
| .14.hub_public_ip | 203.0.113.4 |
| .14.network | 10.253.12.52/30 |
| .14.branch_ip | 10.253.12.53 |
| .14.hub_ip | 10.253.12.54 |
| .15.hub_public_ip | 198.51.100.4 |
| .15.network | 10.253.12.56/30 |
| .15.branch_ip | 10.253.12.57 |
| .15.hub_ip | 10.253.12.58 |
| .16.hub_public_ip | 203.0.113.4 |
| .16.network | 10.253.12.60/30 |
| .16.branch_ip | 10.253.12.61 |
| .16.hub_ip | 10.253.12.62 |

### S13 — Talca

28 PCs y 28 teléfonos existentes.

| Función | ANTES | DESPUÉS |
| --- | --- | --- |
| Routers | 1 × ISR4321/K9 | 2 × C1121X-8P |
| Switches | 1 × C9200L-48P-4G-E | C9200L-48P-4G-E + C9200L-24P-4G-E |
| Firewall | Sin equipo dedicado | Sin appliance remoto; seguridad central |
| Distribución WAN | MPLS y accesos ISP del escenario base | wanA: E50UG; wanB: E50UG |


| Red | VLAN | Subred | Gateway / roles |
| --- | --- | --- | --- |
| users | 10 | 10.70.13.0/25 | 10.70.13.1 |
| voice | 20 | 10.70.77.0/25 | 10.70.77.1 |
| guests | 40 | 10.70.109.0/26 | 10.70.109.1 |
| wifi_users | 110 | 10.81.13.0/25 | 10.81.13.1 |
| wifi_voice | 120 | 10.82.13.0/25 | 10.82.13.1 |
| management | 130 | 10.80.13.0/27 | 10.80.13.1 |


| Gestión | Dirección |
| --- | --- |
| sw1 | 10.80.13.1 |
| sw2 | 10.80.13.1 |
| r1 | 10.80.13.2 |
| r2 | 10.80.13.3 |
| wanA | 10.80.13.6 |
| wanB | 10.80.13.7 |
| ap1 | 10.80.13.24 |
| ap2 | 10.80.13.25 |


| Origen | Puerto | Destino | Puerto | Función | VLAN/red | Mbps | IP / agregado lógico |
| --- | --- | --- | --- | --- | --- | --- | --- |
| cpe:starlink | LAN | wanA | ether1 | WAN_ACCESS | 201 | 1000 | — |
| cpe:entel5g | LAN | wanA | ether2 | WAN_ACCESS | 203 | 1000 | — |
| r1 | GigabitEthernet0/0/0 | wanA | ether3 | WAN_TRUNK | 201, 203 | 1000 | — |
| r2 | GigabitEthernet0/0/0 | wanA | ether4 | WAN_TRUNK | 201, 203 | 1000 | — |
| wanA | ether5 | sw1 | Gi1/0/22 | MANAGEMENT_ACCESS | 130 | 1000 | — |
| cpe:leo | LAN | wanB | ether1 | WAN_ACCESS | 202 | 1000 | — |
| cpe:wom4g | LAN | wanB | ether2 | WAN_ACCESS | 204 | 1000 | — |
| r1 | GigabitEthernet0/0/1 | wanB | ether3 | WAN_TRUNK | 202, 204 | 1000 | — |
| r2 | GigabitEthernet0/0/1 | wanB | ether4 | WAN_TRUNK | 202, 204 | 1000 | — |
| wanB | ether5 | sw2 | Gi2/0/22 | MANAGEMENT_ACCESS | 130 | 1000 | — |
| r1 | GigabitEthernet0/1/0 | sw1 | Gi1/0/19 | LAN_ROUTED | 172.31.13.0/30 | 1000 | router_ip: 172.31.13.1; stack_ip: 172.31.13.2 |
| r1 | GigabitEthernet0/1/1 | sw2 | Gi2/0/19 | LAN_ROUTED | 172.31.13.4/30 | 1000 | router_ip: 172.31.13.5; stack_ip: 172.31.13.6 |
| r1 | GigabitEthernet0/1/2 | sw1 | Gi1/0/21 | MANAGEMENT_ACCESS | 130 | 1000 | — |
| r2 | GigabitEthernet0/1/0 | sw1 | Gi1/0/20 | LAN_ROUTED | 172.31.13.8/30 | 1000 | router_ip: 172.31.13.9; stack_ip: 172.31.13.10 |
| r2 | GigabitEthernet0/1/1 | sw2 | Gi2/0/20 | LAN_ROUTED | 172.31.13.12/30 | 1000 | router_ip: 172.31.13.13; stack_ip: 172.31.13.14 |
| r2 | GigabitEthernet0/1/2 | sw2 | Gi2/0/21 | MANAGEMENT_ACCESS | 130 | 1000 | — |
| ap1 | LAN | sw1 | Gi1/0/24 | AP_TRUNK | 40, 110, 120, 130 | 1000 | — |
| ap2 | LAN | sw2 | Gi2/0/24 | AP_TRUNK | 40, 110, 120, 130 | 1000 | — |
| sw1 | Stack1 | sw2 | Stack2 | STACK | — | 80000 | — |
| sw1 | Stack2 | sw2 | Stack1 | STACK | — | 80000 | — |


| Puesto | Switch | Puerto | IP PC | IP teléfono | Reserva Wi-Fi PC | Reserva Wi-Fi voz |
| --- | --- | --- | --- | --- | --- | --- |
| s13-pc01 | 1 | 1 | 10.70.13.10 | 10.70.77.10 | 10.81.13.10 | 10.82.13.10 |
| s13-pc02 | 2 | 1 | 10.70.13.11 | 10.70.77.11 | 10.81.13.11 | 10.82.13.11 |
| s13-pc03 | 1 | 2 | 10.70.13.12 | 10.70.77.12 | 10.81.13.12 | 10.82.13.12 |
| s13-pc04 | 2 | 2 | 10.70.13.13 | 10.70.77.13 | 10.81.13.13 | 10.82.13.13 |
| s13-pc05 | 1 | 3 | 10.70.13.14 | 10.70.77.14 | 10.81.13.14 | 10.82.13.14 |
| s13-pc06 | 2 | 3 | 10.70.13.15 | 10.70.77.15 | 10.81.13.15 | 10.82.13.15 |
| s13-pc07 | 1 | 4 | 10.70.13.16 | 10.70.77.16 | 10.81.13.16 | 10.82.13.16 |
| s13-pc08 | 2 | 4 | 10.70.13.17 | 10.70.77.17 | 10.81.13.17 | 10.82.13.17 |
| s13-pc09 | 1 | 5 | 10.70.13.18 | 10.70.77.18 | 10.81.13.18 | 10.82.13.18 |
| s13-pc10 | 2 | 5 | 10.70.13.19 | 10.70.77.19 | 10.81.13.19 | 10.82.13.19 |
| s13-pc11 | 1 | 6 | 10.70.13.20 | 10.70.77.20 | 10.81.13.20 | 10.82.13.20 |
| s13-pc12 | 2 | 6 | 10.70.13.21 | 10.70.77.21 | 10.81.13.21 | 10.82.13.21 |
| s13-pc13 | 1 | 7 | 10.70.13.22 | 10.70.77.22 | 10.81.13.22 | 10.82.13.22 |
| s13-pc14 | 2 | 7 | 10.70.13.23 | 10.70.77.23 | 10.81.13.23 | 10.82.13.23 |
| s13-pc15 | 1 | 8 | 10.70.13.24 | 10.70.77.24 | 10.81.13.24 | 10.82.13.24 |
| s13-pc16 | 2 | 8 | 10.70.13.25 | 10.70.77.25 | 10.81.13.25 | 10.82.13.25 |
| s13-pc17 | 1 | 9 | 10.70.13.26 | 10.70.77.26 | 10.81.13.26 | 10.82.13.26 |
| s13-pc18 | 2 | 9 | 10.70.13.27 | 10.70.77.27 | 10.81.13.27 | 10.82.13.27 |
| s13-pc19 | 1 | 10 | 10.70.13.28 | 10.70.77.28 | 10.81.13.28 | 10.82.13.28 |
| s13-pc20 | 2 | 10 | 10.70.13.29 | 10.70.77.29 | 10.81.13.29 | 10.82.13.29 |
| s13-pc21 | 1 | 11 | 10.70.13.30 | 10.70.77.30 | 10.81.13.30 | 10.82.13.30 |
| s13-pc22 | 2 | 11 | 10.70.13.31 | 10.70.77.31 | 10.81.13.31 | 10.82.13.31 |
| s13-pc23 | 1 | 12 | 10.70.13.32 | 10.70.77.32 | 10.81.13.32 | 10.82.13.32 |
| s13-pc24 | 2 | 12 | 10.70.13.33 | 10.70.77.33 | 10.81.13.33 | 10.82.13.33 |
| s13-pc25 | 1 | 13 | 10.70.13.34 | 10.70.77.34 | 10.81.13.34 | 10.82.13.34 |
| s13-pc26 | 2 | 13 | 10.70.13.35 | 10.70.77.35 | 10.81.13.35 | 10.82.13.35 |
| s13-pc27 | 1 | 14 | 10.70.13.36 | 10.70.77.36 | 10.81.13.36 | 10.82.13.36 |
| s13-pc28 | 2 | 14 | 10.70.13.37 | 10.70.77.37 | 10.81.13.37 | 10.82.13.37 |


**Transporte starlink — VLAN 201 — wanA.**

| Rol de entrega | Dirección |
| --- | --- |
| network | 10.252.13.0/29 |
| cpe | 10.252.13.1 |
| r1 | 10.252.13.2 |
| r2 | 10.252.13.3 |


**Transporte leo — VLAN 202 — wanB.**

| Rol de entrega | Dirección |
| --- | --- |
| network | 10.252.13.8/29 |
| cpe | 10.252.13.9 |
| r1 | 10.252.13.10 |
| r2 | 10.252.13.11 |


**Transporte entel5g — VLAN 203 — wanA.**

| Rol de entrega | Dirección |
| --- | --- |
| network | 10.252.13.16/29 |
| cpe | 10.252.13.17 |
| r1 | 10.252.13.18 |
| r2 | 10.252.13.19 |


**Transporte wom4g — VLAN 204 — wanB.**

| Rol de entrega | Dirección |
| --- | --- |
| network | 10.252.13.24/29 |
| cpe | 10.252.13.25 |
| r1 | 10.252.13.26 |
| r2 | 10.252.13.27 |


**Reservas de túneles (numeración según lista de la ficha).**

| Rol / candidato | Dirección |
| --- | --- |
| .1.hub_public_ip | 198.51.100.4 |
| .1.network | 10.253.13.0/30 |
| .1.branch_ip | 10.253.13.1 |
| .1.hub_ip | 10.253.13.2 |
| .2.hub_public_ip | 203.0.113.4 |
| .2.network | 10.253.13.4/30 |
| .2.branch_ip | 10.253.13.5 |
| .2.hub_ip | 10.253.13.6 |
| .3.hub_public_ip | 198.51.100.4 |
| .3.network | 10.253.13.8/30 |
| .3.branch_ip | 10.253.13.9 |
| .3.hub_ip | 10.253.13.10 |
| .4.hub_public_ip | 203.0.113.4 |
| .4.network | 10.253.13.12/30 |
| .4.branch_ip | 10.253.13.13 |
| .4.hub_ip | 10.253.13.14 |
| .5.hub_public_ip | 198.51.100.4 |
| .5.network | 10.253.13.16/30 |
| .5.branch_ip | 10.253.13.17 |
| .5.hub_ip | 10.253.13.18 |
| .6.hub_public_ip | 203.0.113.4 |
| .6.network | 10.253.13.20/30 |
| .6.branch_ip | 10.253.13.21 |
| .6.hub_ip | 10.253.13.22 |
| .7.hub_public_ip | 198.51.100.4 |
| .7.network | 10.253.13.24/30 |
| .7.branch_ip | 10.253.13.25 |
| .7.hub_ip | 10.253.13.26 |
| .8.hub_public_ip | 203.0.113.4 |
| .8.network | 10.253.13.28/30 |
| .8.branch_ip | 10.253.13.29 |
| .8.hub_ip | 10.253.13.30 |
| .9.hub_public_ip | 198.51.100.4 |
| .9.network | 10.253.13.32/30 |
| .9.branch_ip | 10.253.13.33 |
| .9.hub_ip | 10.253.13.34 |
| .10.hub_public_ip | 203.0.113.4 |
| .10.network | 10.253.13.36/30 |
| .10.branch_ip | 10.253.13.37 |
| .10.hub_ip | 10.253.13.38 |
| .11.hub_public_ip | 198.51.100.4 |
| .11.network | 10.253.13.40/30 |
| .11.branch_ip | 10.253.13.41 |
| .11.hub_ip | 10.253.13.42 |
| .12.hub_public_ip | 203.0.113.4 |
| .12.network | 10.253.13.44/30 |
| .12.branch_ip | 10.253.13.45 |
| .12.hub_ip | 10.253.13.46 |
| .13.hub_public_ip | 198.51.100.4 |
| .13.network | 10.253.13.48/30 |
| .13.branch_ip | 10.253.13.49 |
| .13.hub_ip | 10.253.13.50 |
| .14.hub_public_ip | 203.0.113.4 |
| .14.network | 10.253.13.52/30 |
| .14.branch_ip | 10.253.13.53 |
| .14.hub_ip | 10.253.13.54 |
| .15.hub_public_ip | 198.51.100.4 |
| .15.network | 10.253.13.56/30 |
| .15.branch_ip | 10.253.13.57 |
| .15.hub_ip | 10.253.13.58 |
| .16.hub_public_ip | 203.0.113.4 |
| .16.network | 10.253.13.60/30 |
| .16.branch_ip | 10.253.13.61 |
| .16.hub_ip | 10.253.13.62 |

### S14 — Chillán

28 PCs y 28 teléfonos existentes.

| Función | ANTES | DESPUÉS |
| --- | --- | --- |
| Routers | 1 × C1121X-8P | 2 × C1121X-8P |
| Switches | 1 × C9200L-48P-4G-E | C9200L-48P-4G-E + C9200L-24P-4G-E |
| Firewall | Sin equipo dedicado | Sin appliance remoto; seguridad central |
| Distribución WAN | MPLS y accesos ISP del escenario base | wanA: E50UG; wanB: E50UG |


| Red | VLAN | Subred | Gateway / roles |
| --- | --- | --- | --- |
| users | 10 | 10.70.14.0/25 | 10.70.14.1 |
| voice | 20 | 10.70.78.0/25 | 10.70.78.1 |
| guests | 40 | 10.70.110.0/26 | 10.70.110.1 |
| wifi_users | 110 | 10.81.14.0/25 | 10.81.14.1 |
| wifi_voice | 120 | 10.82.14.0/25 | 10.82.14.1 |
| management | 130 | 10.80.14.0/27 | 10.80.14.1 |


| Gestión | Dirección |
| --- | --- |
| sw1 | 10.80.14.1 |
| sw2 | 10.80.14.1 |
| r1 | 10.80.14.2 |
| r2 | 10.80.14.3 |
| wanA | 10.80.14.6 |
| wanB | 10.80.14.7 |
| ap1 | 10.80.14.24 |
| ap2 | 10.80.14.25 |


| Origen | Puerto | Destino | Puerto | Función | VLAN/red | Mbps | IP / agregado lógico |
| --- | --- | --- | --- | --- | --- | --- | --- |
| cpe:starlink | LAN | wanA | ether1 | WAN_ACCESS | 201 | 1000 | — |
| cpe:entel5g | LAN | wanA | ether2 | WAN_ACCESS | 203 | 1000 | — |
| r1 | GigabitEthernet0/0/0 | wanA | ether3 | WAN_TRUNK | 201, 203 | 1000 | — |
| r2 | GigabitEthernet0/0/0 | wanA | ether4 | WAN_TRUNK | 201, 203 | 1000 | — |
| wanA | ether5 | sw1 | Gi1/0/22 | MANAGEMENT_ACCESS | 130 | 1000 | — |
| cpe:leo | LAN | wanB | ether1 | WAN_ACCESS | 202 | 1000 | — |
| cpe:wom4g | LAN | wanB | ether2 | WAN_ACCESS | 204 | 1000 | — |
| r1 | GigabitEthernet0/0/1 | wanB | ether3 | WAN_TRUNK | 202, 204 | 1000 | — |
| r2 | GigabitEthernet0/0/1 | wanB | ether4 | WAN_TRUNK | 202, 204 | 1000 | — |
| wanB | ether5 | sw2 | Gi2/0/22 | MANAGEMENT_ACCESS | 130 | 1000 | — |
| r1 | GigabitEthernet0/1/0 | sw1 | Gi1/0/19 | LAN_ROUTED | 172.31.14.0/30 | 1000 | router_ip: 172.31.14.1; stack_ip: 172.31.14.2 |
| r1 | GigabitEthernet0/1/1 | sw2 | Gi2/0/19 | LAN_ROUTED | 172.31.14.4/30 | 1000 | router_ip: 172.31.14.5; stack_ip: 172.31.14.6 |
| r1 | GigabitEthernet0/1/2 | sw1 | Gi1/0/21 | MANAGEMENT_ACCESS | 130 | 1000 | — |
| r2 | GigabitEthernet0/1/0 | sw1 | Gi1/0/20 | LAN_ROUTED | 172.31.14.8/30 | 1000 | router_ip: 172.31.14.9; stack_ip: 172.31.14.10 |
| r2 | GigabitEthernet0/1/1 | sw2 | Gi2/0/20 | LAN_ROUTED | 172.31.14.12/30 | 1000 | router_ip: 172.31.14.13; stack_ip: 172.31.14.14 |
| r2 | GigabitEthernet0/1/2 | sw2 | Gi2/0/21 | MANAGEMENT_ACCESS | 130 | 1000 | — |
| ap1 | LAN | sw1 | Gi1/0/24 | AP_TRUNK | 40, 110, 120, 130 | 1000 | — |
| ap2 | LAN | sw2 | Gi2/0/24 | AP_TRUNK | 40, 110, 120, 130 | 1000 | — |
| sw1 | Stack1 | sw2 | Stack2 | STACK | — | 80000 | — |
| sw1 | Stack2 | sw2 | Stack1 | STACK | — | 80000 | — |


| Puesto | Switch | Puerto | IP PC | IP teléfono | Reserva Wi-Fi PC | Reserva Wi-Fi voz |
| --- | --- | --- | --- | --- | --- | --- |
| s14-pc01 | 1 | 1 | 10.70.14.10 | 10.70.78.10 | 10.81.14.10 | 10.82.14.10 |
| s14-pc02 | 2 | 1 | 10.70.14.11 | 10.70.78.11 | 10.81.14.11 | 10.82.14.11 |
| s14-pc03 | 1 | 2 | 10.70.14.12 | 10.70.78.12 | 10.81.14.12 | 10.82.14.12 |
| s14-pc04 | 2 | 2 | 10.70.14.13 | 10.70.78.13 | 10.81.14.13 | 10.82.14.13 |
| s14-pc05 | 1 | 3 | 10.70.14.14 | 10.70.78.14 | 10.81.14.14 | 10.82.14.14 |
| s14-pc06 | 2 | 3 | 10.70.14.15 | 10.70.78.15 | 10.81.14.15 | 10.82.14.15 |
| s14-pc07 | 1 | 4 | 10.70.14.16 | 10.70.78.16 | 10.81.14.16 | 10.82.14.16 |
| s14-pc08 | 2 | 4 | 10.70.14.17 | 10.70.78.17 | 10.81.14.17 | 10.82.14.17 |
| s14-pc09 | 1 | 5 | 10.70.14.18 | 10.70.78.18 | 10.81.14.18 | 10.82.14.18 |
| s14-pc10 | 2 | 5 | 10.70.14.19 | 10.70.78.19 | 10.81.14.19 | 10.82.14.19 |
| s14-pc11 | 1 | 6 | 10.70.14.20 | 10.70.78.20 | 10.81.14.20 | 10.82.14.20 |
| s14-pc12 | 2 | 6 | 10.70.14.21 | 10.70.78.21 | 10.81.14.21 | 10.82.14.21 |
| s14-pc13 | 1 | 7 | 10.70.14.22 | 10.70.78.22 | 10.81.14.22 | 10.82.14.22 |
| s14-pc14 | 2 | 7 | 10.70.14.23 | 10.70.78.23 | 10.81.14.23 | 10.82.14.23 |
| s14-pc15 | 1 | 8 | 10.70.14.24 | 10.70.78.24 | 10.81.14.24 | 10.82.14.24 |
| s14-pc16 | 2 | 8 | 10.70.14.25 | 10.70.78.25 | 10.81.14.25 | 10.82.14.25 |
| s14-pc17 | 1 | 9 | 10.70.14.26 | 10.70.78.26 | 10.81.14.26 | 10.82.14.26 |
| s14-pc18 | 2 | 9 | 10.70.14.27 | 10.70.78.27 | 10.81.14.27 | 10.82.14.27 |
| s14-pc19 | 1 | 10 | 10.70.14.28 | 10.70.78.28 | 10.81.14.28 | 10.82.14.28 |
| s14-pc20 | 2 | 10 | 10.70.14.29 | 10.70.78.29 | 10.81.14.29 | 10.82.14.29 |
| s14-pc21 | 1 | 11 | 10.70.14.30 | 10.70.78.30 | 10.81.14.30 | 10.82.14.30 |
| s14-pc22 | 2 | 11 | 10.70.14.31 | 10.70.78.31 | 10.81.14.31 | 10.82.14.31 |
| s14-pc23 | 1 | 12 | 10.70.14.32 | 10.70.78.32 | 10.81.14.32 | 10.82.14.32 |
| s14-pc24 | 2 | 12 | 10.70.14.33 | 10.70.78.33 | 10.81.14.33 | 10.82.14.33 |
| s14-pc25 | 1 | 13 | 10.70.14.34 | 10.70.78.34 | 10.81.14.34 | 10.82.14.34 |
| s14-pc26 | 2 | 13 | 10.70.14.35 | 10.70.78.35 | 10.81.14.35 | 10.82.14.35 |
| s14-pc27 | 1 | 14 | 10.70.14.36 | 10.70.78.36 | 10.81.14.36 | 10.82.14.36 |
| s14-pc28 | 2 | 14 | 10.70.14.37 | 10.70.78.37 | 10.81.14.37 | 10.82.14.37 |


**Transporte starlink — VLAN 201 — wanA.**

| Rol de entrega | Dirección |
| --- | --- |
| network | 10.252.14.0/29 |
| cpe | 10.252.14.1 |
| r1 | 10.252.14.2 |
| r2 | 10.252.14.3 |


**Transporte leo — VLAN 202 — wanB.**

| Rol de entrega | Dirección |
| --- | --- |
| network | 10.252.14.8/29 |
| cpe | 10.252.14.9 |
| r1 | 10.252.14.10 |
| r2 | 10.252.14.11 |


**Transporte entel5g — VLAN 203 — wanA.**

| Rol de entrega | Dirección |
| --- | --- |
| network | 10.252.14.16/29 |
| cpe | 10.252.14.17 |
| r1 | 10.252.14.18 |
| r2 | 10.252.14.19 |


**Transporte wom4g — VLAN 204 — wanB.**

| Rol de entrega | Dirección |
| --- | --- |
| network | 10.252.14.24/29 |
| cpe | 10.252.14.25 |
| r1 | 10.252.14.26 |
| r2 | 10.252.14.27 |


**Reservas de túneles (numeración según lista de la ficha).**

| Rol / candidato | Dirección |
| --- | --- |
| .1.hub_public_ip | 198.51.100.4 |
| .1.network | 10.253.14.0/30 |
| .1.branch_ip | 10.253.14.1 |
| .1.hub_ip | 10.253.14.2 |
| .2.hub_public_ip | 203.0.113.4 |
| .2.network | 10.253.14.4/30 |
| .2.branch_ip | 10.253.14.5 |
| .2.hub_ip | 10.253.14.6 |
| .3.hub_public_ip | 198.51.100.4 |
| .3.network | 10.253.14.8/30 |
| .3.branch_ip | 10.253.14.9 |
| .3.hub_ip | 10.253.14.10 |
| .4.hub_public_ip | 203.0.113.4 |
| .4.network | 10.253.14.12/30 |
| .4.branch_ip | 10.253.14.13 |
| .4.hub_ip | 10.253.14.14 |
| .5.hub_public_ip | 198.51.100.4 |
| .5.network | 10.253.14.16/30 |
| .5.branch_ip | 10.253.14.17 |
| .5.hub_ip | 10.253.14.18 |
| .6.hub_public_ip | 203.0.113.4 |
| .6.network | 10.253.14.20/30 |
| .6.branch_ip | 10.253.14.21 |
| .6.hub_ip | 10.253.14.22 |
| .7.hub_public_ip | 198.51.100.4 |
| .7.network | 10.253.14.24/30 |
| .7.branch_ip | 10.253.14.25 |
| .7.hub_ip | 10.253.14.26 |
| .8.hub_public_ip | 203.0.113.4 |
| .8.network | 10.253.14.28/30 |
| .8.branch_ip | 10.253.14.29 |
| .8.hub_ip | 10.253.14.30 |
| .9.hub_public_ip | 198.51.100.4 |
| .9.network | 10.253.14.32/30 |
| .9.branch_ip | 10.253.14.33 |
| .9.hub_ip | 10.253.14.34 |
| .10.hub_public_ip | 203.0.113.4 |
| .10.network | 10.253.14.36/30 |
| .10.branch_ip | 10.253.14.37 |
| .10.hub_ip | 10.253.14.38 |
| .11.hub_public_ip | 198.51.100.4 |
| .11.network | 10.253.14.40/30 |
| .11.branch_ip | 10.253.14.41 |
| .11.hub_ip | 10.253.14.42 |
| .12.hub_public_ip | 203.0.113.4 |
| .12.network | 10.253.14.44/30 |
| .12.branch_ip | 10.253.14.45 |
| .12.hub_ip | 10.253.14.46 |
| .13.hub_public_ip | 198.51.100.4 |
| .13.network | 10.253.14.48/30 |
| .13.branch_ip | 10.253.14.49 |
| .13.hub_ip | 10.253.14.50 |
| .14.hub_public_ip | 203.0.113.4 |
| .14.network | 10.253.14.52/30 |
| .14.branch_ip | 10.253.14.53 |
| .14.hub_ip | 10.253.14.54 |
| .15.hub_public_ip | 198.51.100.4 |
| .15.network | 10.253.14.56/30 |
| .15.branch_ip | 10.253.14.57 |
| .15.hub_ip | 10.253.14.58 |
| .16.hub_public_ip | 203.0.113.4 |
| .16.network | 10.253.14.60/30 |
| .16.branch_ip | 10.253.14.61 |
| .16.hub_ip | 10.253.14.62 |

### S15 — Concepción

28 PCs y 28 teléfonos existentes.

| Función | ANTES | DESPUÉS |
| --- | --- | --- |
| Routers | 1 × CISCO1921-SEC/K9 | 2 × C1121X-8P |
| Switches | 1 × WS-C2960S-48LPS-L | C9200L-24P-4G-E + C9200L-24P-4G-E |
| Firewall | Sin equipo dedicado | Sin appliance remoto; seguridad central |
| Distribución WAN | MPLS y accesos ISP del escenario base | wanA: E50UG; wanB: E50UG |


| Red | VLAN | Subred | Gateway / roles |
| --- | --- | --- | --- |
| users | 10 | 10.70.15.0/25 | 10.70.15.1 |
| voice | 20 | 10.70.79.0/25 | 10.70.79.1 |
| guests | 40 | 10.70.111.0/26 | 10.70.111.1 |
| wifi_users | 110 | 10.81.15.0/25 | 10.81.15.1 |
| wifi_voice | 120 | 10.82.15.0/25 | 10.82.15.1 |
| management | 130 | 10.80.15.0/27 | 10.80.15.1 |


| Gestión | Dirección |
| --- | --- |
| sw1 | 10.80.15.1 |
| sw2 | 10.80.15.1 |
| r1 | 10.80.15.2 |
| r2 | 10.80.15.3 |
| wanA | 10.80.15.6 |
| wanB | 10.80.15.7 |
| ap1 | 10.80.15.24 |
| ap2 | 10.80.15.25 |


| Origen | Puerto | Destino | Puerto | Función | VLAN/red | Mbps | IP / agregado lógico |
| --- | --- | --- | --- | --- | --- | --- | --- |
| cpe:starlink | LAN | wanA | ether1 | WAN_ACCESS | 201 | 1000 | — |
| cpe:entel5g | LAN | wanA | ether2 | WAN_ACCESS | 203 | 1000 | — |
| r1 | GigabitEthernet0/0/0 | wanA | ether3 | WAN_TRUNK | 201, 203 | 1000 | — |
| r2 | GigabitEthernet0/0/0 | wanA | ether4 | WAN_TRUNK | 201, 203 | 1000 | — |
| wanA | ether5 | sw1 | Gi1/0/22 | MANAGEMENT_ACCESS | 130 | 1000 | — |
| cpe:leo | LAN | wanB | ether1 | WAN_ACCESS | 202 | 1000 | — |
| cpe:wom4g | LAN | wanB | ether2 | WAN_ACCESS | 204 | 1000 | — |
| r1 | GigabitEthernet0/0/1 | wanB | ether3 | WAN_TRUNK | 202, 204 | 1000 | — |
| r2 | GigabitEthernet0/0/1 | wanB | ether4 | WAN_TRUNK | 202, 204 | 1000 | — |
| wanB | ether5 | sw2 | Gi2/0/22 | MANAGEMENT_ACCESS | 130 | 1000 | — |
| r1 | GigabitEthernet0/1/0 | sw1 | Gi1/0/19 | LAN_ROUTED | 172.31.15.0/30 | 1000 | router_ip: 172.31.15.1; stack_ip: 172.31.15.2 |
| r1 | GigabitEthernet0/1/1 | sw2 | Gi2/0/19 | LAN_ROUTED | 172.31.15.4/30 | 1000 | router_ip: 172.31.15.5; stack_ip: 172.31.15.6 |
| r1 | GigabitEthernet0/1/2 | sw1 | Gi1/0/21 | MANAGEMENT_ACCESS | 130 | 1000 | — |
| r2 | GigabitEthernet0/1/0 | sw1 | Gi1/0/20 | LAN_ROUTED | 172.31.15.8/30 | 1000 | router_ip: 172.31.15.9; stack_ip: 172.31.15.10 |
| r2 | GigabitEthernet0/1/1 | sw2 | Gi2/0/20 | LAN_ROUTED | 172.31.15.12/30 | 1000 | router_ip: 172.31.15.13; stack_ip: 172.31.15.14 |
| r2 | GigabitEthernet0/1/2 | sw2 | Gi2/0/21 | MANAGEMENT_ACCESS | 130 | 1000 | — |
| ap1 | LAN | sw1 | Gi1/0/24 | AP_TRUNK | 40, 110, 120, 130 | 1000 | — |
| ap2 | LAN | sw2 | Gi2/0/24 | AP_TRUNK | 40, 110, 120, 130 | 1000 | — |
| sw1 | Stack1 | sw2 | Stack2 | STACK | — | 80000 | — |
| sw1 | Stack2 | sw2 | Stack1 | STACK | — | 80000 | — |


| Puesto | Switch | Puerto | IP PC | IP teléfono | Reserva Wi-Fi PC | Reserva Wi-Fi voz |
| --- | --- | --- | --- | --- | --- | --- |
| s15-pc01 | 1 | 1 | 10.70.15.10 | 10.70.79.10 | 10.81.15.10 | 10.82.15.10 |
| s15-pc02 | 2 | 1 | 10.70.15.11 | 10.70.79.11 | 10.81.15.11 | 10.82.15.11 |
| s15-pc03 | 1 | 2 | 10.70.15.12 | 10.70.79.12 | 10.81.15.12 | 10.82.15.12 |
| s15-pc04 | 2 | 2 | 10.70.15.13 | 10.70.79.13 | 10.81.15.13 | 10.82.15.13 |
| s15-pc05 | 1 | 3 | 10.70.15.14 | 10.70.79.14 | 10.81.15.14 | 10.82.15.14 |
| s15-pc06 | 2 | 3 | 10.70.15.15 | 10.70.79.15 | 10.81.15.15 | 10.82.15.15 |
| s15-pc07 | 1 | 4 | 10.70.15.16 | 10.70.79.16 | 10.81.15.16 | 10.82.15.16 |
| s15-pc08 | 2 | 4 | 10.70.15.17 | 10.70.79.17 | 10.81.15.17 | 10.82.15.17 |
| s15-pc09 | 1 | 5 | 10.70.15.18 | 10.70.79.18 | 10.81.15.18 | 10.82.15.18 |
| s15-pc10 | 2 | 5 | 10.70.15.19 | 10.70.79.19 | 10.81.15.19 | 10.82.15.19 |
| s15-pc11 | 1 | 6 | 10.70.15.20 | 10.70.79.20 | 10.81.15.20 | 10.82.15.20 |
| s15-pc12 | 2 | 6 | 10.70.15.21 | 10.70.79.21 | 10.81.15.21 | 10.82.15.21 |
| s15-pc13 | 1 | 7 | 10.70.15.22 | 10.70.79.22 | 10.81.15.22 | 10.82.15.22 |
| s15-pc14 | 2 | 7 | 10.70.15.23 | 10.70.79.23 | 10.81.15.23 | 10.82.15.23 |
| s15-pc15 | 1 | 8 | 10.70.15.24 | 10.70.79.24 | 10.81.15.24 | 10.82.15.24 |
| s15-pc16 | 2 | 8 | 10.70.15.25 | 10.70.79.25 | 10.81.15.25 | 10.82.15.25 |
| s15-pc17 | 1 | 9 | 10.70.15.26 | 10.70.79.26 | 10.81.15.26 | 10.82.15.26 |
| s15-pc18 | 2 | 9 | 10.70.15.27 | 10.70.79.27 | 10.81.15.27 | 10.82.15.27 |
| s15-pc19 | 1 | 10 | 10.70.15.28 | 10.70.79.28 | 10.81.15.28 | 10.82.15.28 |
| s15-pc20 | 2 | 10 | 10.70.15.29 | 10.70.79.29 | 10.81.15.29 | 10.82.15.29 |
| s15-pc21 | 1 | 11 | 10.70.15.30 | 10.70.79.30 | 10.81.15.30 | 10.82.15.30 |
| s15-pc22 | 2 | 11 | 10.70.15.31 | 10.70.79.31 | 10.81.15.31 | 10.82.15.31 |
| s15-pc23 | 1 | 12 | 10.70.15.32 | 10.70.79.32 | 10.81.15.32 | 10.82.15.32 |
| s15-pc24 | 2 | 12 | 10.70.15.33 | 10.70.79.33 | 10.81.15.33 | 10.82.15.33 |
| s15-pc25 | 1 | 13 | 10.70.15.34 | 10.70.79.34 | 10.81.15.34 | 10.82.15.34 |
| s15-pc26 | 2 | 13 | 10.70.15.35 | 10.70.79.35 | 10.81.15.35 | 10.82.15.35 |
| s15-pc27 | 1 | 14 | 10.70.15.36 | 10.70.79.36 | 10.81.15.36 | 10.82.15.36 |
| s15-pc28 | 2 | 14 | 10.70.15.37 | 10.70.79.37 | 10.81.15.37 | 10.82.15.37 |


**Transporte starlink — VLAN 201 — wanA.**

| Rol de entrega | Dirección |
| --- | --- |
| network | 10.252.15.0/29 |
| cpe | 10.252.15.1 |
| r1 | 10.252.15.2 |
| r2 | 10.252.15.3 |


**Transporte leo — VLAN 202 — wanB.**

| Rol de entrega | Dirección |
| --- | --- |
| network | 10.252.15.8/29 |
| cpe | 10.252.15.9 |
| r1 | 10.252.15.10 |
| r2 | 10.252.15.11 |


**Transporte entel5g — VLAN 203 — wanA.**

| Rol de entrega | Dirección |
| --- | --- |
| network | 10.252.15.16/29 |
| cpe | 10.252.15.17 |
| r1 | 10.252.15.18 |
| r2 | 10.252.15.19 |


**Transporte wom4g — VLAN 204 — wanB.**

| Rol de entrega | Dirección |
| --- | --- |
| network | 10.252.15.24/29 |
| cpe | 10.252.15.25 |
| r1 | 10.252.15.26 |
| r2 | 10.252.15.27 |


**Reservas de túneles (numeración según lista de la ficha).**

| Rol / candidato | Dirección |
| --- | --- |
| .1.hub_public_ip | 198.51.100.4 |
| .1.network | 10.253.15.0/30 |
| .1.branch_ip | 10.253.15.1 |
| .1.hub_ip | 10.253.15.2 |
| .2.hub_public_ip | 203.0.113.4 |
| .2.network | 10.253.15.4/30 |
| .2.branch_ip | 10.253.15.5 |
| .2.hub_ip | 10.253.15.6 |
| .3.hub_public_ip | 198.51.100.4 |
| .3.network | 10.253.15.8/30 |
| .3.branch_ip | 10.253.15.9 |
| .3.hub_ip | 10.253.15.10 |
| .4.hub_public_ip | 203.0.113.4 |
| .4.network | 10.253.15.12/30 |
| .4.branch_ip | 10.253.15.13 |
| .4.hub_ip | 10.253.15.14 |
| .5.hub_public_ip | 198.51.100.4 |
| .5.network | 10.253.15.16/30 |
| .5.branch_ip | 10.253.15.17 |
| .5.hub_ip | 10.253.15.18 |
| .6.hub_public_ip | 203.0.113.4 |
| .6.network | 10.253.15.20/30 |
| .6.branch_ip | 10.253.15.21 |
| .6.hub_ip | 10.253.15.22 |
| .7.hub_public_ip | 198.51.100.4 |
| .7.network | 10.253.15.24/30 |
| .7.branch_ip | 10.253.15.25 |
| .7.hub_ip | 10.253.15.26 |
| .8.hub_public_ip | 203.0.113.4 |
| .8.network | 10.253.15.28/30 |
| .8.branch_ip | 10.253.15.29 |
| .8.hub_ip | 10.253.15.30 |
| .9.hub_public_ip | 198.51.100.4 |
| .9.network | 10.253.15.32/30 |
| .9.branch_ip | 10.253.15.33 |
| .9.hub_ip | 10.253.15.34 |
| .10.hub_public_ip | 203.0.113.4 |
| .10.network | 10.253.15.36/30 |
| .10.branch_ip | 10.253.15.37 |
| .10.hub_ip | 10.253.15.38 |
| .11.hub_public_ip | 198.51.100.4 |
| .11.network | 10.253.15.40/30 |
| .11.branch_ip | 10.253.15.41 |
| .11.hub_ip | 10.253.15.42 |
| .12.hub_public_ip | 203.0.113.4 |
| .12.network | 10.253.15.44/30 |
| .12.branch_ip | 10.253.15.45 |
| .12.hub_ip | 10.253.15.46 |
| .13.hub_public_ip | 198.51.100.4 |
| .13.network | 10.253.15.48/30 |
| .13.branch_ip | 10.253.15.49 |
| .13.hub_ip | 10.253.15.50 |
| .14.hub_public_ip | 203.0.113.4 |
| .14.network | 10.253.15.52/30 |
| .14.branch_ip | 10.253.15.53 |
| .14.hub_ip | 10.253.15.54 |
| .15.hub_public_ip | 198.51.100.4 |
| .15.network | 10.253.15.56/30 |
| .15.branch_ip | 10.253.15.57 |
| .15.hub_ip | 10.253.15.58 |
| .16.hub_public_ip | 203.0.113.4 |
| .16.network | 10.253.15.60/30 |
| .16.branch_ip | 10.253.15.61 |
| .16.hub_ip | 10.253.15.62 |

### S16 — Temuco

28 PCs y 28 teléfonos existentes.

| Función | ANTES | DESPUÉS |
| --- | --- | --- |
| Routers | 1 × ISR4321/K9 | 2 × C1121X-8P |
| Switches | 1 × C9200L-48P-4G-E | C9200L-48P-4G-E + C9200L-24P-4G-E |
| Firewall | Sin equipo dedicado | Sin appliance remoto; seguridad central |
| Distribución WAN | MPLS y accesos ISP del escenario base | wanA: E50UG; wanB: E50UG |


| Red | VLAN | Subred | Gateway / roles |
| --- | --- | --- | --- |
| users | 10 | 10.70.16.0/25 | 10.70.16.1 |
| voice | 20 | 10.70.80.0/25 | 10.70.80.1 |
| guests | 40 | 10.70.112.0/26 | 10.70.112.1 |
| wifi_users | 110 | 10.81.16.0/25 | 10.81.16.1 |
| wifi_voice | 120 | 10.82.16.0/25 | 10.82.16.1 |
| management | 130 | 10.80.16.0/27 | 10.80.16.1 |


| Gestión | Dirección |
| --- | --- |
| sw1 | 10.80.16.1 |
| sw2 | 10.80.16.1 |
| r1 | 10.80.16.2 |
| r2 | 10.80.16.3 |
| wanA | 10.80.16.6 |
| wanB | 10.80.16.7 |
| ap1 | 10.80.16.24 |
| ap2 | 10.80.16.25 |


| Origen | Puerto | Destino | Puerto | Función | VLAN/red | Mbps | IP / agregado lógico |
| --- | --- | --- | --- | --- | --- | --- | --- |
| cpe:starlink | LAN | wanA | ether1 | WAN_ACCESS | 201 | 1000 | — |
| cpe:entel5g | LAN | wanA | ether2 | WAN_ACCESS | 203 | 1000 | — |
| r1 | GigabitEthernet0/0/0 | wanA | ether3 | WAN_TRUNK | 201, 203 | 1000 | — |
| r2 | GigabitEthernet0/0/0 | wanA | ether4 | WAN_TRUNK | 201, 203 | 1000 | — |
| wanA | ether5 | sw1 | Gi1/0/22 | MANAGEMENT_ACCESS | 130 | 1000 | — |
| cpe:leo | LAN | wanB | ether1 | WAN_ACCESS | 202 | 1000 | — |
| cpe:wom4g | LAN | wanB | ether2 | WAN_ACCESS | 204 | 1000 | — |
| r1 | GigabitEthernet0/0/1 | wanB | ether3 | WAN_TRUNK | 202, 204 | 1000 | — |
| r2 | GigabitEthernet0/0/1 | wanB | ether4 | WAN_TRUNK | 202, 204 | 1000 | — |
| wanB | ether5 | sw2 | Gi2/0/22 | MANAGEMENT_ACCESS | 130 | 1000 | — |
| r1 | GigabitEthernet0/1/0 | sw1 | Gi1/0/19 | LAN_ROUTED | 172.31.16.0/30 | 1000 | router_ip: 172.31.16.1; stack_ip: 172.31.16.2 |
| r1 | GigabitEthernet0/1/1 | sw2 | Gi2/0/19 | LAN_ROUTED | 172.31.16.4/30 | 1000 | router_ip: 172.31.16.5; stack_ip: 172.31.16.6 |
| r1 | GigabitEthernet0/1/2 | sw1 | Gi1/0/21 | MANAGEMENT_ACCESS | 130 | 1000 | — |
| r2 | GigabitEthernet0/1/0 | sw1 | Gi1/0/20 | LAN_ROUTED | 172.31.16.8/30 | 1000 | router_ip: 172.31.16.9; stack_ip: 172.31.16.10 |
| r2 | GigabitEthernet0/1/1 | sw2 | Gi2/0/20 | LAN_ROUTED | 172.31.16.12/30 | 1000 | router_ip: 172.31.16.13; stack_ip: 172.31.16.14 |
| r2 | GigabitEthernet0/1/2 | sw2 | Gi2/0/21 | MANAGEMENT_ACCESS | 130 | 1000 | — |
| ap1 | LAN | sw1 | Gi1/0/24 | AP_TRUNK | 40, 110, 120, 130 | 1000 | — |
| ap2 | LAN | sw2 | Gi2/0/24 | AP_TRUNK | 40, 110, 120, 130 | 1000 | — |
| sw1 | Stack1 | sw2 | Stack2 | STACK | — | 80000 | — |
| sw1 | Stack2 | sw2 | Stack1 | STACK | — | 80000 | — |


| Puesto | Switch | Puerto | IP PC | IP teléfono | Reserva Wi-Fi PC | Reserva Wi-Fi voz |
| --- | --- | --- | --- | --- | --- | --- |
| s16-pc01 | 1 | 1 | 10.70.16.10 | 10.70.80.10 | 10.81.16.10 | 10.82.16.10 |
| s16-pc02 | 2 | 1 | 10.70.16.11 | 10.70.80.11 | 10.81.16.11 | 10.82.16.11 |
| s16-pc03 | 1 | 2 | 10.70.16.12 | 10.70.80.12 | 10.81.16.12 | 10.82.16.12 |
| s16-pc04 | 2 | 2 | 10.70.16.13 | 10.70.80.13 | 10.81.16.13 | 10.82.16.13 |
| s16-pc05 | 1 | 3 | 10.70.16.14 | 10.70.80.14 | 10.81.16.14 | 10.82.16.14 |
| s16-pc06 | 2 | 3 | 10.70.16.15 | 10.70.80.15 | 10.81.16.15 | 10.82.16.15 |
| s16-pc07 | 1 | 4 | 10.70.16.16 | 10.70.80.16 | 10.81.16.16 | 10.82.16.16 |
| s16-pc08 | 2 | 4 | 10.70.16.17 | 10.70.80.17 | 10.81.16.17 | 10.82.16.17 |
| s16-pc09 | 1 | 5 | 10.70.16.18 | 10.70.80.18 | 10.81.16.18 | 10.82.16.18 |
| s16-pc10 | 2 | 5 | 10.70.16.19 | 10.70.80.19 | 10.81.16.19 | 10.82.16.19 |
| s16-pc11 | 1 | 6 | 10.70.16.20 | 10.70.80.20 | 10.81.16.20 | 10.82.16.20 |
| s16-pc12 | 2 | 6 | 10.70.16.21 | 10.70.80.21 | 10.81.16.21 | 10.82.16.21 |
| s16-pc13 | 1 | 7 | 10.70.16.22 | 10.70.80.22 | 10.81.16.22 | 10.82.16.22 |
| s16-pc14 | 2 | 7 | 10.70.16.23 | 10.70.80.23 | 10.81.16.23 | 10.82.16.23 |
| s16-pc15 | 1 | 8 | 10.70.16.24 | 10.70.80.24 | 10.81.16.24 | 10.82.16.24 |
| s16-pc16 | 2 | 8 | 10.70.16.25 | 10.70.80.25 | 10.81.16.25 | 10.82.16.25 |
| s16-pc17 | 1 | 9 | 10.70.16.26 | 10.70.80.26 | 10.81.16.26 | 10.82.16.26 |
| s16-pc18 | 2 | 9 | 10.70.16.27 | 10.70.80.27 | 10.81.16.27 | 10.82.16.27 |
| s16-pc19 | 1 | 10 | 10.70.16.28 | 10.70.80.28 | 10.81.16.28 | 10.82.16.28 |
| s16-pc20 | 2 | 10 | 10.70.16.29 | 10.70.80.29 | 10.81.16.29 | 10.82.16.29 |
| s16-pc21 | 1 | 11 | 10.70.16.30 | 10.70.80.30 | 10.81.16.30 | 10.82.16.30 |
| s16-pc22 | 2 | 11 | 10.70.16.31 | 10.70.80.31 | 10.81.16.31 | 10.82.16.31 |
| s16-pc23 | 1 | 12 | 10.70.16.32 | 10.70.80.32 | 10.81.16.32 | 10.82.16.32 |
| s16-pc24 | 2 | 12 | 10.70.16.33 | 10.70.80.33 | 10.81.16.33 | 10.82.16.33 |
| s16-pc25 | 1 | 13 | 10.70.16.34 | 10.70.80.34 | 10.81.16.34 | 10.82.16.34 |
| s16-pc26 | 2 | 13 | 10.70.16.35 | 10.70.80.35 | 10.81.16.35 | 10.82.16.35 |
| s16-pc27 | 1 | 14 | 10.70.16.36 | 10.70.80.36 | 10.81.16.36 | 10.82.16.36 |
| s16-pc28 | 2 | 14 | 10.70.16.37 | 10.70.80.37 | 10.81.16.37 | 10.82.16.37 |


**Transporte starlink — VLAN 201 — wanA.**

| Rol de entrega | Dirección |
| --- | --- |
| network | 10.252.16.0/29 |
| cpe | 10.252.16.1 |
| r1 | 10.252.16.2 |
| r2 | 10.252.16.3 |


**Transporte leo — VLAN 202 — wanB.**

| Rol de entrega | Dirección |
| --- | --- |
| network | 10.252.16.8/29 |
| cpe | 10.252.16.9 |
| r1 | 10.252.16.10 |
| r2 | 10.252.16.11 |


**Transporte entel5g — VLAN 203 — wanA.**

| Rol de entrega | Dirección |
| --- | --- |
| network | 10.252.16.16/29 |
| cpe | 10.252.16.17 |
| r1 | 10.252.16.18 |
| r2 | 10.252.16.19 |


**Transporte wom4g — VLAN 204 — wanB.**

| Rol de entrega | Dirección |
| --- | --- |
| network | 10.252.16.24/29 |
| cpe | 10.252.16.25 |
| r1 | 10.252.16.26 |
| r2 | 10.252.16.27 |


**Reservas de túneles (numeración según lista de la ficha).**

| Rol / candidato | Dirección |
| --- | --- |
| .1.hub_public_ip | 198.51.100.4 |
| .1.network | 10.253.16.0/30 |
| .1.branch_ip | 10.253.16.1 |
| .1.hub_ip | 10.253.16.2 |
| .2.hub_public_ip | 203.0.113.4 |
| .2.network | 10.253.16.4/30 |
| .2.branch_ip | 10.253.16.5 |
| .2.hub_ip | 10.253.16.6 |
| .3.hub_public_ip | 198.51.100.4 |
| .3.network | 10.253.16.8/30 |
| .3.branch_ip | 10.253.16.9 |
| .3.hub_ip | 10.253.16.10 |
| .4.hub_public_ip | 203.0.113.4 |
| .4.network | 10.253.16.12/30 |
| .4.branch_ip | 10.253.16.13 |
| .4.hub_ip | 10.253.16.14 |
| .5.hub_public_ip | 198.51.100.4 |
| .5.network | 10.253.16.16/30 |
| .5.branch_ip | 10.253.16.17 |
| .5.hub_ip | 10.253.16.18 |
| .6.hub_public_ip | 203.0.113.4 |
| .6.network | 10.253.16.20/30 |
| .6.branch_ip | 10.253.16.21 |
| .6.hub_ip | 10.253.16.22 |
| .7.hub_public_ip | 198.51.100.4 |
| .7.network | 10.253.16.24/30 |
| .7.branch_ip | 10.253.16.25 |
| .7.hub_ip | 10.253.16.26 |
| .8.hub_public_ip | 203.0.113.4 |
| .8.network | 10.253.16.28/30 |
| .8.branch_ip | 10.253.16.29 |
| .8.hub_ip | 10.253.16.30 |
| .9.hub_public_ip | 198.51.100.4 |
| .9.network | 10.253.16.32/30 |
| .9.branch_ip | 10.253.16.33 |
| .9.hub_ip | 10.253.16.34 |
| .10.hub_public_ip | 203.0.113.4 |
| .10.network | 10.253.16.36/30 |
| .10.branch_ip | 10.253.16.37 |
| .10.hub_ip | 10.253.16.38 |
| .11.hub_public_ip | 198.51.100.4 |
| .11.network | 10.253.16.40/30 |
| .11.branch_ip | 10.253.16.41 |
| .11.hub_ip | 10.253.16.42 |
| .12.hub_public_ip | 203.0.113.4 |
| .12.network | 10.253.16.44/30 |
| .12.branch_ip | 10.253.16.45 |
| .12.hub_ip | 10.253.16.46 |
| .13.hub_public_ip | 198.51.100.4 |
| .13.network | 10.253.16.48/30 |
| .13.branch_ip | 10.253.16.49 |
| .13.hub_ip | 10.253.16.50 |
| .14.hub_public_ip | 203.0.113.4 |
| .14.network | 10.253.16.52/30 |
| .14.branch_ip | 10.253.16.53 |
| .14.hub_ip | 10.253.16.54 |
| .15.hub_public_ip | 198.51.100.4 |
| .15.network | 10.253.16.56/30 |
| .15.branch_ip | 10.253.16.57 |
| .15.hub_ip | 10.253.16.58 |
| .16.hub_public_ip | 203.0.113.4 |
| .16.network | 10.253.16.60/30 |
| .16.branch_ip | 10.253.16.61 |
| .16.hub_ip | 10.253.16.62 |

### S17 — Valdivia

28 PCs y 28 teléfonos existentes.

| Función | ANTES | DESPUÉS |
| --- | --- | --- |
| Routers | 1 × C1121X-8P | 2 × C1121X-8P |
| Switches | 1 × C9200L-48P-4G-E | C9200L-48P-4G-E + C9200L-24P-4G-E |
| Firewall | Sin equipo dedicado | Sin appliance remoto; seguridad central |
| Distribución WAN | MPLS y accesos ISP del escenario base | wanA: E50UG; wanB: E50UG |


| Red | VLAN | Subred | Gateway / roles |
| --- | --- | --- | --- |
| users | 10 | 10.70.17.0/25 | 10.70.17.1 |
| voice | 20 | 10.70.81.0/25 | 10.70.81.1 |
| guests | 40 | 10.70.113.0/26 | 10.70.113.1 |
| wifi_users | 110 | 10.81.17.0/25 | 10.81.17.1 |
| wifi_voice | 120 | 10.82.17.0/25 | 10.82.17.1 |
| management | 130 | 10.80.17.0/27 | 10.80.17.1 |


| Gestión | Dirección |
| --- | --- |
| sw1 | 10.80.17.1 |
| sw2 | 10.80.17.1 |
| r1 | 10.80.17.2 |
| r2 | 10.80.17.3 |
| wanA | 10.80.17.6 |
| wanB | 10.80.17.7 |
| ap1 | 10.80.17.24 |
| ap2 | 10.80.17.25 |


| Origen | Puerto | Destino | Puerto | Función | VLAN/red | Mbps | IP / agregado lógico |
| --- | --- | --- | --- | --- | --- | --- | --- |
| cpe:starlink | LAN | wanA | ether1 | WAN_ACCESS | 201 | 1000 | — |
| cpe:entel5g | LAN | wanA | ether2 | WAN_ACCESS | 203 | 1000 | — |
| r1 | GigabitEthernet0/0/0 | wanA | ether3 | WAN_TRUNK | 201, 203 | 1000 | — |
| r2 | GigabitEthernet0/0/0 | wanA | ether4 | WAN_TRUNK | 201, 203 | 1000 | — |
| wanA | ether5 | sw1 | Gi1/0/22 | MANAGEMENT_ACCESS | 130 | 1000 | — |
| cpe:leo | LAN | wanB | ether1 | WAN_ACCESS | 202 | 1000 | — |
| cpe:wom4g | LAN | wanB | ether2 | WAN_ACCESS | 204 | 1000 | — |
| r1 | GigabitEthernet0/0/1 | wanB | ether3 | WAN_TRUNK | 202, 204 | 1000 | — |
| r2 | GigabitEthernet0/0/1 | wanB | ether4 | WAN_TRUNK | 202, 204 | 1000 | — |
| wanB | ether5 | sw2 | Gi2/0/22 | MANAGEMENT_ACCESS | 130 | 1000 | — |
| r1 | GigabitEthernet0/1/0 | sw1 | Gi1/0/19 | LAN_ROUTED | 172.31.17.0/30 | 1000 | router_ip: 172.31.17.1; stack_ip: 172.31.17.2 |
| r1 | GigabitEthernet0/1/1 | sw2 | Gi2/0/19 | LAN_ROUTED | 172.31.17.4/30 | 1000 | router_ip: 172.31.17.5; stack_ip: 172.31.17.6 |
| r1 | GigabitEthernet0/1/2 | sw1 | Gi1/0/21 | MANAGEMENT_ACCESS | 130 | 1000 | — |
| r2 | GigabitEthernet0/1/0 | sw1 | Gi1/0/20 | LAN_ROUTED | 172.31.17.8/30 | 1000 | router_ip: 172.31.17.9; stack_ip: 172.31.17.10 |
| r2 | GigabitEthernet0/1/1 | sw2 | Gi2/0/20 | LAN_ROUTED | 172.31.17.12/30 | 1000 | router_ip: 172.31.17.13; stack_ip: 172.31.17.14 |
| r2 | GigabitEthernet0/1/2 | sw2 | Gi2/0/21 | MANAGEMENT_ACCESS | 130 | 1000 | — |
| ap1 | LAN | sw1 | Gi1/0/24 | AP_TRUNK | 40, 110, 120, 130 | 1000 | — |
| ap2 | LAN | sw2 | Gi2/0/24 | AP_TRUNK | 40, 110, 120, 130 | 1000 | — |
| sw1 | Stack1 | sw2 | Stack2 | STACK | — | 80000 | — |
| sw1 | Stack2 | sw2 | Stack1 | STACK | — | 80000 | — |


| Puesto | Switch | Puerto | IP PC | IP teléfono | Reserva Wi-Fi PC | Reserva Wi-Fi voz |
| --- | --- | --- | --- | --- | --- | --- |
| s17-pc01 | 1 | 1 | 10.70.17.10 | 10.70.81.10 | 10.81.17.10 | 10.82.17.10 |
| s17-pc02 | 2 | 1 | 10.70.17.11 | 10.70.81.11 | 10.81.17.11 | 10.82.17.11 |
| s17-pc03 | 1 | 2 | 10.70.17.12 | 10.70.81.12 | 10.81.17.12 | 10.82.17.12 |
| s17-pc04 | 2 | 2 | 10.70.17.13 | 10.70.81.13 | 10.81.17.13 | 10.82.17.13 |
| s17-pc05 | 1 | 3 | 10.70.17.14 | 10.70.81.14 | 10.81.17.14 | 10.82.17.14 |
| s17-pc06 | 2 | 3 | 10.70.17.15 | 10.70.81.15 | 10.81.17.15 | 10.82.17.15 |
| s17-pc07 | 1 | 4 | 10.70.17.16 | 10.70.81.16 | 10.81.17.16 | 10.82.17.16 |
| s17-pc08 | 2 | 4 | 10.70.17.17 | 10.70.81.17 | 10.81.17.17 | 10.82.17.17 |
| s17-pc09 | 1 | 5 | 10.70.17.18 | 10.70.81.18 | 10.81.17.18 | 10.82.17.18 |
| s17-pc10 | 2 | 5 | 10.70.17.19 | 10.70.81.19 | 10.81.17.19 | 10.82.17.19 |
| s17-pc11 | 1 | 6 | 10.70.17.20 | 10.70.81.20 | 10.81.17.20 | 10.82.17.20 |
| s17-pc12 | 2 | 6 | 10.70.17.21 | 10.70.81.21 | 10.81.17.21 | 10.82.17.21 |
| s17-pc13 | 1 | 7 | 10.70.17.22 | 10.70.81.22 | 10.81.17.22 | 10.82.17.22 |
| s17-pc14 | 2 | 7 | 10.70.17.23 | 10.70.81.23 | 10.81.17.23 | 10.82.17.23 |
| s17-pc15 | 1 | 8 | 10.70.17.24 | 10.70.81.24 | 10.81.17.24 | 10.82.17.24 |
| s17-pc16 | 2 | 8 | 10.70.17.25 | 10.70.81.25 | 10.81.17.25 | 10.82.17.25 |
| s17-pc17 | 1 | 9 | 10.70.17.26 | 10.70.81.26 | 10.81.17.26 | 10.82.17.26 |
| s17-pc18 | 2 | 9 | 10.70.17.27 | 10.70.81.27 | 10.81.17.27 | 10.82.17.27 |
| s17-pc19 | 1 | 10 | 10.70.17.28 | 10.70.81.28 | 10.81.17.28 | 10.82.17.28 |
| s17-pc20 | 2 | 10 | 10.70.17.29 | 10.70.81.29 | 10.81.17.29 | 10.82.17.29 |
| s17-pc21 | 1 | 11 | 10.70.17.30 | 10.70.81.30 | 10.81.17.30 | 10.82.17.30 |
| s17-pc22 | 2 | 11 | 10.70.17.31 | 10.70.81.31 | 10.81.17.31 | 10.82.17.31 |
| s17-pc23 | 1 | 12 | 10.70.17.32 | 10.70.81.32 | 10.81.17.32 | 10.82.17.32 |
| s17-pc24 | 2 | 12 | 10.70.17.33 | 10.70.81.33 | 10.81.17.33 | 10.82.17.33 |
| s17-pc25 | 1 | 13 | 10.70.17.34 | 10.70.81.34 | 10.81.17.34 | 10.82.17.34 |
| s17-pc26 | 2 | 13 | 10.70.17.35 | 10.70.81.35 | 10.81.17.35 | 10.82.17.35 |
| s17-pc27 | 1 | 14 | 10.70.17.36 | 10.70.81.36 | 10.81.17.36 | 10.82.17.36 |
| s17-pc28 | 2 | 14 | 10.70.17.37 | 10.70.81.37 | 10.81.17.37 | 10.82.17.37 |


**Transporte starlink — VLAN 201 — wanA.**

| Rol de entrega | Dirección |
| --- | --- |
| network | 10.252.17.0/29 |
| cpe | 10.252.17.1 |
| r1 | 10.252.17.2 |
| r2 | 10.252.17.3 |


**Transporte leo — VLAN 202 — wanB.**

| Rol de entrega | Dirección |
| --- | --- |
| network | 10.252.17.8/29 |
| cpe | 10.252.17.9 |
| r1 | 10.252.17.10 |
| r2 | 10.252.17.11 |


**Transporte entel5g — VLAN 203 — wanA.**

| Rol de entrega | Dirección |
| --- | --- |
| network | 10.252.17.16/29 |
| cpe | 10.252.17.17 |
| r1 | 10.252.17.18 |
| r2 | 10.252.17.19 |


**Transporte wom4g — VLAN 204 — wanB.**

| Rol de entrega | Dirección |
| --- | --- |
| network | 10.252.17.24/29 |
| cpe | 10.252.17.25 |
| r1 | 10.252.17.26 |
| r2 | 10.252.17.27 |


**Reservas de túneles (numeración según lista de la ficha).**

| Rol / candidato | Dirección |
| --- | --- |
| .1.hub_public_ip | 198.51.100.4 |
| .1.network | 10.253.17.0/30 |
| .1.branch_ip | 10.253.17.1 |
| .1.hub_ip | 10.253.17.2 |
| .2.hub_public_ip | 203.0.113.4 |
| .2.network | 10.253.17.4/30 |
| .2.branch_ip | 10.253.17.5 |
| .2.hub_ip | 10.253.17.6 |
| .3.hub_public_ip | 198.51.100.4 |
| .3.network | 10.253.17.8/30 |
| .3.branch_ip | 10.253.17.9 |
| .3.hub_ip | 10.253.17.10 |
| .4.hub_public_ip | 203.0.113.4 |
| .4.network | 10.253.17.12/30 |
| .4.branch_ip | 10.253.17.13 |
| .4.hub_ip | 10.253.17.14 |
| .5.hub_public_ip | 198.51.100.4 |
| .5.network | 10.253.17.16/30 |
| .5.branch_ip | 10.253.17.17 |
| .5.hub_ip | 10.253.17.18 |
| .6.hub_public_ip | 203.0.113.4 |
| .6.network | 10.253.17.20/30 |
| .6.branch_ip | 10.253.17.21 |
| .6.hub_ip | 10.253.17.22 |
| .7.hub_public_ip | 198.51.100.4 |
| .7.network | 10.253.17.24/30 |
| .7.branch_ip | 10.253.17.25 |
| .7.hub_ip | 10.253.17.26 |
| .8.hub_public_ip | 203.0.113.4 |
| .8.network | 10.253.17.28/30 |
| .8.branch_ip | 10.253.17.29 |
| .8.hub_ip | 10.253.17.30 |
| .9.hub_public_ip | 198.51.100.4 |
| .9.network | 10.253.17.32/30 |
| .9.branch_ip | 10.253.17.33 |
| .9.hub_ip | 10.253.17.34 |
| .10.hub_public_ip | 203.0.113.4 |
| .10.network | 10.253.17.36/30 |
| .10.branch_ip | 10.253.17.37 |
| .10.hub_ip | 10.253.17.38 |
| .11.hub_public_ip | 198.51.100.4 |
| .11.network | 10.253.17.40/30 |
| .11.branch_ip | 10.253.17.41 |
| .11.hub_ip | 10.253.17.42 |
| .12.hub_public_ip | 203.0.113.4 |
| .12.network | 10.253.17.44/30 |
| .12.branch_ip | 10.253.17.45 |
| .12.hub_ip | 10.253.17.46 |
| .13.hub_public_ip | 198.51.100.4 |
| .13.network | 10.253.17.48/30 |
| .13.branch_ip | 10.253.17.49 |
| .13.hub_ip | 10.253.17.50 |
| .14.hub_public_ip | 203.0.113.4 |
| .14.network | 10.253.17.52/30 |
| .14.branch_ip | 10.253.17.53 |
| .14.hub_ip | 10.253.17.54 |
| .15.hub_public_ip | 198.51.100.4 |
| .15.network | 10.253.17.56/30 |
| .15.branch_ip | 10.253.17.57 |
| .15.hub_ip | 10.253.17.58 |
| .16.hub_public_ip | 203.0.113.4 |
| .16.network | 10.253.17.60/30 |
| .16.branch_ip | 10.253.17.61 |
| .16.hub_ip | 10.253.17.62 |

### S18 — Puerto Montt

28 PCs y 28 teléfonos existentes.

| Función | ANTES | DESPUÉS |
| --- | --- | --- |
| Routers | 1 × ISR4321/K9 | 2 × C1121X-8P |
| Switches | 1 × C9200L-48P-4G-E | C9200L-48P-4G-E + C9200L-24P-4G-E |
| Firewall | Sin equipo dedicado | Sin appliance remoto; seguridad central |
| Distribución WAN | MPLS y accesos ISP del escenario base | wanA: E50UG; wanB: E50UG |


| Red | VLAN | Subred | Gateway / roles |
| --- | --- | --- | --- |
| users | 10 | 10.70.18.0/25 | 10.70.18.1 |
| voice | 20 | 10.70.82.0/25 | 10.70.82.1 |
| guests | 40 | 10.70.114.0/26 | 10.70.114.1 |
| wifi_users | 110 | 10.81.18.0/25 | 10.81.18.1 |
| wifi_voice | 120 | 10.82.18.0/25 | 10.82.18.1 |
| management | 130 | 10.80.18.0/27 | 10.80.18.1 |


| Gestión | Dirección |
| --- | --- |
| sw1 | 10.80.18.1 |
| sw2 | 10.80.18.1 |
| r1 | 10.80.18.2 |
| r2 | 10.80.18.3 |
| wanA | 10.80.18.6 |
| wanB | 10.80.18.7 |
| ap1 | 10.80.18.24 |
| ap2 | 10.80.18.25 |


| Origen | Puerto | Destino | Puerto | Función | VLAN/red | Mbps | IP / agregado lógico |
| --- | --- | --- | --- | --- | --- | --- | --- |
| cpe:starlink | LAN | wanA | ether1 | WAN_ACCESS | 201 | 1000 | — |
| cpe:entel5g | LAN | wanA | ether2 | WAN_ACCESS | 203 | 1000 | — |
| r1 | GigabitEthernet0/0/0 | wanA | ether3 | WAN_TRUNK | 201, 203 | 1000 | — |
| r2 | GigabitEthernet0/0/0 | wanA | ether4 | WAN_TRUNK | 201, 203 | 1000 | — |
| wanA | ether5 | sw1 | Gi1/0/22 | MANAGEMENT_ACCESS | 130 | 1000 | — |
| cpe:leo | LAN | wanB | ether1 | WAN_ACCESS | 202 | 1000 | — |
| cpe:wom4g | LAN | wanB | ether2 | WAN_ACCESS | 204 | 1000 | — |
| r1 | GigabitEthernet0/0/1 | wanB | ether3 | WAN_TRUNK | 202, 204 | 1000 | — |
| r2 | GigabitEthernet0/0/1 | wanB | ether4 | WAN_TRUNK | 202, 204 | 1000 | — |
| wanB | ether5 | sw2 | Gi2/0/22 | MANAGEMENT_ACCESS | 130 | 1000 | — |
| r1 | GigabitEthernet0/1/0 | sw1 | Gi1/0/19 | LAN_ROUTED | 172.31.18.0/30 | 1000 | router_ip: 172.31.18.1; stack_ip: 172.31.18.2 |
| r1 | GigabitEthernet0/1/1 | sw2 | Gi2/0/19 | LAN_ROUTED | 172.31.18.4/30 | 1000 | router_ip: 172.31.18.5; stack_ip: 172.31.18.6 |
| r1 | GigabitEthernet0/1/2 | sw1 | Gi1/0/21 | MANAGEMENT_ACCESS | 130 | 1000 | — |
| r2 | GigabitEthernet0/1/0 | sw1 | Gi1/0/20 | LAN_ROUTED | 172.31.18.8/30 | 1000 | router_ip: 172.31.18.9; stack_ip: 172.31.18.10 |
| r2 | GigabitEthernet0/1/1 | sw2 | Gi2/0/20 | LAN_ROUTED | 172.31.18.12/30 | 1000 | router_ip: 172.31.18.13; stack_ip: 172.31.18.14 |
| r2 | GigabitEthernet0/1/2 | sw2 | Gi2/0/21 | MANAGEMENT_ACCESS | 130 | 1000 | — |
| ap1 | LAN | sw1 | Gi1/0/24 | AP_TRUNK | 40, 110, 120, 130 | 1000 | — |
| ap2 | LAN | sw2 | Gi2/0/24 | AP_TRUNK | 40, 110, 120, 130 | 1000 | — |
| sw1 | Stack1 | sw2 | Stack2 | STACK | — | 80000 | — |
| sw1 | Stack2 | sw2 | Stack1 | STACK | — | 80000 | — |


| Puesto | Switch | Puerto | IP PC | IP teléfono | Reserva Wi-Fi PC | Reserva Wi-Fi voz |
| --- | --- | --- | --- | --- | --- | --- |
| s18-pc01 | 1 | 1 | 10.70.18.10 | 10.70.82.10 | 10.81.18.10 | 10.82.18.10 |
| s18-pc02 | 2 | 1 | 10.70.18.11 | 10.70.82.11 | 10.81.18.11 | 10.82.18.11 |
| s18-pc03 | 1 | 2 | 10.70.18.12 | 10.70.82.12 | 10.81.18.12 | 10.82.18.12 |
| s18-pc04 | 2 | 2 | 10.70.18.13 | 10.70.82.13 | 10.81.18.13 | 10.82.18.13 |
| s18-pc05 | 1 | 3 | 10.70.18.14 | 10.70.82.14 | 10.81.18.14 | 10.82.18.14 |
| s18-pc06 | 2 | 3 | 10.70.18.15 | 10.70.82.15 | 10.81.18.15 | 10.82.18.15 |
| s18-pc07 | 1 | 4 | 10.70.18.16 | 10.70.82.16 | 10.81.18.16 | 10.82.18.16 |
| s18-pc08 | 2 | 4 | 10.70.18.17 | 10.70.82.17 | 10.81.18.17 | 10.82.18.17 |
| s18-pc09 | 1 | 5 | 10.70.18.18 | 10.70.82.18 | 10.81.18.18 | 10.82.18.18 |
| s18-pc10 | 2 | 5 | 10.70.18.19 | 10.70.82.19 | 10.81.18.19 | 10.82.18.19 |
| s18-pc11 | 1 | 6 | 10.70.18.20 | 10.70.82.20 | 10.81.18.20 | 10.82.18.20 |
| s18-pc12 | 2 | 6 | 10.70.18.21 | 10.70.82.21 | 10.81.18.21 | 10.82.18.21 |
| s18-pc13 | 1 | 7 | 10.70.18.22 | 10.70.82.22 | 10.81.18.22 | 10.82.18.22 |
| s18-pc14 | 2 | 7 | 10.70.18.23 | 10.70.82.23 | 10.81.18.23 | 10.82.18.23 |
| s18-pc15 | 1 | 8 | 10.70.18.24 | 10.70.82.24 | 10.81.18.24 | 10.82.18.24 |
| s18-pc16 | 2 | 8 | 10.70.18.25 | 10.70.82.25 | 10.81.18.25 | 10.82.18.25 |
| s18-pc17 | 1 | 9 | 10.70.18.26 | 10.70.82.26 | 10.81.18.26 | 10.82.18.26 |
| s18-pc18 | 2 | 9 | 10.70.18.27 | 10.70.82.27 | 10.81.18.27 | 10.82.18.27 |
| s18-pc19 | 1 | 10 | 10.70.18.28 | 10.70.82.28 | 10.81.18.28 | 10.82.18.28 |
| s18-pc20 | 2 | 10 | 10.70.18.29 | 10.70.82.29 | 10.81.18.29 | 10.82.18.29 |
| s18-pc21 | 1 | 11 | 10.70.18.30 | 10.70.82.30 | 10.81.18.30 | 10.82.18.30 |
| s18-pc22 | 2 | 11 | 10.70.18.31 | 10.70.82.31 | 10.81.18.31 | 10.82.18.31 |
| s18-pc23 | 1 | 12 | 10.70.18.32 | 10.70.82.32 | 10.81.18.32 | 10.82.18.32 |
| s18-pc24 | 2 | 12 | 10.70.18.33 | 10.70.82.33 | 10.81.18.33 | 10.82.18.33 |
| s18-pc25 | 1 | 13 | 10.70.18.34 | 10.70.82.34 | 10.81.18.34 | 10.82.18.34 |
| s18-pc26 | 2 | 13 | 10.70.18.35 | 10.70.82.35 | 10.81.18.35 | 10.82.18.35 |
| s18-pc27 | 1 | 14 | 10.70.18.36 | 10.70.82.36 | 10.81.18.36 | 10.82.18.36 |
| s18-pc28 | 2 | 14 | 10.70.18.37 | 10.70.82.37 | 10.81.18.37 | 10.82.18.37 |


**Transporte starlink — VLAN 201 — wanA.**

| Rol de entrega | Dirección |
| --- | --- |
| network | 10.252.18.0/29 |
| cpe | 10.252.18.1 |
| r1 | 10.252.18.2 |
| r2 | 10.252.18.3 |


**Transporte leo — VLAN 202 — wanB.**

| Rol de entrega | Dirección |
| --- | --- |
| network | 10.252.18.8/29 |
| cpe | 10.252.18.9 |
| r1 | 10.252.18.10 |
| r2 | 10.252.18.11 |


**Transporte entel5g — VLAN 203 — wanA.**

| Rol de entrega | Dirección |
| --- | --- |
| network | 10.252.18.16/29 |
| cpe | 10.252.18.17 |
| r1 | 10.252.18.18 |
| r2 | 10.252.18.19 |


**Transporte wom4g — VLAN 204 — wanB.**

| Rol de entrega | Dirección |
| --- | --- |
| network | 10.252.18.24/29 |
| cpe | 10.252.18.25 |
| r1 | 10.252.18.26 |
| r2 | 10.252.18.27 |


**Reservas de túneles (numeración según lista de la ficha).**

| Rol / candidato | Dirección |
| --- | --- |
| .1.hub_public_ip | 198.51.100.4 |
| .1.network | 10.253.18.0/30 |
| .1.branch_ip | 10.253.18.1 |
| .1.hub_ip | 10.253.18.2 |
| .2.hub_public_ip | 203.0.113.4 |
| .2.network | 10.253.18.4/30 |
| .2.branch_ip | 10.253.18.5 |
| .2.hub_ip | 10.253.18.6 |
| .3.hub_public_ip | 198.51.100.4 |
| .3.network | 10.253.18.8/30 |
| .3.branch_ip | 10.253.18.9 |
| .3.hub_ip | 10.253.18.10 |
| .4.hub_public_ip | 203.0.113.4 |
| .4.network | 10.253.18.12/30 |
| .4.branch_ip | 10.253.18.13 |
| .4.hub_ip | 10.253.18.14 |
| .5.hub_public_ip | 198.51.100.4 |
| .5.network | 10.253.18.16/30 |
| .5.branch_ip | 10.253.18.17 |
| .5.hub_ip | 10.253.18.18 |
| .6.hub_public_ip | 203.0.113.4 |
| .6.network | 10.253.18.20/30 |
| .6.branch_ip | 10.253.18.21 |
| .6.hub_ip | 10.253.18.22 |
| .7.hub_public_ip | 198.51.100.4 |
| .7.network | 10.253.18.24/30 |
| .7.branch_ip | 10.253.18.25 |
| .7.hub_ip | 10.253.18.26 |
| .8.hub_public_ip | 203.0.113.4 |
| .8.network | 10.253.18.28/30 |
| .8.branch_ip | 10.253.18.29 |
| .8.hub_ip | 10.253.18.30 |
| .9.hub_public_ip | 198.51.100.4 |
| .9.network | 10.253.18.32/30 |
| .9.branch_ip | 10.253.18.33 |
| .9.hub_ip | 10.253.18.34 |
| .10.hub_public_ip | 203.0.113.4 |
| .10.network | 10.253.18.36/30 |
| .10.branch_ip | 10.253.18.37 |
| .10.hub_ip | 10.253.18.38 |
| .11.hub_public_ip | 198.51.100.4 |
| .11.network | 10.253.18.40/30 |
| .11.branch_ip | 10.253.18.41 |
| .11.hub_ip | 10.253.18.42 |
| .12.hub_public_ip | 203.0.113.4 |
| .12.network | 10.253.18.44/30 |
| .12.branch_ip | 10.253.18.45 |
| .12.hub_ip | 10.253.18.46 |
| .13.hub_public_ip | 198.51.100.4 |
| .13.network | 10.253.18.48/30 |
| .13.branch_ip | 10.253.18.49 |
| .13.hub_ip | 10.253.18.50 |
| .14.hub_public_ip | 203.0.113.4 |
| .14.network | 10.253.18.52/30 |
| .14.branch_ip | 10.253.18.53 |
| .14.hub_ip | 10.253.18.54 |
| .15.hub_public_ip | 198.51.100.4 |
| .15.network | 10.253.18.56/30 |
| .15.branch_ip | 10.253.18.57 |
| .15.hub_ip | 10.253.18.58 |
| .16.hub_public_ip | 203.0.113.4 |
| .16.network | 10.253.18.60/30 |
| .16.branch_ip | 10.253.18.61 |
| .16.hub_ip | 10.253.18.62 |

### S19 — Coyhaique

28 PCs y 28 teléfonos existentes.

| Función | ANTES | DESPUÉS |
| --- | --- | --- |
| Routers | 1 × C1121X-8P | 2 × C1121X-8P |
| Switches | 1 × C9200L-48P-4G-E | C9200L-48P-4G-E + C9200L-24P-4G-E |
| Firewall | Sin equipo dedicado | Sin appliance remoto; seguridad central |
| Distribución WAN | MPLS y accesos ISP del escenario base | wanA: E50UG; wanB: E50UG |


| Red | VLAN | Subred | Gateway / roles |
| --- | --- | --- | --- |
| users | 10 | 10.70.19.0/25 | 10.70.19.1 |
| voice | 20 | 10.70.83.0/25 | 10.70.83.1 |
| guests | 40 | 10.70.115.0/26 | 10.70.115.1 |
| wifi_users | 110 | 10.81.19.0/25 | 10.81.19.1 |
| wifi_voice | 120 | 10.82.19.0/25 | 10.82.19.1 |
| management | 130 | 10.80.19.0/27 | 10.80.19.1 |


| Gestión | Dirección |
| --- | --- |
| sw1 | 10.80.19.1 |
| sw2 | 10.80.19.1 |
| r1 | 10.80.19.2 |
| r2 | 10.80.19.3 |
| wanA | 10.80.19.6 |
| wanB | 10.80.19.7 |
| ap1 | 10.80.19.24 |
| ap2 | 10.80.19.25 |


| Origen | Puerto | Destino | Puerto | Función | VLAN/red | Mbps | IP / agregado lógico |
| --- | --- | --- | --- | --- | --- | --- | --- |
| cpe:starlink | LAN | wanA | ether1 | WAN_ACCESS | 201 | 1000 | — |
| cpe:entel5g | LAN | wanA | ether2 | WAN_ACCESS | 203 | 1000 | — |
| r1 | GigabitEthernet0/0/0 | wanA | ether3 | WAN_TRUNK | 201, 203 | 1000 | — |
| r2 | GigabitEthernet0/0/0 | wanA | ether4 | WAN_TRUNK | 201, 203 | 1000 | — |
| wanA | ether5 | sw1 | Gi1/0/22 | MANAGEMENT_ACCESS | 130 | 1000 | — |
| cpe:leo | LAN | wanB | ether1 | WAN_ACCESS | 202 | 1000 | — |
| cpe:wom4g | LAN | wanB | ether2 | WAN_ACCESS | 204 | 1000 | — |
| r1 | GigabitEthernet0/0/1 | wanB | ether3 | WAN_TRUNK | 202, 204 | 1000 | — |
| r2 | GigabitEthernet0/0/1 | wanB | ether4 | WAN_TRUNK | 202, 204 | 1000 | — |
| wanB | ether5 | sw2 | Gi2/0/22 | MANAGEMENT_ACCESS | 130 | 1000 | — |
| r1 | GigabitEthernet0/1/0 | sw1 | Gi1/0/19 | LAN_ROUTED | 172.31.19.0/30 | 1000 | router_ip: 172.31.19.1; stack_ip: 172.31.19.2 |
| r1 | GigabitEthernet0/1/1 | sw2 | Gi2/0/19 | LAN_ROUTED | 172.31.19.4/30 | 1000 | router_ip: 172.31.19.5; stack_ip: 172.31.19.6 |
| r1 | GigabitEthernet0/1/2 | sw1 | Gi1/0/21 | MANAGEMENT_ACCESS | 130 | 1000 | — |
| r2 | GigabitEthernet0/1/0 | sw1 | Gi1/0/20 | LAN_ROUTED | 172.31.19.8/30 | 1000 | router_ip: 172.31.19.9; stack_ip: 172.31.19.10 |
| r2 | GigabitEthernet0/1/1 | sw2 | Gi2/0/20 | LAN_ROUTED | 172.31.19.12/30 | 1000 | router_ip: 172.31.19.13; stack_ip: 172.31.19.14 |
| r2 | GigabitEthernet0/1/2 | sw2 | Gi2/0/21 | MANAGEMENT_ACCESS | 130 | 1000 | — |
| ap1 | LAN | sw1 | Gi1/0/24 | AP_TRUNK | 40, 110, 120, 130 | 1000 | — |
| ap2 | LAN | sw2 | Gi2/0/24 | AP_TRUNK | 40, 110, 120, 130 | 1000 | — |
| sw1 | Stack1 | sw2 | Stack2 | STACK | — | 80000 | — |
| sw1 | Stack2 | sw2 | Stack1 | STACK | — | 80000 | — |


| Puesto | Switch | Puerto | IP PC | IP teléfono | Reserva Wi-Fi PC | Reserva Wi-Fi voz |
| --- | --- | --- | --- | --- | --- | --- |
| s19-pc01 | 1 | 1 | 10.70.19.10 | 10.70.83.10 | 10.81.19.10 | 10.82.19.10 |
| s19-pc02 | 2 | 1 | 10.70.19.11 | 10.70.83.11 | 10.81.19.11 | 10.82.19.11 |
| s19-pc03 | 1 | 2 | 10.70.19.12 | 10.70.83.12 | 10.81.19.12 | 10.82.19.12 |
| s19-pc04 | 2 | 2 | 10.70.19.13 | 10.70.83.13 | 10.81.19.13 | 10.82.19.13 |
| s19-pc05 | 1 | 3 | 10.70.19.14 | 10.70.83.14 | 10.81.19.14 | 10.82.19.14 |
| s19-pc06 | 2 | 3 | 10.70.19.15 | 10.70.83.15 | 10.81.19.15 | 10.82.19.15 |
| s19-pc07 | 1 | 4 | 10.70.19.16 | 10.70.83.16 | 10.81.19.16 | 10.82.19.16 |
| s19-pc08 | 2 | 4 | 10.70.19.17 | 10.70.83.17 | 10.81.19.17 | 10.82.19.17 |
| s19-pc09 | 1 | 5 | 10.70.19.18 | 10.70.83.18 | 10.81.19.18 | 10.82.19.18 |
| s19-pc10 | 2 | 5 | 10.70.19.19 | 10.70.83.19 | 10.81.19.19 | 10.82.19.19 |
| s19-pc11 | 1 | 6 | 10.70.19.20 | 10.70.83.20 | 10.81.19.20 | 10.82.19.20 |
| s19-pc12 | 2 | 6 | 10.70.19.21 | 10.70.83.21 | 10.81.19.21 | 10.82.19.21 |
| s19-pc13 | 1 | 7 | 10.70.19.22 | 10.70.83.22 | 10.81.19.22 | 10.82.19.22 |
| s19-pc14 | 2 | 7 | 10.70.19.23 | 10.70.83.23 | 10.81.19.23 | 10.82.19.23 |
| s19-pc15 | 1 | 8 | 10.70.19.24 | 10.70.83.24 | 10.81.19.24 | 10.82.19.24 |
| s19-pc16 | 2 | 8 | 10.70.19.25 | 10.70.83.25 | 10.81.19.25 | 10.82.19.25 |
| s19-pc17 | 1 | 9 | 10.70.19.26 | 10.70.83.26 | 10.81.19.26 | 10.82.19.26 |
| s19-pc18 | 2 | 9 | 10.70.19.27 | 10.70.83.27 | 10.81.19.27 | 10.82.19.27 |
| s19-pc19 | 1 | 10 | 10.70.19.28 | 10.70.83.28 | 10.81.19.28 | 10.82.19.28 |
| s19-pc20 | 2 | 10 | 10.70.19.29 | 10.70.83.29 | 10.81.19.29 | 10.82.19.29 |
| s19-pc21 | 1 | 11 | 10.70.19.30 | 10.70.83.30 | 10.81.19.30 | 10.82.19.30 |
| s19-pc22 | 2 | 11 | 10.70.19.31 | 10.70.83.31 | 10.81.19.31 | 10.82.19.31 |
| s19-pc23 | 1 | 12 | 10.70.19.32 | 10.70.83.32 | 10.81.19.32 | 10.82.19.32 |
| s19-pc24 | 2 | 12 | 10.70.19.33 | 10.70.83.33 | 10.81.19.33 | 10.82.19.33 |
| s19-pc25 | 1 | 13 | 10.70.19.34 | 10.70.83.34 | 10.81.19.34 | 10.82.19.34 |
| s19-pc26 | 2 | 13 | 10.70.19.35 | 10.70.83.35 | 10.81.19.35 | 10.82.19.35 |
| s19-pc27 | 1 | 14 | 10.70.19.36 | 10.70.83.36 | 10.81.19.36 | 10.82.19.36 |
| s19-pc28 | 2 | 14 | 10.70.19.37 | 10.70.83.37 | 10.81.19.37 | 10.82.19.37 |


**Transporte starlink — VLAN 201 — wanA.**

| Rol de entrega | Dirección |
| --- | --- |
| network | 10.252.19.0/29 |
| cpe | 10.252.19.1 |
| r1 | 10.252.19.2 |
| r2 | 10.252.19.3 |


**Transporte leo — VLAN 202 — wanB.**

| Rol de entrega | Dirección |
| --- | --- |
| network | 10.252.19.8/29 |
| cpe | 10.252.19.9 |
| r1 | 10.252.19.10 |
| r2 | 10.252.19.11 |


**Transporte entel5g — VLAN 203 — wanA.**

| Rol de entrega | Dirección |
| --- | --- |
| network | 10.252.19.16/29 |
| cpe | 10.252.19.17 |
| r1 | 10.252.19.18 |
| r2 | 10.252.19.19 |


**Transporte wom4g — VLAN 204 — wanB.**

| Rol de entrega | Dirección |
| --- | --- |
| network | 10.252.19.24/29 |
| cpe | 10.252.19.25 |
| r1 | 10.252.19.26 |
| r2 | 10.252.19.27 |


**Reservas de túneles (numeración según lista de la ficha).**

| Rol / candidato | Dirección |
| --- | --- |
| .1.hub_public_ip | 198.51.100.4 |
| .1.network | 10.253.19.0/30 |
| .1.branch_ip | 10.253.19.1 |
| .1.hub_ip | 10.253.19.2 |
| .2.hub_public_ip | 203.0.113.4 |
| .2.network | 10.253.19.4/30 |
| .2.branch_ip | 10.253.19.5 |
| .2.hub_ip | 10.253.19.6 |
| .3.hub_public_ip | 198.51.100.4 |
| .3.network | 10.253.19.8/30 |
| .3.branch_ip | 10.253.19.9 |
| .3.hub_ip | 10.253.19.10 |
| .4.hub_public_ip | 203.0.113.4 |
| .4.network | 10.253.19.12/30 |
| .4.branch_ip | 10.253.19.13 |
| .4.hub_ip | 10.253.19.14 |
| .5.hub_public_ip | 198.51.100.4 |
| .5.network | 10.253.19.16/30 |
| .5.branch_ip | 10.253.19.17 |
| .5.hub_ip | 10.253.19.18 |
| .6.hub_public_ip | 203.0.113.4 |
| .6.network | 10.253.19.20/30 |
| .6.branch_ip | 10.253.19.21 |
| .6.hub_ip | 10.253.19.22 |
| .7.hub_public_ip | 198.51.100.4 |
| .7.network | 10.253.19.24/30 |
| .7.branch_ip | 10.253.19.25 |
| .7.hub_ip | 10.253.19.26 |
| .8.hub_public_ip | 203.0.113.4 |
| .8.network | 10.253.19.28/30 |
| .8.branch_ip | 10.253.19.29 |
| .8.hub_ip | 10.253.19.30 |
| .9.hub_public_ip | 198.51.100.4 |
| .9.network | 10.253.19.32/30 |
| .9.branch_ip | 10.253.19.33 |
| .9.hub_ip | 10.253.19.34 |
| .10.hub_public_ip | 203.0.113.4 |
| .10.network | 10.253.19.36/30 |
| .10.branch_ip | 10.253.19.37 |
| .10.hub_ip | 10.253.19.38 |
| .11.hub_public_ip | 198.51.100.4 |
| .11.network | 10.253.19.40/30 |
| .11.branch_ip | 10.253.19.41 |
| .11.hub_ip | 10.253.19.42 |
| .12.hub_public_ip | 203.0.113.4 |
| .12.network | 10.253.19.44/30 |
| .12.branch_ip | 10.253.19.45 |
| .12.hub_ip | 10.253.19.46 |
| .13.hub_public_ip | 198.51.100.4 |
| .13.network | 10.253.19.48/30 |
| .13.branch_ip | 10.253.19.49 |
| .13.hub_ip | 10.253.19.50 |
| .14.hub_public_ip | 203.0.113.4 |
| .14.network | 10.253.19.52/30 |
| .14.branch_ip | 10.253.19.53 |
| .14.hub_ip | 10.253.19.54 |
| .15.hub_public_ip | 198.51.100.4 |
| .15.network | 10.253.19.56/30 |
| .15.branch_ip | 10.253.19.57 |
| .15.hub_ip | 10.253.19.58 |
| .16.hub_public_ip | 203.0.113.4 |
| .16.network | 10.253.19.60/30 |
| .16.branch_ip | 10.253.19.61 |
| .16.hub_ip | 10.253.19.62 |

### S20 — Punta Arenas

28 PCs y 28 teléfonos existentes.

| Función | ANTES | DESPUÉS |
| --- | --- | --- |
| Routers | 1 × C1121X-8P | 2 × C1121X-8P |
| Switches | 1 × C9200L-48P-4G-E | C9200L-48P-4G-E + C9200L-24P-4G-E |
| Firewall | Sin equipo dedicado | Sin appliance remoto; seguridad central |
| Distribución WAN | MPLS y accesos ISP del escenario base | wanA: E50UG; wanB: E50UG |


| Red | VLAN | Subred | Gateway / roles |
| --- | --- | --- | --- |
| users | 10 | 10.70.20.0/25 | 10.70.20.1 |
| voice | 20 | 10.70.84.0/25 | 10.70.84.1 |
| guests | 40 | 10.70.116.0/26 | 10.70.116.1 |
| wifi_users | 110 | 10.81.20.0/25 | 10.81.20.1 |
| wifi_voice | 120 | 10.82.20.0/25 | 10.82.20.1 |
| management | 130 | 10.80.20.0/27 | 10.80.20.1 |


| Gestión | Dirección |
| --- | --- |
| sw1 | 10.80.20.1 |
| sw2 | 10.80.20.1 |
| r1 | 10.80.20.2 |
| r2 | 10.80.20.3 |
| wanA | 10.80.20.6 |
| wanB | 10.80.20.7 |
| ap1 | 10.80.20.24 |
| ap2 | 10.80.20.25 |


| Origen | Puerto | Destino | Puerto | Función | VLAN/red | Mbps | IP / agregado lógico |
| --- | --- | --- | --- | --- | --- | --- | --- |
| cpe:starlink | LAN | wanA | ether1 | WAN_ACCESS | 201 | 1000 | — |
| cpe:entel5g | LAN | wanA | ether2 | WAN_ACCESS | 203 | 1000 | — |
| r1 | GigabitEthernet0/0/0 | wanA | ether3 | WAN_TRUNK | 201, 203 | 1000 | — |
| r2 | GigabitEthernet0/0/0 | wanA | ether4 | WAN_TRUNK | 201, 203 | 1000 | — |
| wanA | ether5 | sw1 | Gi1/0/22 | MANAGEMENT_ACCESS | 130 | 1000 | — |
| cpe:leo | LAN | wanB | ether1 | WAN_ACCESS | 202 | 1000 | — |
| cpe:wom4g | LAN | wanB | ether2 | WAN_ACCESS | 204 | 1000 | — |
| r1 | GigabitEthernet0/0/1 | wanB | ether3 | WAN_TRUNK | 202, 204 | 1000 | — |
| r2 | GigabitEthernet0/0/1 | wanB | ether4 | WAN_TRUNK | 202, 204 | 1000 | — |
| wanB | ether5 | sw2 | Gi2/0/22 | MANAGEMENT_ACCESS | 130 | 1000 | — |
| r1 | GigabitEthernet0/1/0 | sw1 | Gi1/0/19 | LAN_ROUTED | 172.31.20.0/30 | 1000 | router_ip: 172.31.20.1; stack_ip: 172.31.20.2 |
| r1 | GigabitEthernet0/1/1 | sw2 | Gi2/0/19 | LAN_ROUTED | 172.31.20.4/30 | 1000 | router_ip: 172.31.20.5; stack_ip: 172.31.20.6 |
| r1 | GigabitEthernet0/1/2 | sw1 | Gi1/0/21 | MANAGEMENT_ACCESS | 130 | 1000 | — |
| r2 | GigabitEthernet0/1/0 | sw1 | Gi1/0/20 | LAN_ROUTED | 172.31.20.8/30 | 1000 | router_ip: 172.31.20.9; stack_ip: 172.31.20.10 |
| r2 | GigabitEthernet0/1/1 | sw2 | Gi2/0/20 | LAN_ROUTED | 172.31.20.12/30 | 1000 | router_ip: 172.31.20.13; stack_ip: 172.31.20.14 |
| r2 | GigabitEthernet0/1/2 | sw2 | Gi2/0/21 | MANAGEMENT_ACCESS | 130 | 1000 | — |
| ap1 | LAN | sw1 | Gi1/0/24 | AP_TRUNK | 40, 110, 120, 130 | 1000 | — |
| ap2 | LAN | sw2 | Gi2/0/24 | AP_TRUNK | 40, 110, 120, 130 | 1000 | — |
| sw1 | Stack1 | sw2 | Stack2 | STACK | — | 80000 | — |
| sw1 | Stack2 | sw2 | Stack1 | STACK | — | 80000 | — |


| Puesto | Switch | Puerto | IP PC | IP teléfono | Reserva Wi-Fi PC | Reserva Wi-Fi voz |
| --- | --- | --- | --- | --- | --- | --- |
| s20-pc01 | 1 | 1 | 10.70.20.10 | 10.70.84.10 | 10.81.20.10 | 10.82.20.10 |
| s20-pc02 | 2 | 1 | 10.70.20.11 | 10.70.84.11 | 10.81.20.11 | 10.82.20.11 |
| s20-pc03 | 1 | 2 | 10.70.20.12 | 10.70.84.12 | 10.81.20.12 | 10.82.20.12 |
| s20-pc04 | 2 | 2 | 10.70.20.13 | 10.70.84.13 | 10.81.20.13 | 10.82.20.13 |
| s20-pc05 | 1 | 3 | 10.70.20.14 | 10.70.84.14 | 10.81.20.14 | 10.82.20.14 |
| s20-pc06 | 2 | 3 | 10.70.20.15 | 10.70.84.15 | 10.81.20.15 | 10.82.20.15 |
| s20-pc07 | 1 | 4 | 10.70.20.16 | 10.70.84.16 | 10.81.20.16 | 10.82.20.16 |
| s20-pc08 | 2 | 4 | 10.70.20.17 | 10.70.84.17 | 10.81.20.17 | 10.82.20.17 |
| s20-pc09 | 1 | 5 | 10.70.20.18 | 10.70.84.18 | 10.81.20.18 | 10.82.20.18 |
| s20-pc10 | 2 | 5 | 10.70.20.19 | 10.70.84.19 | 10.81.20.19 | 10.82.20.19 |
| s20-pc11 | 1 | 6 | 10.70.20.20 | 10.70.84.20 | 10.81.20.20 | 10.82.20.20 |
| s20-pc12 | 2 | 6 | 10.70.20.21 | 10.70.84.21 | 10.81.20.21 | 10.82.20.21 |
| s20-pc13 | 1 | 7 | 10.70.20.22 | 10.70.84.22 | 10.81.20.22 | 10.82.20.22 |
| s20-pc14 | 2 | 7 | 10.70.20.23 | 10.70.84.23 | 10.81.20.23 | 10.82.20.23 |
| s20-pc15 | 1 | 8 | 10.70.20.24 | 10.70.84.24 | 10.81.20.24 | 10.82.20.24 |
| s20-pc16 | 2 | 8 | 10.70.20.25 | 10.70.84.25 | 10.81.20.25 | 10.82.20.25 |
| s20-pc17 | 1 | 9 | 10.70.20.26 | 10.70.84.26 | 10.81.20.26 | 10.82.20.26 |
| s20-pc18 | 2 | 9 | 10.70.20.27 | 10.70.84.27 | 10.81.20.27 | 10.82.20.27 |
| s20-pc19 | 1 | 10 | 10.70.20.28 | 10.70.84.28 | 10.81.20.28 | 10.82.20.28 |
| s20-pc20 | 2 | 10 | 10.70.20.29 | 10.70.84.29 | 10.81.20.29 | 10.82.20.29 |
| s20-pc21 | 1 | 11 | 10.70.20.30 | 10.70.84.30 | 10.81.20.30 | 10.82.20.30 |
| s20-pc22 | 2 | 11 | 10.70.20.31 | 10.70.84.31 | 10.81.20.31 | 10.82.20.31 |
| s20-pc23 | 1 | 12 | 10.70.20.32 | 10.70.84.32 | 10.81.20.32 | 10.82.20.32 |
| s20-pc24 | 2 | 12 | 10.70.20.33 | 10.70.84.33 | 10.81.20.33 | 10.82.20.33 |
| s20-pc25 | 1 | 13 | 10.70.20.34 | 10.70.84.34 | 10.81.20.34 | 10.82.20.34 |
| s20-pc26 | 2 | 13 | 10.70.20.35 | 10.70.84.35 | 10.81.20.35 | 10.82.20.35 |
| s20-pc27 | 1 | 14 | 10.70.20.36 | 10.70.84.36 | 10.81.20.36 | 10.82.20.36 |
| s20-pc28 | 2 | 14 | 10.70.20.37 | 10.70.84.37 | 10.81.20.37 | 10.82.20.37 |


**Transporte starlink — VLAN 201 — wanA.**

| Rol de entrega | Dirección |
| --- | --- |
| network | 10.252.20.0/29 |
| cpe | 10.252.20.1 |
| r1 | 10.252.20.2 |
| r2 | 10.252.20.3 |


**Transporte leo — VLAN 202 — wanB.**

| Rol de entrega | Dirección |
| --- | --- |
| network | 10.252.20.8/29 |
| cpe | 10.252.20.9 |
| r1 | 10.252.20.10 |
| r2 | 10.252.20.11 |


**Transporte entel5g — VLAN 203 — wanA.**

| Rol de entrega | Dirección |
| --- | --- |
| network | 10.252.20.16/29 |
| cpe | 10.252.20.17 |
| r1 | 10.252.20.18 |
| r2 | 10.252.20.19 |


**Transporte wom4g — VLAN 204 — wanB.**

| Rol de entrega | Dirección |
| --- | --- |
| network | 10.252.20.24/29 |
| cpe | 10.252.20.25 |
| r1 | 10.252.20.26 |
| r2 | 10.252.20.27 |


**Reservas de túneles (numeración según lista de la ficha).**

| Rol / candidato | Dirección |
| --- | --- |
| .1.hub_public_ip | 198.51.100.4 |
| .1.network | 10.253.20.0/30 |
| .1.branch_ip | 10.253.20.1 |
| .1.hub_ip | 10.253.20.2 |
| .2.hub_public_ip | 203.0.113.4 |
| .2.network | 10.253.20.4/30 |
| .2.branch_ip | 10.253.20.5 |
| .2.hub_ip | 10.253.20.6 |
| .3.hub_public_ip | 198.51.100.4 |
| .3.network | 10.253.20.8/30 |
| .3.branch_ip | 10.253.20.9 |
| .3.hub_ip | 10.253.20.10 |
| .4.hub_public_ip | 203.0.113.4 |
| .4.network | 10.253.20.12/30 |
| .4.branch_ip | 10.253.20.13 |
| .4.hub_ip | 10.253.20.14 |
| .5.hub_public_ip | 198.51.100.4 |
| .5.network | 10.253.20.16/30 |
| .5.branch_ip | 10.253.20.17 |
| .5.hub_ip | 10.253.20.18 |
| .6.hub_public_ip | 203.0.113.4 |
| .6.network | 10.253.20.20/30 |
| .6.branch_ip | 10.253.20.21 |
| .6.hub_ip | 10.253.20.22 |
| .7.hub_public_ip | 198.51.100.4 |
| .7.network | 10.253.20.24/30 |
| .7.branch_ip | 10.253.20.25 |
| .7.hub_ip | 10.253.20.26 |
| .8.hub_public_ip | 203.0.113.4 |
| .8.network | 10.253.20.28/30 |
| .8.branch_ip | 10.253.20.29 |
| .8.hub_ip | 10.253.20.30 |
| .9.hub_public_ip | 198.51.100.4 |
| .9.network | 10.253.20.32/30 |
| .9.branch_ip | 10.253.20.33 |
| .9.hub_ip | 10.253.20.34 |
| .10.hub_public_ip | 203.0.113.4 |
| .10.network | 10.253.20.36/30 |
| .10.branch_ip | 10.253.20.37 |
| .10.hub_ip | 10.253.20.38 |
| .11.hub_public_ip | 198.51.100.4 |
| .11.network | 10.253.20.40/30 |
| .11.branch_ip | 10.253.20.41 |
| .11.hub_ip | 10.253.20.42 |
| .12.hub_public_ip | 203.0.113.4 |
| .12.network | 10.253.20.44/30 |
| .12.branch_ip | 10.253.20.45 |
| .12.hub_ip | 10.253.20.46 |
| .13.hub_public_ip | 198.51.100.4 |
| .13.network | 10.253.20.48/30 |
| .13.branch_ip | 10.253.20.49 |
| .13.hub_ip | 10.253.20.50 |
| .14.hub_public_ip | 203.0.113.4 |
| .14.network | 10.253.20.52/30 |
| .14.branch_ip | 10.253.20.53 |
| .14.hub_ip | 10.253.20.54 |
| .15.hub_public_ip | 198.51.100.4 |
| .15.network | 10.253.20.56/30 |
| .15.branch_ip | 10.253.20.57 |
| .15.hub_ip | 10.253.20.58 |
| .16.hub_public_ip | 203.0.113.4 |
| .16.network | 10.253.20.60/30 |
| .16.branch_ip | 10.253.20.61 |
| .16.hub_ip | 10.253.20.62 |

### S21 — Hanga Roa (Isla de Pascua)

17 PCs y 17 teléfonos existentes.

| Función | ANTES | DESPUÉS |
| --- | --- | --- |
| Routers | 1 × C1121X-8P | 2 × C1121X-8P |
| Switches | 1 × C9200L-24P-4G-E | C9200L-24P-4G-E + C9200L-24P-4G-E |
| Firewall | Sin equipo dedicado | Sin appliance remoto; seguridad central |
| Distribución WAN | MPLS y accesos ISP del escenario base | wanA: E50UG; wanB: E50UG |


| Red | VLAN | Subred | Gateway / roles |
| --- | --- | --- | --- |
| users | 10 | 10.70.21.0/25 | 10.70.21.1 |
| voice | 20 | 10.70.85.0/25 | 10.70.85.1 |
| guests | 40 | 10.70.117.0/26 | 10.70.117.1 |
| wifi_users | 110 | 10.81.21.0/25 | 10.81.21.1 |
| wifi_voice | 120 | 10.82.21.0/25 | 10.82.21.1 |
| management | 130 | 10.80.21.0/27 | 10.80.21.1 |


| Gestión | Dirección |
| --- | --- |
| sw1 | 10.80.21.1 |
| sw2 | 10.80.21.1 |
| r1 | 10.80.21.2 |
| r2 | 10.80.21.3 |
| wanA | 10.80.21.6 |
| wanB | 10.80.21.7 |
| ap1 | 10.80.21.24 |
| ap2 | 10.80.21.25 |


| Origen | Puerto | Destino | Puerto | Función | VLAN/red | Mbps | IP / agregado lógico |
| --- | --- | --- | --- | --- | --- | --- | --- |
| cpe:starlink | LAN | wanA | ether1 | WAN_ACCESS | 201 | 1000 | — |
| cpe:entel5g | LAN | wanA | ether2 | WAN_ACCESS | 203 | 1000 | — |
| r1 | GigabitEthernet0/0/0 | wanA | ether3 | WAN_TRUNK | 201, 203 | 1000 | — |
| r2 | GigabitEthernet0/0/0 | wanA | ether4 | WAN_TRUNK | 201, 203 | 1000 | — |
| wanA | ether5 | sw1 | Gi1/0/22 | MANAGEMENT_ACCESS | 130 | 1000 | — |
| cpe:leo | LAN | wanB | ether1 | WAN_ACCESS | 202 | 1000 | — |
| cpe:wom4g | LAN | wanB | ether2 | WAN_ACCESS | 204 | 1000 | — |
| r1 | GigabitEthernet0/0/1 | wanB | ether3 | WAN_TRUNK | 202, 204 | 1000 | — |
| r2 | GigabitEthernet0/0/1 | wanB | ether4 | WAN_TRUNK | 202, 204 | 1000 | — |
| wanB | ether5 | sw2 | Gi2/0/22 | MANAGEMENT_ACCESS | 130 | 1000 | — |
| r1 | GigabitEthernet0/1/0 | sw1 | Gi1/0/19 | LAN_ROUTED | 172.31.21.0/30 | 1000 | router_ip: 172.31.21.1; stack_ip: 172.31.21.2 |
| r1 | GigabitEthernet0/1/1 | sw2 | Gi2/0/19 | LAN_ROUTED | 172.31.21.4/30 | 1000 | router_ip: 172.31.21.5; stack_ip: 172.31.21.6 |
| r1 | GigabitEthernet0/1/2 | sw1 | Gi1/0/21 | MANAGEMENT_ACCESS | 130 | 1000 | — |
| r2 | GigabitEthernet0/1/0 | sw1 | Gi1/0/20 | LAN_ROUTED | 172.31.21.8/30 | 1000 | router_ip: 172.31.21.9; stack_ip: 172.31.21.10 |
| r2 | GigabitEthernet0/1/1 | sw2 | Gi2/0/20 | LAN_ROUTED | 172.31.21.12/30 | 1000 | router_ip: 172.31.21.13; stack_ip: 172.31.21.14 |
| r2 | GigabitEthernet0/1/2 | sw2 | Gi2/0/21 | MANAGEMENT_ACCESS | 130 | 1000 | — |
| ap1 | LAN | sw1 | Gi1/0/24 | AP_TRUNK | 40, 110, 120, 130 | 1000 | — |
| ap2 | LAN | sw2 | Gi2/0/24 | AP_TRUNK | 40, 110, 120, 130 | 1000 | — |
| sw1 | Stack1 | sw2 | Stack2 | STACK | — | 80000 | — |
| sw1 | Stack2 | sw2 | Stack1 | STACK | — | 80000 | — |


| Puesto | Switch | Puerto | IP PC | IP teléfono | Reserva Wi-Fi PC | Reserva Wi-Fi voz |
| --- | --- | --- | --- | --- | --- | --- |
| s21-pc01 | 1 | 1 | 10.70.21.10 | 10.70.85.10 | 10.81.21.10 | 10.82.21.10 |
| s21-pc02 | 2 | 1 | 10.70.21.11 | 10.70.85.11 | 10.81.21.11 | 10.82.21.11 |
| s21-pc03 | 1 | 2 | 10.70.21.12 | 10.70.85.12 | 10.81.21.12 | 10.82.21.12 |
| s21-pc04 | 2 | 2 | 10.70.21.13 | 10.70.85.13 | 10.81.21.13 | 10.82.21.13 |
| s21-pc05 | 1 | 3 | 10.70.21.14 | 10.70.85.14 | 10.81.21.14 | 10.82.21.14 |
| s21-pc06 | 2 | 3 | 10.70.21.15 | 10.70.85.15 | 10.81.21.15 | 10.82.21.15 |
| s21-pc07 | 1 | 4 | 10.70.21.16 | 10.70.85.16 | 10.81.21.16 | 10.82.21.16 |
| s21-pc08 | 2 | 4 | 10.70.21.17 | 10.70.85.17 | 10.81.21.17 | 10.82.21.17 |
| s21-pc09 | 1 | 5 | 10.70.21.18 | 10.70.85.18 | 10.81.21.18 | 10.82.21.18 |
| s21-pc10 | 2 | 5 | 10.70.21.19 | 10.70.85.19 | 10.81.21.19 | 10.82.21.19 |
| s21-pc11 | 1 | 6 | 10.70.21.20 | 10.70.85.20 | 10.81.21.20 | 10.82.21.20 |
| s21-pc12 | 2 | 6 | 10.70.21.21 | 10.70.85.21 | 10.81.21.21 | 10.82.21.21 |
| s21-pc13 | 1 | 7 | 10.70.21.22 | 10.70.85.22 | 10.81.21.22 | 10.82.21.22 |
| s21-pc14 | 2 | 7 | 10.70.21.23 | 10.70.85.23 | 10.81.21.23 | 10.82.21.23 |
| s21-pc15 | 1 | 8 | 10.70.21.24 | 10.70.85.24 | 10.81.21.24 | 10.82.21.24 |
| s21-pc16 | 2 | 8 | 10.70.21.25 | 10.70.85.25 | 10.81.21.25 | 10.82.21.25 |
| s21-pc17 | 1 | 9 | 10.70.21.26 | 10.70.85.26 | 10.81.21.26 | 10.82.21.26 |


**Transporte starlink — VLAN 201 — wanA.**

| Rol de entrega | Dirección |
| --- | --- |
| network | 10.252.21.0/29 |
| cpe | 10.252.21.1 |
| r1 | 10.252.21.2 |
| r2 | 10.252.21.3 |


**Transporte leo — VLAN 202 — wanB.**

| Rol de entrega | Dirección |
| --- | --- |
| network | 10.252.21.8/29 |
| cpe | 10.252.21.9 |
| r1 | 10.252.21.10 |
| r2 | 10.252.21.11 |


**Transporte entel5g — VLAN 203 — wanA.**

| Rol de entrega | Dirección |
| --- | --- |
| network | 10.252.21.16/29 |
| cpe | 10.252.21.17 |
| r1 | 10.252.21.18 |
| r2 | 10.252.21.19 |


**Transporte wom4g — VLAN 204 — wanB.**

| Rol de entrega | Dirección |
| --- | --- |
| network | 10.252.21.24/29 |
| cpe | 10.252.21.25 |
| r1 | 10.252.21.26 |
| r2 | 10.252.21.27 |


**Reservas de túneles (numeración según lista de la ficha).**

| Rol / candidato | Dirección |
| --- | --- |
| .1.hub_public_ip | 198.51.100.4 |
| .1.network | 10.253.21.0/30 |
| .1.branch_ip | 10.253.21.1 |
| .1.hub_ip | 10.253.21.2 |
| .2.hub_public_ip | 203.0.113.4 |
| .2.network | 10.253.21.4/30 |
| .2.branch_ip | 10.253.21.5 |
| .2.hub_ip | 10.253.21.6 |
| .3.hub_public_ip | 198.51.100.4 |
| .3.network | 10.253.21.8/30 |
| .3.branch_ip | 10.253.21.9 |
| .3.hub_ip | 10.253.21.10 |
| .4.hub_public_ip | 203.0.113.4 |
| .4.network | 10.253.21.12/30 |
| .4.branch_ip | 10.253.21.13 |
| .4.hub_ip | 10.253.21.14 |
| .5.hub_public_ip | 198.51.100.4 |
| .5.network | 10.253.21.16/30 |
| .5.branch_ip | 10.253.21.17 |
| .5.hub_ip | 10.253.21.18 |
| .6.hub_public_ip | 203.0.113.4 |
| .6.network | 10.253.21.20/30 |
| .6.branch_ip | 10.253.21.21 |
| .6.hub_ip | 10.253.21.22 |
| .7.hub_public_ip | 198.51.100.4 |
| .7.network | 10.253.21.24/30 |
| .7.branch_ip | 10.253.21.25 |
| .7.hub_ip | 10.253.21.26 |
| .8.hub_public_ip | 203.0.113.4 |
| .8.network | 10.253.21.28/30 |
| .8.branch_ip | 10.253.21.29 |
| .8.hub_ip | 10.253.21.30 |
| .9.hub_public_ip | 198.51.100.4 |
| .9.network | 10.253.21.32/30 |
| .9.branch_ip | 10.253.21.33 |
| .9.hub_ip | 10.253.21.34 |
| .10.hub_public_ip | 203.0.113.4 |
| .10.network | 10.253.21.36/30 |
| .10.branch_ip | 10.253.21.37 |
| .10.hub_ip | 10.253.21.38 |
| .11.hub_public_ip | 198.51.100.4 |
| .11.network | 10.253.21.40/30 |
| .11.branch_ip | 10.253.21.41 |
| .11.hub_ip | 10.253.21.42 |
| .12.hub_public_ip | 203.0.113.4 |
| .12.network | 10.253.21.44/30 |
| .12.branch_ip | 10.253.21.45 |
| .12.hub_ip | 10.253.21.46 |
| .13.hub_public_ip | 198.51.100.4 |
| .13.network | 10.253.21.48/30 |
| .13.branch_ip | 10.253.21.49 |
| .13.hub_ip | 10.253.21.50 |
| .14.hub_public_ip | 203.0.113.4 |
| .14.network | 10.253.21.52/30 |
| .14.branch_ip | 10.253.21.53 |
| .14.hub_ip | 10.253.21.54 |
| .15.hub_public_ip | 198.51.100.4 |
| .15.network | 10.253.21.56/30 |
| .15.branch_ip | 10.253.21.57 |
| .15.hub_ip | 10.253.21.58 |
| .16.hub_public_ip | 203.0.113.4 |
| .16.network | 10.253.21.60/30 |
| .16.branch_ip | 10.253.21.61 |
| .16.hub_ip | 10.253.21.62 |

### S22 — Antártica Chilena

8 PCs y 8 teléfonos existentes.

| Función | ANTES | DESPUÉS |
| --- | --- | --- |
| Routers | 1 × C1121X-8P | 2 × C1121X-8P |
| Switches | 1 × C9200L-24P-4G-E | C9200L-24P-4G-E + C9200L-24P-4G-E |
| Firewall | Sin equipo dedicado | Sin appliance remoto; seguridad central |
| Distribución WAN | MPLS y accesos ISP del escenario base | wanA: E50UG; wanB: E50UG |


| Red | VLAN | Subred | Gateway / roles |
| --- | --- | --- | --- |
| users | 10 | 10.70.22.0/25 | 10.70.22.1 |
| voice | 20 | 10.70.86.0/25 | 10.70.86.1 |
| guests | 40 | 10.70.118.0/26 | 10.70.118.1 |
| wifi_users | 110 | 10.81.22.0/25 | 10.81.22.1 |
| wifi_voice | 120 | 10.82.22.0/25 | 10.82.22.1 |
| management | 130 | 10.80.22.0/27 | 10.80.22.1 |


| Gestión | Dirección |
| --- | --- |
| sw1 | 10.80.22.1 |
| sw2 | 10.80.22.1 |
| r1 | 10.80.22.2 |
| r2 | 10.80.22.3 |
| wanA | 10.80.22.6 |
| wanB | 10.80.22.7 |
| ap1 | 10.80.22.24 |
| ap2 | 10.80.22.25 |


| Origen | Puerto | Destino | Puerto | Función | VLAN/red | Mbps | IP / agregado lógico |
| --- | --- | --- | --- | --- | --- | --- | --- |
| cpe:starlink | LAN | wanA | ether1 | WAN_ACCESS | 201 | 1000 | — |
| cpe:entel5g | LAN | wanA | ether2 | WAN_ACCESS | 203 | 1000 | — |
| r1 | GigabitEthernet0/0/0 | wanA | ether3 | WAN_TRUNK | 201, 203 | 1000 | — |
| r2 | GigabitEthernet0/0/0 | wanA | ether4 | WAN_TRUNK | 201, 203 | 1000 | — |
| wanA | ether5 | sw1 | Gi1/0/22 | MANAGEMENT_ACCESS | 130 | 1000 | — |
| cpe:leo | LAN | wanB | ether1 | WAN_ACCESS | 202 | 1000 | — |
| cpe:wom4g | LAN | wanB | ether2 | WAN_ACCESS | 204 | 1000 | — |
| r1 | GigabitEthernet0/0/1 | wanB | ether3 | WAN_TRUNK | 202, 204 | 1000 | — |
| r2 | GigabitEthernet0/0/1 | wanB | ether4 | WAN_TRUNK | 202, 204 | 1000 | — |
| wanB | ether5 | sw2 | Gi2/0/22 | MANAGEMENT_ACCESS | 130 | 1000 | — |
| r1 | GigabitEthernet0/1/0 | sw1 | Gi1/0/19 | LAN_ROUTED | 172.31.22.0/30 | 1000 | router_ip: 172.31.22.1; stack_ip: 172.31.22.2 |
| r1 | GigabitEthernet0/1/1 | sw2 | Gi2/0/19 | LAN_ROUTED | 172.31.22.4/30 | 1000 | router_ip: 172.31.22.5; stack_ip: 172.31.22.6 |
| r1 | GigabitEthernet0/1/2 | sw1 | Gi1/0/21 | MANAGEMENT_ACCESS | 130 | 1000 | — |
| r2 | GigabitEthernet0/1/0 | sw1 | Gi1/0/20 | LAN_ROUTED | 172.31.22.8/30 | 1000 | router_ip: 172.31.22.9; stack_ip: 172.31.22.10 |
| r2 | GigabitEthernet0/1/1 | sw2 | Gi2/0/20 | LAN_ROUTED | 172.31.22.12/30 | 1000 | router_ip: 172.31.22.13; stack_ip: 172.31.22.14 |
| r2 | GigabitEthernet0/1/2 | sw2 | Gi2/0/21 | MANAGEMENT_ACCESS | 130 | 1000 | — |
| ap1 | LAN | sw1 | Gi1/0/24 | AP_TRUNK | 40, 110, 120, 130 | 1000 | — |
| ap2 | LAN | sw2 | Gi2/0/24 | AP_TRUNK | 40, 110, 120, 130 | 1000 | — |
| sw1 | Stack1 | sw2 | Stack2 | STACK | — | 80000 | — |
| sw1 | Stack2 | sw2 | Stack1 | STACK | — | 80000 | — |


| Puesto | Switch | Puerto | IP PC | IP teléfono | Reserva Wi-Fi PC | Reserva Wi-Fi voz |
| --- | --- | --- | --- | --- | --- | --- |
| s22-pc01 | 1 | 1 | 10.70.22.10 | 10.70.86.10 | 10.81.22.10 | 10.82.22.10 |
| s22-pc02 | 2 | 1 | 10.70.22.11 | 10.70.86.11 | 10.81.22.11 | 10.82.22.11 |
| s22-pc03 | 1 | 2 | 10.70.22.12 | 10.70.86.12 | 10.81.22.12 | 10.82.22.12 |
| s22-pc04 | 2 | 2 | 10.70.22.13 | 10.70.86.13 | 10.81.22.13 | 10.82.22.13 |
| s22-pc05 | 1 | 3 | 10.70.22.14 | 10.70.86.14 | 10.81.22.14 | 10.82.22.14 |
| s22-pc06 | 2 | 3 | 10.70.22.15 | 10.70.86.15 | 10.81.22.15 | 10.82.22.15 |
| s22-pc07 | 1 | 4 | 10.70.22.16 | 10.70.86.16 | 10.81.22.16 | 10.82.22.16 |
| s22-pc08 | 2 | 4 | 10.70.22.17 | 10.70.86.17 | 10.81.22.17 | 10.82.22.17 |


**Transporte starlink — VLAN 201 — wanA.**

| Rol de entrega | Dirección |
| --- | --- |
| network | 10.252.22.0/29 |
| cpe | 10.252.22.1 |
| r1 | 10.252.22.2 |
| r2 | 10.252.22.3 |


**Transporte leo — VLAN 202 — wanB.**

| Rol de entrega | Dirección |
| --- | --- |
| network | 10.252.22.8/29 |
| cpe | 10.252.22.9 |
| r1 | 10.252.22.10 |
| r2 | 10.252.22.11 |


**Transporte entel5g — VLAN 203 — wanA.**

| Rol de entrega | Dirección |
| --- | --- |
| network | 10.252.22.16/29 |
| cpe | 10.252.22.17 |
| r1 | 10.252.22.18 |
| r2 | 10.252.22.19 |


**Transporte wom4g — VLAN 204 — wanB.**

| Rol de entrega | Dirección |
| --- | --- |
| network | 10.252.22.24/29 |
| cpe | 10.252.22.25 |
| r1 | 10.252.22.26 |
| r2 | 10.252.22.27 |


**Reservas de túneles (numeración según lista de la ficha).**

| Rol / candidato | Dirección |
| --- | --- |
| .1.hub_public_ip | 198.51.100.4 |
| .1.network | 10.253.22.0/30 |
| .1.branch_ip | 10.253.22.1 |
| .1.hub_ip | 10.253.22.2 |
| .2.hub_public_ip | 203.0.113.4 |
| .2.network | 10.253.22.4/30 |
| .2.branch_ip | 10.253.22.5 |
| .2.hub_ip | 10.253.22.6 |
| .3.hub_public_ip | 198.51.100.4 |
| .3.network | 10.253.22.8/30 |
| .3.branch_ip | 10.253.22.9 |
| .3.hub_ip | 10.253.22.10 |
| .4.hub_public_ip | 203.0.113.4 |
| .4.network | 10.253.22.12/30 |
| .4.branch_ip | 10.253.22.13 |
| .4.hub_ip | 10.253.22.14 |
| .5.hub_public_ip | 198.51.100.4 |
| .5.network | 10.253.22.16/30 |
| .5.branch_ip | 10.253.22.17 |
| .5.hub_ip | 10.253.22.18 |
| .6.hub_public_ip | 203.0.113.4 |
| .6.network | 10.253.22.20/30 |
| .6.branch_ip | 10.253.22.21 |
| .6.hub_ip | 10.253.22.22 |
| .7.hub_public_ip | 198.51.100.4 |
| .7.network | 10.253.22.24/30 |
| .7.branch_ip | 10.253.22.25 |
| .7.hub_ip | 10.253.22.26 |
| .8.hub_public_ip | 203.0.113.4 |
| .8.network | 10.253.22.28/30 |
| .8.branch_ip | 10.253.22.29 |
| .8.hub_ip | 10.253.22.30 |
| .9.hub_public_ip | 198.51.100.4 |
| .9.network | 10.253.22.32/30 |
| .9.branch_ip | 10.253.22.33 |
| .9.hub_ip | 10.253.22.34 |
| .10.hub_public_ip | 203.0.113.4 |
| .10.network | 10.253.22.36/30 |
| .10.branch_ip | 10.253.22.37 |
| .10.hub_ip | 10.253.22.38 |
| .11.hub_public_ip | 198.51.100.4 |
| .11.network | 10.253.22.40/30 |
| .11.branch_ip | 10.253.22.41 |
| .11.hub_ip | 10.253.22.42 |
| .12.hub_public_ip | 203.0.113.4 |
| .12.network | 10.253.22.44/30 |
| .12.branch_ip | 10.253.22.45 |
| .12.hub_ip | 10.253.22.46 |
| .13.hub_public_ip | 198.51.100.4 |
| .13.network | 10.253.22.48/30 |
| .13.branch_ip | 10.253.22.49 |
| .13.hub_ip | 10.253.22.50 |
| .14.hub_public_ip | 203.0.113.4 |
| .14.network | 10.253.22.52/30 |
| .14.branch_ip | 10.253.22.53 |
| .14.hub_ip | 10.253.22.54 |
| .15.hub_public_ip | 198.51.100.4 |
| .15.network | 10.253.22.56/30 |
| .15.branch_ip | 10.253.22.57 |
| .15.hub_ip | 10.253.22.58 |
| .16.hub_public_ip | 203.0.113.4 |
| .16.network | 10.253.22.60/30 |
| .16.branch_ip | 10.253.22.61 |
| .16.hub_ip | 10.253.22.62 |

## Alternativa B

### CM — Santiago Centro

55 PCs y 55 teléfonos existentes.

| Función | ANTES | DESPUÉS |
| --- | --- | --- |
| Routers | 2 × CISCO2911-SEC/K9 | Routing en el par de firewalls |
| Switches | 2 × C9200L-48P-4X-E | C9200L-48P-4X-E + C9200L-48P-4X-E |
| Firewall | 1 × ASA5512-K9 | 2 × OPNsense DEC3852 |
| Distribución WAN | MPLS y accesos ISP del escenario base | wanA: CRS310-8G+2S+IN; wanB: E50UG |


| Red | VLAN | Subred | Gateway / roles |
| --- | --- | --- | --- |
| users | 10 | 10.70.0.0/25 | 10.70.0.1 |
| voice | 20 | 10.70.64.0/25 | 10.70.64.1 |
| guests | 40 | 10.70.96.0/26 | 10.70.96.1 |
| wifi_users | 110 | 10.81.0.0/25 | 10.81.0.1 |
| wifi_voice | 120 | 10.82.0.0/25 | 10.82.0.1 |
| management | 130 | 10.80.0.0/27 | 10.80.0.1 |
| servers | 50 | 10.70.200.0/24 | 10.70.200.1 |
| firewall_transit | 131 | 172.31.0.0/29 | stack: 172.31.0.1; ha_firewall: 172.31.0.2 |


| Gestión | Dirección |
| --- | --- |
| sw1 | 10.80.0.1 |
| sw2 | 10.80.0.1 |
| fwA | 10.80.0.2 |
| fwB | 10.80.0.3 |
| wanA | 10.80.0.6 |
| wanB | 10.80.0.7 |
| ap1 | 10.80.0.24 |
| ap2 | 10.80.0.25 |
| ap3 | 10.80.0.26 |
| ap4 | 10.80.0.27 |


| Origen | Puerto | Destino | Puerto | Función | VLAN/red | Mbps | IP / agregado lógico |
| --- | --- | --- | --- | --- | --- | --- | --- |
| cpe:starlink | LAN_2_5G_REQUIRED | wanA | ether1 | WAN_ACCESS | 201 | 2500 | — |
| cpe:leo | LAN_1G_REQUIRED | wanB | ether1 | WAN_ACCESS | 202 | 1000 | — |
| fwA | RJ45-0 | wanA | ether2 | WAN_ACCESS | 201 | 2500 | — |
| fwA | RJ45-1 | wanB | ether2 | WAN_ACCESS | 202 | 1000 | — |
| fwA | SFP+-X0 | sw1 | Te1/1/1 | LAN_AGGREGATE | 50, 131 | 10000 | port_channel: Po21; firewall_aggregate: ae1 |
| fwA | SFP+-X1 | sw2 | Te2/1/1 | LAN_AGGREGATE | 50, 131 | 10000 | port_channel: Po21; firewall_aggregate: ae1 |
| fwA | RJ45-2 | sw1 | Gi1/0/41 | MANAGEMENT_ACCESS | 130 | 1000 | — |
| fwB | RJ45-0 | wanA | ether3 | WAN_ACCESS | 201 | 2500 | — |
| fwB | RJ45-1 | wanB | ether3 | WAN_ACCESS | 202 | 1000 | — |
| fwB | SFP+-X0 | sw1 | Te1/1/2 | LAN_AGGREGATE | 50, 131 | 10000 | port_channel: Po22; firewall_aggregate: ae1 |
| fwB | SFP+-X1 | sw2 | Te2/1/2 | LAN_AGGREGATE | 50, 131 | 10000 | port_channel: Po22; firewall_aggregate: ae1 |
| fwB | RJ45-2 | sw2 | Gi2/0/41 | MANAGEMENT_ACCESS | 130 | 1000 | — |
| fwA | RJ45-3 | fwB | RJ45-3 | HA1 | 172.31.255.0/30 | 2500 | — |
| wanA | ether4 | sw1 | Gi1/0/42 | MANAGEMENT_ACCESS | 130 | 1000 | — |
| ap1 | LAN | sw1 | Gi1/0/47 | AP_TRUNK | 40, 110, 120, 130 | 1000 | — |
| ap2 | LAN | sw1 | Gi1/0/48 | AP_TRUNK | 40, 110, 120, 130 | 1000 | — |
| wanB | ether4 | sw2 | Gi2/0/42 | MANAGEMENT_ACCESS | 130 | 1000 | — |
| ap3 | LAN | sw2 | Gi2/0/47 | AP_TRUNK | 40, 110, 120, 130 | 1000 | — |
| ap4 | LAN | sw2 | Gi2/0/48 | AP_TRUNK | 40, 110, 120, 130 | 1000 | — |
| dc1 | NIC1 | sw1 | Gi1/0/43 | SERVER_TRUNK | 50, 130 | 1000 | — |
| dc1 | NIC2 | sw2 | Gi2/0/43 | SERVER_TRUNK | 50, 130 | 1000 | — |
| dc2 | NIC1 | sw1 | Gi1/0/44 | SERVER_TRUNK | 50, 130 | 1000 | — |
| dc2 | NIC2 | sw2 | Gi2/0/44 | SERVER_TRUNK | 50, 130 | 1000 | — |
| backup | NIC1 | sw1 | Gi1/0/45 | SERVER_ACCESS | 50 | 1000 | — |
| backup | NIC2 | sw2 | Gi2/0/45 | SERVER_ACCESS | 50 | 1000 | — |
| sw1 | Stack1 | sw2 | Stack2 | STACK | — | 80000 | — |
| sw1 | Stack2 | sw2 | Stack1 | STACK | — | 80000 | — |


| Puesto | Switch | Puerto | IP PC | IP teléfono | Reserva Wi-Fi PC | Reserva Wi-Fi voz |
| --- | --- | --- | --- | --- | --- | --- |
| cm-pc01 | 1 | 1 | 10.70.0.10 | 10.70.64.10 | 10.81.0.10 | 10.82.0.10 |
| cm-pc02 | 2 | 1 | 10.70.0.11 | 10.70.64.11 | 10.81.0.11 | 10.82.0.11 |
| cm-pc03 | 1 | 2 | 10.70.0.12 | 10.70.64.12 | 10.81.0.12 | 10.82.0.12 |
| cm-pc04 | 2 | 2 | 10.70.0.13 | 10.70.64.13 | 10.81.0.13 | 10.82.0.13 |
| cm-pc05 | 1 | 3 | 10.70.0.14 | 10.70.64.14 | 10.81.0.14 | 10.82.0.14 |
| cm-pc06 | 2 | 3 | 10.70.0.15 | 10.70.64.15 | 10.81.0.15 | 10.82.0.15 |
| cm-pc07 | 1 | 4 | 10.70.0.16 | 10.70.64.16 | 10.81.0.16 | 10.82.0.16 |
| cm-pc08 | 2 | 4 | 10.70.0.17 | 10.70.64.17 | 10.81.0.17 | 10.82.0.17 |
| cm-pc09 | 1 | 5 | 10.70.0.18 | 10.70.64.18 | 10.81.0.18 | 10.82.0.18 |
| cm-pc10 | 2 | 5 | 10.70.0.19 | 10.70.64.19 | 10.81.0.19 | 10.82.0.19 |
| cm-pc11 | 1 | 6 | 10.70.0.20 | 10.70.64.20 | 10.81.0.20 | 10.82.0.20 |
| cm-pc12 | 2 | 6 | 10.70.0.21 | 10.70.64.21 | 10.81.0.21 | 10.82.0.21 |
| cm-pc13 | 1 | 7 | 10.70.0.22 | 10.70.64.22 | 10.81.0.22 | 10.82.0.22 |
| cm-pc14 | 2 | 7 | 10.70.0.23 | 10.70.64.23 | 10.81.0.23 | 10.82.0.23 |
| cm-pc15 | 1 | 8 | 10.70.0.24 | 10.70.64.24 | 10.81.0.24 | 10.82.0.24 |
| cm-pc16 | 2 | 8 | 10.70.0.25 | 10.70.64.25 | 10.81.0.25 | 10.82.0.25 |
| cm-pc17 | 1 | 9 | 10.70.0.26 | 10.70.64.26 | 10.81.0.26 | 10.82.0.26 |
| cm-pc18 | 2 | 9 | 10.70.0.27 | 10.70.64.27 | 10.81.0.27 | 10.82.0.27 |
| cm-pc19 | 1 | 10 | 10.70.0.28 | 10.70.64.28 | 10.81.0.28 | 10.82.0.28 |
| cm-pc20 | 2 | 10 | 10.70.0.29 | 10.70.64.29 | 10.81.0.29 | 10.82.0.29 |
| cm-pc21 | 1 | 11 | 10.70.0.30 | 10.70.64.30 | 10.81.0.30 | 10.82.0.30 |
| cm-pc22 | 2 | 11 | 10.70.0.31 | 10.70.64.31 | 10.81.0.31 | 10.82.0.31 |
| cm-pc23 | 1 | 12 | 10.70.0.32 | 10.70.64.32 | 10.81.0.32 | 10.82.0.32 |
| cm-pc24 | 2 | 12 | 10.70.0.33 | 10.70.64.33 | 10.81.0.33 | 10.82.0.33 |
| cm-pc25 | 1 | 13 | 10.70.0.34 | 10.70.64.34 | 10.81.0.34 | 10.82.0.34 |
| cm-pc26 | 2 | 13 | 10.70.0.35 | 10.70.64.35 | 10.81.0.35 | 10.82.0.35 |
| cm-pc27 | 1 | 14 | 10.70.0.36 | 10.70.64.36 | 10.81.0.36 | 10.82.0.36 |
| cm-pc28 | 2 | 14 | 10.70.0.37 | 10.70.64.37 | 10.81.0.37 | 10.82.0.37 |
| cm-pc29 | 1 | 15 | 10.70.0.38 | 10.70.64.38 | 10.81.0.38 | 10.82.0.38 |
| cm-pc30 | 2 | 15 | 10.70.0.39 | 10.70.64.39 | 10.81.0.39 | 10.82.0.39 |
| cm-pc31 | 1 | 16 | 10.70.0.40 | 10.70.64.40 | 10.81.0.40 | 10.82.0.40 |
| cm-pc32 | 2 | 16 | 10.70.0.41 | 10.70.64.41 | 10.81.0.41 | 10.82.0.41 |
| cm-pc33 | 1 | 17 | 10.70.0.42 | 10.70.64.42 | 10.81.0.42 | 10.82.0.42 |
| cm-pc34 | 2 | 17 | 10.70.0.43 | 10.70.64.43 | 10.81.0.43 | 10.82.0.43 |
| cm-pc35 | 1 | 18 | 10.70.0.44 | 10.70.64.44 | 10.81.0.44 | 10.82.0.44 |
| cm-pc36 | 2 | 18 | 10.70.0.45 | 10.70.64.45 | 10.81.0.45 | 10.82.0.45 |
| cm-pc37 | 1 | 19 | 10.70.0.46 | 10.70.64.46 | 10.81.0.46 | 10.82.0.46 |
| cm-pc38 | 2 | 19 | 10.70.0.47 | 10.70.64.47 | 10.81.0.47 | 10.82.0.47 |
| cm-pc39 | 1 | 20 | 10.70.0.48 | 10.70.64.48 | 10.81.0.48 | 10.82.0.48 |
| cm-pc40 | 2 | 20 | 10.70.0.49 | 10.70.64.49 | 10.81.0.49 | 10.82.0.49 |
| cm-pc41 | 1 | 21 | 10.70.0.50 | 10.70.64.50 | 10.81.0.50 | 10.82.0.50 |
| cm-pc42 | 2 | 21 | 10.70.0.51 | 10.70.64.51 | 10.81.0.51 | 10.82.0.51 |
| cm-pc43 | 1 | 22 | 10.70.0.52 | 10.70.64.52 | 10.81.0.52 | 10.82.0.52 |
| cm-pc44 | 2 | 22 | 10.70.0.53 | 10.70.64.53 | 10.81.0.53 | 10.82.0.53 |
| cm-pc45 | 1 | 23 | 10.70.0.54 | 10.70.64.54 | 10.81.0.54 | 10.82.0.54 |
| cm-pc46 | 2 | 23 | 10.70.0.55 | 10.70.64.55 | 10.81.0.55 | 10.82.0.55 |
| cm-pc47 | 1 | 24 | 10.70.0.56 | 10.70.64.56 | 10.81.0.56 | 10.82.0.56 |
| cm-pc48 | 2 | 24 | 10.70.0.57 | 10.70.64.57 | 10.81.0.57 | 10.82.0.57 |
| cm-pc49 | 1 | 25 | 10.70.0.58 | 10.70.64.58 | 10.81.0.58 | 10.82.0.58 |
| cm-pc50 | 2 | 25 | 10.70.0.59 | 10.70.64.59 | 10.81.0.59 | 10.82.0.59 |
| cm-pc51 | 1 | 26 | 10.70.0.60 | 10.70.64.60 | 10.81.0.60 | 10.82.0.60 |
| cm-pc52 | 2 | 26 | 10.70.0.61 | 10.70.64.61 | 10.81.0.61 | 10.82.0.61 |
| cm-pc53 | 1 | 27 | 10.70.0.62 | 10.70.64.62 | 10.81.0.62 | 10.82.0.62 |
| cm-pc54 | 2 | 27 | 10.70.0.63 | 10.70.64.63 | 10.81.0.63 | 10.82.0.63 |
| cm-pc55 | 1 | 28 | 10.70.0.64 | 10.70.64.64 | 10.81.0.64 | 10.82.0.64 |


**Transporte starlink — VLAN 201 — wanA.**

| Rol de entrega | Dirección |
| --- | --- |
| network | 198.51.100.0/29 |
| cpe | 198.51.100.1 |
| fwA | 198.51.100.2 |
| fwB | 198.51.100.3 |
| vip | 198.51.100.4 |


**Transporte leo — VLAN 202 — wanB.**

| Rol de entrega | Dirección |
| --- | --- |
| network | 203.0.113.0/29 |
| cpe | 203.0.113.1 |
| fwA | 203.0.113.2 |
| fwB | 203.0.113.3 |
| vip | 203.0.113.4 |


| Servidor | Modelo | Gestión | RAM ANTES → DESPUÉS GiB | Útil ANTES → DESPUÉS GB |
| --- | --- | --- | --- | --- |
| DC-01 | Dell PowerEdge R740 | 10.80.0.11 | 64 → 64 | 2000 → 2000 |
| DC-02 | Dell PowerEdge R740 | 10.80.0.12 | 32 → 64 | 1000 → 3840 |
| BKP-01 | Dell PowerEdge R540 | 10.70.200.50 | 16 → 16 | 8000 → 8000 |


| Host normal | Servicio | IP | Puerto |
| --- | --- | --- | --- |
| DC-01 | Aplicación HTTPS | 10.70.200.10 | TCP 443 |
| DC-01 | PostgreSQL | 10.70.200.11 | TCP 5432 |
| DC-02 | PBX | 10.70.200.20 | TCP 5061 / UDP 10000–20000 |
| DC-02 | DNS / NTP | 10.70.200.30 | TCP/UDP 53 / UDP 123 |
| DC-02 | AAA / RADIUS / TACACS+ | 10.70.200.31 | UDP 1812–1813 / TCP 49 |
| DC-02 | NMS / registros | 10.70.200.40 | UDP 161 / TCP 6514 |
| DC-02 | Bastión NOC | 10.80.0.10 | TCP 22 / 443 |
| BKP-01 | Repositorio | 10.70.200.50 | Acceso restringido a los hosts de respaldo |

### S01 — Providencia

30 PCs y 30 teléfonos existentes.

| Función | ANTES | DESPUÉS |
| --- | --- | --- |
| Routers | 1 × CISCO1921-SEC/K9 | 2 × CCR2004-16G-2S+ |
| Switches | 1 × WS-C2960S-48LPS-L | CRS328-24P-4S+RM + CRS328-24P-4S+RM |
| Firewall | Sin equipo dedicado | Sin appliance remoto; seguridad central |
| Distribución WAN | MPLS y accesos ISP del escenario base | wanA: E50UG; wanB: E50UG |


| Red | VLAN | Subred | Gateway / roles |
| --- | --- | --- | --- |
| users | 10 | 10.70.1.0/25 | 10.70.1.1 |
| voice | 20 | 10.70.65.0/25 | 10.70.65.1 |
| guests | 40 | 10.70.97.0/26 | 10.70.97.1 |
| wifi_users | 110 | 10.81.1.0/25 | 10.81.1.1 |
| wifi_voice | 120 | 10.82.1.0/25 | 10.82.1.1 |
| management | 130 | 10.80.1.0/27 | 10.80.1.1 |


| Gestión | Dirección |
| --- | --- |
| sw1 | 10.80.1.2 |
| sw2 | 10.80.1.3 |
| r1 | 10.80.1.4 |
| r2 | 10.80.1.5 |
| wanA | 10.80.1.6 |
| wanB | 10.80.1.7 |
| ap1 | 10.80.1.24 |
| ap2 | 10.80.1.25 |


| Origen | Puerto | Destino | Puerto | Función | VLAN/red | Mbps | IP / agregado lógico |
| --- | --- | --- | --- | --- | --- | --- | --- |
| cpe:starlink | LAN | wanA | ether1 | WAN_ACCESS | 201 | 1000 | — |
| cpe:entel5g | LAN | wanA | ether2 | WAN_ACCESS | 203 | 1000 | — |
| r1 | ether1 | wanA | ether3 | WAN_TRUNK | 201, 203 | 1000 | — |
| r2 | ether1 | wanA | ether4 | WAN_TRUNK | 201, 203 | 1000 | — |
| wanA | ether5 | sw1 | ether22 | MANAGEMENT_ACCESS | 130 | 1000 | — |
| cpe:leo | LAN | wanB | ether1 | WAN_ACCESS | 202 | 1000 | — |
| cpe:wom4g | LAN | wanB | ether2 | WAN_ACCESS | 204 | 1000 | — |
| r1 | ether2 | wanB | ether3 | WAN_TRUNK | 202, 204 | 1000 | — |
| r2 | ether2 | wanB | ether4 | WAN_TRUNK | 202, 204 | 1000 | — |
| wanB | ether5 | sw2 | ether22 | MANAGEMENT_ACCESS | 130 | 1000 | — |
| r1 | ether3 | sw1 | ether19 | LAN_ROUTED | 172.31.1.0/30 | 1000 | router_ip: 172.31.1.1; stack_ip: 172.31.1.2 |
| r1 | ether4 | sw2 | ether19 | LAN_ROUTED | 172.31.1.4/30 | 1000 | router_ip: 172.31.1.5; stack_ip: 172.31.1.6 |
| r1 | ether5 | sw1 | ether21 | MANAGEMENT_ACCESS | 130 | 1000 | — |
| r2 | ether3 | sw1 | ether20 | LAN_ROUTED | 172.31.1.8/30 | 1000 | router_ip: 172.31.1.9; stack_ip: 172.31.1.10 |
| r2 | ether4 | sw2 | ether20 | LAN_ROUTED | 172.31.1.12/30 | 1000 | router_ip: 172.31.1.13; stack_ip: 172.31.1.14 |
| r2 | ether5 | sw2 | ether21 | MANAGEMENT_ACCESS | 130 | 1000 | — |
| ap1 | LAN | sw1 | ether24 | AP_TRUNK | 40, 110, 120, 130 | 1000 | — |
| ap2 | LAN | sw2 | ether24 | AP_TRUNK | 40, 110, 120, 130 | 1000 | — |
| sw1 | sfp-sfpplus1 | sw2 | sfp-sfpplus2 | STACK | 10, 20, 40, 110, 120, 130 | 10000 | — |
| sw1 | sfp-sfpplus2 | sw2 | sfp-sfpplus1 | STACK | 10, 20, 40, 110, 120, 130 | 10000 | — |


| Puesto | Switch | Puerto | IP PC | IP teléfono | Reserva Wi-Fi PC | Reserva Wi-Fi voz |
| --- | --- | --- | --- | --- | --- | --- |
| s01-pc01 | 1 | 1 | 10.70.1.10 | 10.70.65.10 | 10.81.1.10 | 10.82.1.10 |
| s01-pc02 | 2 | 1 | 10.70.1.11 | 10.70.65.11 | 10.81.1.11 | 10.82.1.11 |
| s01-pc03 | 1 | 2 | 10.70.1.12 | 10.70.65.12 | 10.81.1.12 | 10.82.1.12 |
| s01-pc04 | 2 | 2 | 10.70.1.13 | 10.70.65.13 | 10.81.1.13 | 10.82.1.13 |
| s01-pc05 | 1 | 3 | 10.70.1.14 | 10.70.65.14 | 10.81.1.14 | 10.82.1.14 |
| s01-pc06 | 2 | 3 | 10.70.1.15 | 10.70.65.15 | 10.81.1.15 | 10.82.1.15 |
| s01-pc07 | 1 | 4 | 10.70.1.16 | 10.70.65.16 | 10.81.1.16 | 10.82.1.16 |
| s01-pc08 | 2 | 4 | 10.70.1.17 | 10.70.65.17 | 10.81.1.17 | 10.82.1.17 |
| s01-pc09 | 1 | 5 | 10.70.1.18 | 10.70.65.18 | 10.81.1.18 | 10.82.1.18 |
| s01-pc10 | 2 | 5 | 10.70.1.19 | 10.70.65.19 | 10.81.1.19 | 10.82.1.19 |
| s01-pc11 | 1 | 6 | 10.70.1.20 | 10.70.65.20 | 10.81.1.20 | 10.82.1.20 |
| s01-pc12 | 2 | 6 | 10.70.1.21 | 10.70.65.21 | 10.81.1.21 | 10.82.1.21 |
| s01-pc13 | 1 | 7 | 10.70.1.22 | 10.70.65.22 | 10.81.1.22 | 10.82.1.22 |
| s01-pc14 | 2 | 7 | 10.70.1.23 | 10.70.65.23 | 10.81.1.23 | 10.82.1.23 |
| s01-pc15 | 1 | 8 | 10.70.1.24 | 10.70.65.24 | 10.81.1.24 | 10.82.1.24 |
| s01-pc16 | 2 | 8 | 10.70.1.25 | 10.70.65.25 | 10.81.1.25 | 10.82.1.25 |
| s01-pc17 | 1 | 9 | 10.70.1.26 | 10.70.65.26 | 10.81.1.26 | 10.82.1.26 |
| s01-pc18 | 2 | 9 | 10.70.1.27 | 10.70.65.27 | 10.81.1.27 | 10.82.1.27 |
| s01-pc19 | 1 | 10 | 10.70.1.28 | 10.70.65.28 | 10.81.1.28 | 10.82.1.28 |
| s01-pc20 | 2 | 10 | 10.70.1.29 | 10.70.65.29 | 10.81.1.29 | 10.82.1.29 |
| s01-pc21 | 1 | 11 | 10.70.1.30 | 10.70.65.30 | 10.81.1.30 | 10.82.1.30 |
| s01-pc22 | 2 | 11 | 10.70.1.31 | 10.70.65.31 | 10.81.1.31 | 10.82.1.31 |
| s01-pc23 | 1 | 12 | 10.70.1.32 | 10.70.65.32 | 10.81.1.32 | 10.82.1.32 |
| s01-pc24 | 2 | 12 | 10.70.1.33 | 10.70.65.33 | 10.81.1.33 | 10.82.1.33 |
| s01-pc25 | 1 | 13 | 10.70.1.34 | 10.70.65.34 | 10.81.1.34 | 10.82.1.34 |
| s01-pc26 | 2 | 13 | 10.70.1.35 | 10.70.65.35 | 10.81.1.35 | 10.82.1.35 |
| s01-pc27 | 1 | 14 | 10.70.1.36 | 10.70.65.36 | 10.81.1.36 | 10.82.1.36 |
| s01-pc28 | 2 | 14 | 10.70.1.37 | 10.70.65.37 | 10.81.1.37 | 10.82.1.37 |
| s01-pc29 | 1 | 15 | 10.70.1.38 | 10.70.65.38 | 10.81.1.38 | 10.82.1.38 |
| s01-pc30 | 2 | 15 | 10.70.1.39 | 10.70.65.39 | 10.81.1.39 | 10.82.1.39 |


**Transporte starlink — VLAN 201 — wanA.**

| Rol de entrega | Dirección |
| --- | --- |
| network | 10.252.1.0/29 |
| cpe | 10.252.1.1 |
| r1 | 10.252.1.2 |
| r2 | 10.252.1.3 |


**Transporte leo — VLAN 202 — wanB.**

| Rol de entrega | Dirección |
| --- | --- |
| network | 10.252.1.8/29 |
| cpe | 10.252.1.9 |
| r1 | 10.252.1.10 |
| r2 | 10.252.1.11 |


**Transporte entel5g — VLAN 203 — wanA.**

| Rol de entrega | Dirección |
| --- | --- |
| network | 10.252.1.16/29 |
| cpe | 10.252.1.17 |
| r1 | 10.252.1.18 |
| r2 | 10.252.1.19 |


**Transporte wom4g — VLAN 204 — wanB.**

| Rol de entrega | Dirección |
| --- | --- |
| network | 10.252.1.24/29 |
| cpe | 10.252.1.25 |
| r1 | 10.252.1.26 |
| r2 | 10.252.1.27 |


**Reservas de túneles (numeración según lista de la ficha).**

| Rol / candidato | Dirección |
| --- | --- |
| .1.hub_public_ip | 198.51.100.4 |
| .1.network | 10.253.1.0/30 |
| .1.branch_ip | 10.253.1.1 |
| .1.hub_ip | 10.253.1.2 |
| .2.hub_public_ip | 203.0.113.4 |
| .2.network | 10.253.1.4/30 |
| .2.branch_ip | 10.253.1.5 |
| .2.hub_ip | 10.253.1.6 |
| .3.hub_public_ip | 198.51.100.4 |
| .3.network | 10.253.1.8/30 |
| .3.branch_ip | 10.253.1.9 |
| .3.hub_ip | 10.253.1.10 |
| .4.hub_public_ip | 203.0.113.4 |
| .4.network | 10.253.1.12/30 |
| .4.branch_ip | 10.253.1.13 |
| .4.hub_ip | 10.253.1.14 |
| .5.hub_public_ip | 198.51.100.4 |
| .5.network | 10.253.1.16/30 |
| .5.branch_ip | 10.253.1.17 |
| .5.hub_ip | 10.253.1.18 |
| .6.hub_public_ip | 203.0.113.4 |
| .6.network | 10.253.1.20/30 |
| .6.branch_ip | 10.253.1.21 |
| .6.hub_ip | 10.253.1.22 |
| .7.hub_public_ip | 198.51.100.4 |
| .7.network | 10.253.1.24/30 |
| .7.branch_ip | 10.253.1.25 |
| .7.hub_ip | 10.253.1.26 |
| .8.hub_public_ip | 203.0.113.4 |
| .8.network | 10.253.1.28/30 |
| .8.branch_ip | 10.253.1.29 |
| .8.hub_ip | 10.253.1.30 |
| .9.hub_public_ip | 198.51.100.4 |
| .9.network | 10.253.1.32/30 |
| .9.branch_ip | 10.253.1.33 |
| .9.hub_ip | 10.253.1.34 |
| .10.hub_public_ip | 203.0.113.4 |
| .10.network | 10.253.1.36/30 |
| .10.branch_ip | 10.253.1.37 |
| .10.hub_ip | 10.253.1.38 |
| .11.hub_public_ip | 198.51.100.4 |
| .11.network | 10.253.1.40/30 |
| .11.branch_ip | 10.253.1.41 |
| .11.hub_ip | 10.253.1.42 |
| .12.hub_public_ip | 203.0.113.4 |
| .12.network | 10.253.1.44/30 |
| .12.branch_ip | 10.253.1.45 |
| .12.hub_ip | 10.253.1.46 |
| .13.hub_public_ip | 198.51.100.4 |
| .13.network | 10.253.1.48/30 |
| .13.branch_ip | 10.253.1.49 |
| .13.hub_ip | 10.253.1.50 |
| .14.hub_public_ip | 203.0.113.4 |
| .14.network | 10.253.1.52/30 |
| .14.branch_ip | 10.253.1.53 |
| .14.hub_ip | 10.253.1.54 |
| .15.hub_public_ip | 198.51.100.4 |
| .15.network | 10.253.1.56/30 |
| .15.branch_ip | 10.253.1.57 |
| .15.hub_ip | 10.253.1.58 |
| .16.hub_public_ip | 203.0.113.4 |
| .16.network | 10.253.1.60/30 |
| .16.branch_ip | 10.253.1.61 |
| .16.hub_ip | 10.253.1.62 |

### S02 — Las Condes

30 PCs y 30 teléfonos existentes.

| Función | ANTES | DESPUÉS |
| --- | --- | --- |
| Routers | 1 × ISR4321/K9 | 2 × CCR2004-16G-2S+ |
| Switches | 1 × C9200L-48P-4G-E | CRS328-24P-4S+RM + CRS328-24P-4S+RM |
| Firewall | Sin equipo dedicado | Sin appliance remoto; seguridad central |
| Distribución WAN | MPLS y accesos ISP del escenario base | wanA: E50UG; wanB: E50UG |


| Red | VLAN | Subred | Gateway / roles |
| --- | --- | --- | --- |
| users | 10 | 10.70.2.0/25 | 10.70.2.1 |
| voice | 20 | 10.70.66.0/25 | 10.70.66.1 |
| guests | 40 | 10.70.98.0/26 | 10.70.98.1 |
| wifi_users | 110 | 10.81.2.0/25 | 10.81.2.1 |
| wifi_voice | 120 | 10.82.2.0/25 | 10.82.2.1 |
| management | 130 | 10.80.2.0/27 | 10.80.2.1 |


| Gestión | Dirección |
| --- | --- |
| sw1 | 10.80.2.2 |
| sw2 | 10.80.2.3 |
| r1 | 10.80.2.4 |
| r2 | 10.80.2.5 |
| wanA | 10.80.2.6 |
| wanB | 10.80.2.7 |
| ap1 | 10.80.2.24 |
| ap2 | 10.80.2.25 |


| Origen | Puerto | Destino | Puerto | Función | VLAN/red | Mbps | IP / agregado lógico |
| --- | --- | --- | --- | --- | --- | --- | --- |
| cpe:starlink | LAN | wanA | ether1 | WAN_ACCESS | 201 | 1000 | — |
| cpe:entel5g | LAN | wanA | ether2 | WAN_ACCESS | 203 | 1000 | — |
| r1 | ether1 | wanA | ether3 | WAN_TRUNK | 201, 203 | 1000 | — |
| r2 | ether1 | wanA | ether4 | WAN_TRUNK | 201, 203 | 1000 | — |
| wanA | ether5 | sw1 | ether22 | MANAGEMENT_ACCESS | 130 | 1000 | — |
| cpe:leo | LAN | wanB | ether1 | WAN_ACCESS | 202 | 1000 | — |
| cpe:wom4g | LAN | wanB | ether2 | WAN_ACCESS | 204 | 1000 | — |
| r1 | ether2 | wanB | ether3 | WAN_TRUNK | 202, 204 | 1000 | — |
| r2 | ether2 | wanB | ether4 | WAN_TRUNK | 202, 204 | 1000 | — |
| wanB | ether5 | sw2 | ether22 | MANAGEMENT_ACCESS | 130 | 1000 | — |
| r1 | ether3 | sw1 | ether19 | LAN_ROUTED | 172.31.2.0/30 | 1000 | router_ip: 172.31.2.1; stack_ip: 172.31.2.2 |
| r1 | ether4 | sw2 | ether19 | LAN_ROUTED | 172.31.2.4/30 | 1000 | router_ip: 172.31.2.5; stack_ip: 172.31.2.6 |
| r1 | ether5 | sw1 | ether21 | MANAGEMENT_ACCESS | 130 | 1000 | — |
| r2 | ether3 | sw1 | ether20 | LAN_ROUTED | 172.31.2.8/30 | 1000 | router_ip: 172.31.2.9; stack_ip: 172.31.2.10 |
| r2 | ether4 | sw2 | ether20 | LAN_ROUTED | 172.31.2.12/30 | 1000 | router_ip: 172.31.2.13; stack_ip: 172.31.2.14 |
| r2 | ether5 | sw2 | ether21 | MANAGEMENT_ACCESS | 130 | 1000 | — |
| ap1 | LAN | sw1 | ether24 | AP_TRUNK | 40, 110, 120, 130 | 1000 | — |
| ap2 | LAN | sw2 | ether24 | AP_TRUNK | 40, 110, 120, 130 | 1000 | — |
| sw1 | sfp-sfpplus1 | sw2 | sfp-sfpplus2 | STACK | 10, 20, 40, 110, 120, 130 | 10000 | — |
| sw1 | sfp-sfpplus2 | sw2 | sfp-sfpplus1 | STACK | 10, 20, 40, 110, 120, 130 | 10000 | — |


| Puesto | Switch | Puerto | IP PC | IP teléfono | Reserva Wi-Fi PC | Reserva Wi-Fi voz |
| --- | --- | --- | --- | --- | --- | --- |
| s02-pc01 | 1 | 1 | 10.70.2.10 | 10.70.66.10 | 10.81.2.10 | 10.82.2.10 |
| s02-pc02 | 2 | 1 | 10.70.2.11 | 10.70.66.11 | 10.81.2.11 | 10.82.2.11 |
| s02-pc03 | 1 | 2 | 10.70.2.12 | 10.70.66.12 | 10.81.2.12 | 10.82.2.12 |
| s02-pc04 | 2 | 2 | 10.70.2.13 | 10.70.66.13 | 10.81.2.13 | 10.82.2.13 |
| s02-pc05 | 1 | 3 | 10.70.2.14 | 10.70.66.14 | 10.81.2.14 | 10.82.2.14 |
| s02-pc06 | 2 | 3 | 10.70.2.15 | 10.70.66.15 | 10.81.2.15 | 10.82.2.15 |
| s02-pc07 | 1 | 4 | 10.70.2.16 | 10.70.66.16 | 10.81.2.16 | 10.82.2.16 |
| s02-pc08 | 2 | 4 | 10.70.2.17 | 10.70.66.17 | 10.81.2.17 | 10.82.2.17 |
| s02-pc09 | 1 | 5 | 10.70.2.18 | 10.70.66.18 | 10.81.2.18 | 10.82.2.18 |
| s02-pc10 | 2 | 5 | 10.70.2.19 | 10.70.66.19 | 10.81.2.19 | 10.82.2.19 |
| s02-pc11 | 1 | 6 | 10.70.2.20 | 10.70.66.20 | 10.81.2.20 | 10.82.2.20 |
| s02-pc12 | 2 | 6 | 10.70.2.21 | 10.70.66.21 | 10.81.2.21 | 10.82.2.21 |
| s02-pc13 | 1 | 7 | 10.70.2.22 | 10.70.66.22 | 10.81.2.22 | 10.82.2.22 |
| s02-pc14 | 2 | 7 | 10.70.2.23 | 10.70.66.23 | 10.81.2.23 | 10.82.2.23 |
| s02-pc15 | 1 | 8 | 10.70.2.24 | 10.70.66.24 | 10.81.2.24 | 10.82.2.24 |
| s02-pc16 | 2 | 8 | 10.70.2.25 | 10.70.66.25 | 10.81.2.25 | 10.82.2.25 |
| s02-pc17 | 1 | 9 | 10.70.2.26 | 10.70.66.26 | 10.81.2.26 | 10.82.2.26 |
| s02-pc18 | 2 | 9 | 10.70.2.27 | 10.70.66.27 | 10.81.2.27 | 10.82.2.27 |
| s02-pc19 | 1 | 10 | 10.70.2.28 | 10.70.66.28 | 10.81.2.28 | 10.82.2.28 |
| s02-pc20 | 2 | 10 | 10.70.2.29 | 10.70.66.29 | 10.81.2.29 | 10.82.2.29 |
| s02-pc21 | 1 | 11 | 10.70.2.30 | 10.70.66.30 | 10.81.2.30 | 10.82.2.30 |
| s02-pc22 | 2 | 11 | 10.70.2.31 | 10.70.66.31 | 10.81.2.31 | 10.82.2.31 |
| s02-pc23 | 1 | 12 | 10.70.2.32 | 10.70.66.32 | 10.81.2.32 | 10.82.2.32 |
| s02-pc24 | 2 | 12 | 10.70.2.33 | 10.70.66.33 | 10.81.2.33 | 10.82.2.33 |
| s02-pc25 | 1 | 13 | 10.70.2.34 | 10.70.66.34 | 10.81.2.34 | 10.82.2.34 |
| s02-pc26 | 2 | 13 | 10.70.2.35 | 10.70.66.35 | 10.81.2.35 | 10.82.2.35 |
| s02-pc27 | 1 | 14 | 10.70.2.36 | 10.70.66.36 | 10.81.2.36 | 10.82.2.36 |
| s02-pc28 | 2 | 14 | 10.70.2.37 | 10.70.66.37 | 10.81.2.37 | 10.82.2.37 |
| s02-pc29 | 1 | 15 | 10.70.2.38 | 10.70.66.38 | 10.81.2.38 | 10.82.2.38 |
| s02-pc30 | 2 | 15 | 10.70.2.39 | 10.70.66.39 | 10.81.2.39 | 10.82.2.39 |


**Transporte starlink — VLAN 201 — wanA.**

| Rol de entrega | Dirección |
| --- | --- |
| network | 10.252.2.0/29 |
| cpe | 10.252.2.1 |
| r1 | 10.252.2.2 |
| r2 | 10.252.2.3 |


**Transporte leo — VLAN 202 — wanB.**

| Rol de entrega | Dirección |
| --- | --- |
| network | 10.252.2.8/29 |
| cpe | 10.252.2.9 |
| r1 | 10.252.2.10 |
| r2 | 10.252.2.11 |


**Transporte entel5g — VLAN 203 — wanA.**

| Rol de entrega | Dirección |
| --- | --- |
| network | 10.252.2.16/29 |
| cpe | 10.252.2.17 |
| r1 | 10.252.2.18 |
| r2 | 10.252.2.19 |


**Transporte wom4g — VLAN 204 — wanB.**

| Rol de entrega | Dirección |
| --- | --- |
| network | 10.252.2.24/29 |
| cpe | 10.252.2.25 |
| r1 | 10.252.2.26 |
| r2 | 10.252.2.27 |


**Reservas de túneles (numeración según lista de la ficha).**

| Rol / candidato | Dirección |
| --- | --- |
| .1.hub_public_ip | 198.51.100.4 |
| .1.network | 10.253.2.0/30 |
| .1.branch_ip | 10.253.2.1 |
| .1.hub_ip | 10.253.2.2 |
| .2.hub_public_ip | 203.0.113.4 |
| .2.network | 10.253.2.4/30 |
| .2.branch_ip | 10.253.2.5 |
| .2.hub_ip | 10.253.2.6 |
| .3.hub_public_ip | 198.51.100.4 |
| .3.network | 10.253.2.8/30 |
| .3.branch_ip | 10.253.2.9 |
| .3.hub_ip | 10.253.2.10 |
| .4.hub_public_ip | 203.0.113.4 |
| .4.network | 10.253.2.12/30 |
| .4.branch_ip | 10.253.2.13 |
| .4.hub_ip | 10.253.2.14 |
| .5.hub_public_ip | 198.51.100.4 |
| .5.network | 10.253.2.16/30 |
| .5.branch_ip | 10.253.2.17 |
| .5.hub_ip | 10.253.2.18 |
| .6.hub_public_ip | 203.0.113.4 |
| .6.network | 10.253.2.20/30 |
| .6.branch_ip | 10.253.2.21 |
| .6.hub_ip | 10.253.2.22 |
| .7.hub_public_ip | 198.51.100.4 |
| .7.network | 10.253.2.24/30 |
| .7.branch_ip | 10.253.2.25 |
| .7.hub_ip | 10.253.2.26 |
| .8.hub_public_ip | 203.0.113.4 |
| .8.network | 10.253.2.28/30 |
| .8.branch_ip | 10.253.2.29 |
| .8.hub_ip | 10.253.2.30 |
| .9.hub_public_ip | 198.51.100.4 |
| .9.network | 10.253.2.32/30 |
| .9.branch_ip | 10.253.2.33 |
| .9.hub_ip | 10.253.2.34 |
| .10.hub_public_ip | 203.0.113.4 |
| .10.network | 10.253.2.36/30 |
| .10.branch_ip | 10.253.2.37 |
| .10.hub_ip | 10.253.2.38 |
| .11.hub_public_ip | 198.51.100.4 |
| .11.network | 10.253.2.40/30 |
| .11.branch_ip | 10.253.2.41 |
| .11.hub_ip | 10.253.2.42 |
| .12.hub_public_ip | 203.0.113.4 |
| .12.network | 10.253.2.44/30 |
| .12.branch_ip | 10.253.2.45 |
| .12.hub_ip | 10.253.2.46 |
| .13.hub_public_ip | 198.51.100.4 |
| .13.network | 10.253.2.48/30 |
| .13.branch_ip | 10.253.2.49 |
| .13.hub_ip | 10.253.2.50 |
| .14.hub_public_ip | 203.0.113.4 |
| .14.network | 10.253.2.52/30 |
| .14.branch_ip | 10.253.2.53 |
| .14.hub_ip | 10.253.2.54 |
| .15.hub_public_ip | 198.51.100.4 |
| .15.network | 10.253.2.56/30 |
| .15.branch_ip | 10.253.2.57 |
| .15.hub_ip | 10.253.2.58 |
| .16.hub_public_ip | 203.0.113.4 |
| .16.network | 10.253.2.60/30 |
| .16.branch_ip | 10.253.2.61 |
| .16.hub_ip | 10.253.2.62 |

### S03 — Maipú

30 PCs y 30 teléfonos existentes.

| Función | ANTES | DESPUÉS |
| --- | --- | --- |
| Routers | 1 × CISCO1921-SEC/K9 | 2 × CCR2004-16G-2S+ |
| Switches | 1 × WS-C2960S-48LPS-L | CRS328-24P-4S+RM + CRS328-24P-4S+RM |
| Firewall | Sin equipo dedicado | Sin appliance remoto; seguridad central |
| Distribución WAN | MPLS y accesos ISP del escenario base | wanA: E50UG; wanB: E50UG |


| Red | VLAN | Subred | Gateway / roles |
| --- | --- | --- | --- |
| users | 10 | 10.70.3.0/25 | 10.70.3.1 |
| voice | 20 | 10.70.67.0/25 | 10.70.67.1 |
| guests | 40 | 10.70.99.0/26 | 10.70.99.1 |
| wifi_users | 110 | 10.81.3.0/25 | 10.81.3.1 |
| wifi_voice | 120 | 10.82.3.0/25 | 10.82.3.1 |
| management | 130 | 10.80.3.0/27 | 10.80.3.1 |


| Gestión | Dirección |
| --- | --- |
| sw1 | 10.80.3.2 |
| sw2 | 10.80.3.3 |
| r1 | 10.80.3.4 |
| r2 | 10.80.3.5 |
| wanA | 10.80.3.6 |
| wanB | 10.80.3.7 |
| ap1 | 10.80.3.24 |
| ap2 | 10.80.3.25 |


| Origen | Puerto | Destino | Puerto | Función | VLAN/red | Mbps | IP / agregado lógico |
| --- | --- | --- | --- | --- | --- | --- | --- |
| cpe:starlink | LAN | wanA | ether1 | WAN_ACCESS | 201 | 1000 | — |
| cpe:entel5g | LAN | wanA | ether2 | WAN_ACCESS | 203 | 1000 | — |
| r1 | ether1 | wanA | ether3 | WAN_TRUNK | 201, 203 | 1000 | — |
| r2 | ether1 | wanA | ether4 | WAN_TRUNK | 201, 203 | 1000 | — |
| wanA | ether5 | sw1 | ether22 | MANAGEMENT_ACCESS | 130 | 1000 | — |
| cpe:leo | LAN | wanB | ether1 | WAN_ACCESS | 202 | 1000 | — |
| cpe:wom4g | LAN | wanB | ether2 | WAN_ACCESS | 204 | 1000 | — |
| r1 | ether2 | wanB | ether3 | WAN_TRUNK | 202, 204 | 1000 | — |
| r2 | ether2 | wanB | ether4 | WAN_TRUNK | 202, 204 | 1000 | — |
| wanB | ether5 | sw2 | ether22 | MANAGEMENT_ACCESS | 130 | 1000 | — |
| r1 | ether3 | sw1 | ether19 | LAN_ROUTED | 172.31.3.0/30 | 1000 | router_ip: 172.31.3.1; stack_ip: 172.31.3.2 |
| r1 | ether4 | sw2 | ether19 | LAN_ROUTED | 172.31.3.4/30 | 1000 | router_ip: 172.31.3.5; stack_ip: 172.31.3.6 |
| r1 | ether5 | sw1 | ether21 | MANAGEMENT_ACCESS | 130 | 1000 | — |
| r2 | ether3 | sw1 | ether20 | LAN_ROUTED | 172.31.3.8/30 | 1000 | router_ip: 172.31.3.9; stack_ip: 172.31.3.10 |
| r2 | ether4 | sw2 | ether20 | LAN_ROUTED | 172.31.3.12/30 | 1000 | router_ip: 172.31.3.13; stack_ip: 172.31.3.14 |
| r2 | ether5 | sw2 | ether21 | MANAGEMENT_ACCESS | 130 | 1000 | — |
| ap1 | LAN | sw1 | ether24 | AP_TRUNK | 40, 110, 120, 130 | 1000 | — |
| ap2 | LAN | sw2 | ether24 | AP_TRUNK | 40, 110, 120, 130 | 1000 | — |
| sw1 | sfp-sfpplus1 | sw2 | sfp-sfpplus2 | STACK | 10, 20, 40, 110, 120, 130 | 10000 | — |
| sw1 | sfp-sfpplus2 | sw2 | sfp-sfpplus1 | STACK | 10, 20, 40, 110, 120, 130 | 10000 | — |


| Puesto | Switch | Puerto | IP PC | IP teléfono | Reserva Wi-Fi PC | Reserva Wi-Fi voz |
| --- | --- | --- | --- | --- | --- | --- |
| s03-pc01 | 1 | 1 | 10.70.3.10 | 10.70.67.10 | 10.81.3.10 | 10.82.3.10 |
| s03-pc02 | 2 | 1 | 10.70.3.11 | 10.70.67.11 | 10.81.3.11 | 10.82.3.11 |
| s03-pc03 | 1 | 2 | 10.70.3.12 | 10.70.67.12 | 10.81.3.12 | 10.82.3.12 |
| s03-pc04 | 2 | 2 | 10.70.3.13 | 10.70.67.13 | 10.81.3.13 | 10.82.3.13 |
| s03-pc05 | 1 | 3 | 10.70.3.14 | 10.70.67.14 | 10.81.3.14 | 10.82.3.14 |
| s03-pc06 | 2 | 3 | 10.70.3.15 | 10.70.67.15 | 10.81.3.15 | 10.82.3.15 |
| s03-pc07 | 1 | 4 | 10.70.3.16 | 10.70.67.16 | 10.81.3.16 | 10.82.3.16 |
| s03-pc08 | 2 | 4 | 10.70.3.17 | 10.70.67.17 | 10.81.3.17 | 10.82.3.17 |
| s03-pc09 | 1 | 5 | 10.70.3.18 | 10.70.67.18 | 10.81.3.18 | 10.82.3.18 |
| s03-pc10 | 2 | 5 | 10.70.3.19 | 10.70.67.19 | 10.81.3.19 | 10.82.3.19 |
| s03-pc11 | 1 | 6 | 10.70.3.20 | 10.70.67.20 | 10.81.3.20 | 10.82.3.20 |
| s03-pc12 | 2 | 6 | 10.70.3.21 | 10.70.67.21 | 10.81.3.21 | 10.82.3.21 |
| s03-pc13 | 1 | 7 | 10.70.3.22 | 10.70.67.22 | 10.81.3.22 | 10.82.3.22 |
| s03-pc14 | 2 | 7 | 10.70.3.23 | 10.70.67.23 | 10.81.3.23 | 10.82.3.23 |
| s03-pc15 | 1 | 8 | 10.70.3.24 | 10.70.67.24 | 10.81.3.24 | 10.82.3.24 |
| s03-pc16 | 2 | 8 | 10.70.3.25 | 10.70.67.25 | 10.81.3.25 | 10.82.3.25 |
| s03-pc17 | 1 | 9 | 10.70.3.26 | 10.70.67.26 | 10.81.3.26 | 10.82.3.26 |
| s03-pc18 | 2 | 9 | 10.70.3.27 | 10.70.67.27 | 10.81.3.27 | 10.82.3.27 |
| s03-pc19 | 1 | 10 | 10.70.3.28 | 10.70.67.28 | 10.81.3.28 | 10.82.3.28 |
| s03-pc20 | 2 | 10 | 10.70.3.29 | 10.70.67.29 | 10.81.3.29 | 10.82.3.29 |
| s03-pc21 | 1 | 11 | 10.70.3.30 | 10.70.67.30 | 10.81.3.30 | 10.82.3.30 |
| s03-pc22 | 2 | 11 | 10.70.3.31 | 10.70.67.31 | 10.81.3.31 | 10.82.3.31 |
| s03-pc23 | 1 | 12 | 10.70.3.32 | 10.70.67.32 | 10.81.3.32 | 10.82.3.32 |
| s03-pc24 | 2 | 12 | 10.70.3.33 | 10.70.67.33 | 10.81.3.33 | 10.82.3.33 |
| s03-pc25 | 1 | 13 | 10.70.3.34 | 10.70.67.34 | 10.81.3.34 | 10.82.3.34 |
| s03-pc26 | 2 | 13 | 10.70.3.35 | 10.70.67.35 | 10.81.3.35 | 10.82.3.35 |
| s03-pc27 | 1 | 14 | 10.70.3.36 | 10.70.67.36 | 10.81.3.36 | 10.82.3.36 |
| s03-pc28 | 2 | 14 | 10.70.3.37 | 10.70.67.37 | 10.81.3.37 | 10.82.3.37 |
| s03-pc29 | 1 | 15 | 10.70.3.38 | 10.70.67.38 | 10.81.3.38 | 10.82.3.38 |
| s03-pc30 | 2 | 15 | 10.70.3.39 | 10.70.67.39 | 10.81.3.39 | 10.82.3.39 |


**Transporte starlink — VLAN 201 — wanA.**

| Rol de entrega | Dirección |
| --- | --- |
| network | 10.252.3.0/29 |
| cpe | 10.252.3.1 |
| r1 | 10.252.3.2 |
| r2 | 10.252.3.3 |


**Transporte leo — VLAN 202 — wanB.**

| Rol de entrega | Dirección |
| --- | --- |
| network | 10.252.3.8/29 |
| cpe | 10.252.3.9 |
| r1 | 10.252.3.10 |
| r2 | 10.252.3.11 |


**Transporte entel5g — VLAN 203 — wanA.**

| Rol de entrega | Dirección |
| --- | --- |
| network | 10.252.3.16/29 |
| cpe | 10.252.3.17 |
| r1 | 10.252.3.18 |
| r2 | 10.252.3.19 |


**Transporte wom4g — VLAN 204 — wanB.**

| Rol de entrega | Dirección |
| --- | --- |
| network | 10.252.3.24/29 |
| cpe | 10.252.3.25 |
| r1 | 10.252.3.26 |
| r2 | 10.252.3.27 |


**Reservas de túneles (numeración según lista de la ficha).**

| Rol / candidato | Dirección |
| --- | --- |
| .1.hub_public_ip | 198.51.100.4 |
| .1.network | 10.253.3.0/30 |
| .1.branch_ip | 10.253.3.1 |
| .1.hub_ip | 10.253.3.2 |
| .2.hub_public_ip | 203.0.113.4 |
| .2.network | 10.253.3.4/30 |
| .2.branch_ip | 10.253.3.5 |
| .2.hub_ip | 10.253.3.6 |
| .3.hub_public_ip | 198.51.100.4 |
| .3.network | 10.253.3.8/30 |
| .3.branch_ip | 10.253.3.9 |
| .3.hub_ip | 10.253.3.10 |
| .4.hub_public_ip | 203.0.113.4 |
| .4.network | 10.253.3.12/30 |
| .4.branch_ip | 10.253.3.13 |
| .4.hub_ip | 10.253.3.14 |
| .5.hub_public_ip | 198.51.100.4 |
| .5.network | 10.253.3.16/30 |
| .5.branch_ip | 10.253.3.17 |
| .5.hub_ip | 10.253.3.18 |
| .6.hub_public_ip | 203.0.113.4 |
| .6.network | 10.253.3.20/30 |
| .6.branch_ip | 10.253.3.21 |
| .6.hub_ip | 10.253.3.22 |
| .7.hub_public_ip | 198.51.100.4 |
| .7.network | 10.253.3.24/30 |
| .7.branch_ip | 10.253.3.25 |
| .7.hub_ip | 10.253.3.26 |
| .8.hub_public_ip | 203.0.113.4 |
| .8.network | 10.253.3.28/30 |
| .8.branch_ip | 10.253.3.29 |
| .8.hub_ip | 10.253.3.30 |
| .9.hub_public_ip | 198.51.100.4 |
| .9.network | 10.253.3.32/30 |
| .9.branch_ip | 10.253.3.33 |
| .9.hub_ip | 10.253.3.34 |
| .10.hub_public_ip | 203.0.113.4 |
| .10.network | 10.253.3.36/30 |
| .10.branch_ip | 10.253.3.37 |
| .10.hub_ip | 10.253.3.38 |
| .11.hub_public_ip | 198.51.100.4 |
| .11.network | 10.253.3.40/30 |
| .11.branch_ip | 10.253.3.41 |
| .11.hub_ip | 10.253.3.42 |
| .12.hub_public_ip | 203.0.113.4 |
| .12.network | 10.253.3.44/30 |
| .12.branch_ip | 10.253.3.45 |
| .12.hub_ip | 10.253.3.46 |
| .13.hub_public_ip | 198.51.100.4 |
| .13.network | 10.253.3.48/30 |
| .13.branch_ip | 10.253.3.49 |
| .13.hub_ip | 10.253.3.50 |
| .14.hub_public_ip | 203.0.113.4 |
| .14.network | 10.253.3.52/30 |
| .14.branch_ip | 10.253.3.53 |
| .14.hub_ip | 10.253.3.54 |
| .15.hub_public_ip | 198.51.100.4 |
| .15.network | 10.253.3.56/30 |
| .15.branch_ip | 10.253.3.57 |
| .15.hub_ip | 10.253.3.58 |
| .16.hub_public_ip | 203.0.113.4 |
| .16.network | 10.253.3.60/30 |
| .16.branch_ip | 10.253.3.61 |
| .16.hub_ip | 10.253.3.62 |

### S04 — Puente Alto

30 PCs y 30 teléfonos existentes.

| Función | ANTES | DESPUÉS |
| --- | --- | --- |
| Routers | 1 × ISR4321/K9 | 2 × CCR2004-16G-2S+ |
| Switches | 1 × C9200L-48P-4G-E | CRS328-24P-4S+RM + CRS328-24P-4S+RM |
| Firewall | Sin equipo dedicado | Sin appliance remoto; seguridad central |
| Distribución WAN | MPLS y accesos ISP del escenario base | wanA: E50UG; wanB: E50UG |


| Red | VLAN | Subred | Gateway / roles |
| --- | --- | --- | --- |
| users | 10 | 10.70.4.0/25 | 10.70.4.1 |
| voice | 20 | 10.70.68.0/25 | 10.70.68.1 |
| guests | 40 | 10.70.100.0/26 | 10.70.100.1 |
| wifi_users | 110 | 10.81.4.0/25 | 10.81.4.1 |
| wifi_voice | 120 | 10.82.4.0/25 | 10.82.4.1 |
| management | 130 | 10.80.4.0/27 | 10.80.4.1 |


| Gestión | Dirección |
| --- | --- |
| sw1 | 10.80.4.2 |
| sw2 | 10.80.4.3 |
| r1 | 10.80.4.4 |
| r2 | 10.80.4.5 |
| wanA | 10.80.4.6 |
| wanB | 10.80.4.7 |
| ap1 | 10.80.4.24 |
| ap2 | 10.80.4.25 |


| Origen | Puerto | Destino | Puerto | Función | VLAN/red | Mbps | IP / agregado lógico |
| --- | --- | --- | --- | --- | --- | --- | --- |
| cpe:starlink | LAN | wanA | ether1 | WAN_ACCESS | 201 | 1000 | — |
| cpe:entel5g | LAN | wanA | ether2 | WAN_ACCESS | 203 | 1000 | — |
| r1 | ether1 | wanA | ether3 | WAN_TRUNK | 201, 203 | 1000 | — |
| r2 | ether1 | wanA | ether4 | WAN_TRUNK | 201, 203 | 1000 | — |
| wanA | ether5 | sw1 | ether22 | MANAGEMENT_ACCESS | 130 | 1000 | — |
| cpe:leo | LAN | wanB | ether1 | WAN_ACCESS | 202 | 1000 | — |
| cpe:wom4g | LAN | wanB | ether2 | WAN_ACCESS | 204 | 1000 | — |
| r1 | ether2 | wanB | ether3 | WAN_TRUNK | 202, 204 | 1000 | — |
| r2 | ether2 | wanB | ether4 | WAN_TRUNK | 202, 204 | 1000 | — |
| wanB | ether5 | sw2 | ether22 | MANAGEMENT_ACCESS | 130 | 1000 | — |
| r1 | ether3 | sw1 | ether19 | LAN_ROUTED | 172.31.4.0/30 | 1000 | router_ip: 172.31.4.1; stack_ip: 172.31.4.2 |
| r1 | ether4 | sw2 | ether19 | LAN_ROUTED | 172.31.4.4/30 | 1000 | router_ip: 172.31.4.5; stack_ip: 172.31.4.6 |
| r1 | ether5 | sw1 | ether21 | MANAGEMENT_ACCESS | 130 | 1000 | — |
| r2 | ether3 | sw1 | ether20 | LAN_ROUTED | 172.31.4.8/30 | 1000 | router_ip: 172.31.4.9; stack_ip: 172.31.4.10 |
| r2 | ether4 | sw2 | ether20 | LAN_ROUTED | 172.31.4.12/30 | 1000 | router_ip: 172.31.4.13; stack_ip: 172.31.4.14 |
| r2 | ether5 | sw2 | ether21 | MANAGEMENT_ACCESS | 130 | 1000 | — |
| ap1 | LAN | sw1 | ether24 | AP_TRUNK | 40, 110, 120, 130 | 1000 | — |
| ap2 | LAN | sw2 | ether24 | AP_TRUNK | 40, 110, 120, 130 | 1000 | — |
| sw1 | sfp-sfpplus1 | sw2 | sfp-sfpplus2 | STACK | 10, 20, 40, 110, 120, 130 | 10000 | — |
| sw1 | sfp-sfpplus2 | sw2 | sfp-sfpplus1 | STACK | 10, 20, 40, 110, 120, 130 | 10000 | — |


| Puesto | Switch | Puerto | IP PC | IP teléfono | Reserva Wi-Fi PC | Reserva Wi-Fi voz |
| --- | --- | --- | --- | --- | --- | --- |
| s04-pc01 | 1 | 1 | 10.70.4.10 | 10.70.68.10 | 10.81.4.10 | 10.82.4.10 |
| s04-pc02 | 2 | 1 | 10.70.4.11 | 10.70.68.11 | 10.81.4.11 | 10.82.4.11 |
| s04-pc03 | 1 | 2 | 10.70.4.12 | 10.70.68.12 | 10.81.4.12 | 10.82.4.12 |
| s04-pc04 | 2 | 2 | 10.70.4.13 | 10.70.68.13 | 10.81.4.13 | 10.82.4.13 |
| s04-pc05 | 1 | 3 | 10.70.4.14 | 10.70.68.14 | 10.81.4.14 | 10.82.4.14 |
| s04-pc06 | 2 | 3 | 10.70.4.15 | 10.70.68.15 | 10.81.4.15 | 10.82.4.15 |
| s04-pc07 | 1 | 4 | 10.70.4.16 | 10.70.68.16 | 10.81.4.16 | 10.82.4.16 |
| s04-pc08 | 2 | 4 | 10.70.4.17 | 10.70.68.17 | 10.81.4.17 | 10.82.4.17 |
| s04-pc09 | 1 | 5 | 10.70.4.18 | 10.70.68.18 | 10.81.4.18 | 10.82.4.18 |
| s04-pc10 | 2 | 5 | 10.70.4.19 | 10.70.68.19 | 10.81.4.19 | 10.82.4.19 |
| s04-pc11 | 1 | 6 | 10.70.4.20 | 10.70.68.20 | 10.81.4.20 | 10.82.4.20 |
| s04-pc12 | 2 | 6 | 10.70.4.21 | 10.70.68.21 | 10.81.4.21 | 10.82.4.21 |
| s04-pc13 | 1 | 7 | 10.70.4.22 | 10.70.68.22 | 10.81.4.22 | 10.82.4.22 |
| s04-pc14 | 2 | 7 | 10.70.4.23 | 10.70.68.23 | 10.81.4.23 | 10.82.4.23 |
| s04-pc15 | 1 | 8 | 10.70.4.24 | 10.70.68.24 | 10.81.4.24 | 10.82.4.24 |
| s04-pc16 | 2 | 8 | 10.70.4.25 | 10.70.68.25 | 10.81.4.25 | 10.82.4.25 |
| s04-pc17 | 1 | 9 | 10.70.4.26 | 10.70.68.26 | 10.81.4.26 | 10.82.4.26 |
| s04-pc18 | 2 | 9 | 10.70.4.27 | 10.70.68.27 | 10.81.4.27 | 10.82.4.27 |
| s04-pc19 | 1 | 10 | 10.70.4.28 | 10.70.68.28 | 10.81.4.28 | 10.82.4.28 |
| s04-pc20 | 2 | 10 | 10.70.4.29 | 10.70.68.29 | 10.81.4.29 | 10.82.4.29 |
| s04-pc21 | 1 | 11 | 10.70.4.30 | 10.70.68.30 | 10.81.4.30 | 10.82.4.30 |
| s04-pc22 | 2 | 11 | 10.70.4.31 | 10.70.68.31 | 10.81.4.31 | 10.82.4.31 |
| s04-pc23 | 1 | 12 | 10.70.4.32 | 10.70.68.32 | 10.81.4.32 | 10.82.4.32 |
| s04-pc24 | 2 | 12 | 10.70.4.33 | 10.70.68.33 | 10.81.4.33 | 10.82.4.33 |
| s04-pc25 | 1 | 13 | 10.70.4.34 | 10.70.68.34 | 10.81.4.34 | 10.82.4.34 |
| s04-pc26 | 2 | 13 | 10.70.4.35 | 10.70.68.35 | 10.81.4.35 | 10.82.4.35 |
| s04-pc27 | 1 | 14 | 10.70.4.36 | 10.70.68.36 | 10.81.4.36 | 10.82.4.36 |
| s04-pc28 | 2 | 14 | 10.70.4.37 | 10.70.68.37 | 10.81.4.37 | 10.82.4.37 |
| s04-pc29 | 1 | 15 | 10.70.4.38 | 10.70.68.38 | 10.81.4.38 | 10.82.4.38 |
| s04-pc30 | 2 | 15 | 10.70.4.39 | 10.70.68.39 | 10.81.4.39 | 10.82.4.39 |


**Transporte starlink — VLAN 201 — wanA.**

| Rol de entrega | Dirección |
| --- | --- |
| network | 10.252.4.0/29 |
| cpe | 10.252.4.1 |
| r1 | 10.252.4.2 |
| r2 | 10.252.4.3 |


**Transporte leo — VLAN 202 — wanB.**

| Rol de entrega | Dirección |
| --- | --- |
| network | 10.252.4.8/29 |
| cpe | 10.252.4.9 |
| r1 | 10.252.4.10 |
| r2 | 10.252.4.11 |


**Transporte entel5g — VLAN 203 — wanA.**

| Rol de entrega | Dirección |
| --- | --- |
| network | 10.252.4.16/29 |
| cpe | 10.252.4.17 |
| r1 | 10.252.4.18 |
| r2 | 10.252.4.19 |


**Transporte wom4g — VLAN 204 — wanB.**

| Rol de entrega | Dirección |
| --- | --- |
| network | 10.252.4.24/29 |
| cpe | 10.252.4.25 |
| r1 | 10.252.4.26 |
| r2 | 10.252.4.27 |


**Reservas de túneles (numeración según lista de la ficha).**

| Rol / candidato | Dirección |
| --- | --- |
| .1.hub_public_ip | 198.51.100.4 |
| .1.network | 10.253.4.0/30 |
| .1.branch_ip | 10.253.4.1 |
| .1.hub_ip | 10.253.4.2 |
| .2.hub_public_ip | 203.0.113.4 |
| .2.network | 10.253.4.4/30 |
| .2.branch_ip | 10.253.4.5 |
| .2.hub_ip | 10.253.4.6 |
| .3.hub_public_ip | 198.51.100.4 |
| .3.network | 10.253.4.8/30 |
| .3.branch_ip | 10.253.4.9 |
| .3.hub_ip | 10.253.4.10 |
| .4.hub_public_ip | 203.0.113.4 |
| .4.network | 10.253.4.12/30 |
| .4.branch_ip | 10.253.4.13 |
| .4.hub_ip | 10.253.4.14 |
| .5.hub_public_ip | 198.51.100.4 |
| .5.network | 10.253.4.16/30 |
| .5.branch_ip | 10.253.4.17 |
| .5.hub_ip | 10.253.4.18 |
| .6.hub_public_ip | 203.0.113.4 |
| .6.network | 10.253.4.20/30 |
| .6.branch_ip | 10.253.4.21 |
| .6.hub_ip | 10.253.4.22 |
| .7.hub_public_ip | 198.51.100.4 |
| .7.network | 10.253.4.24/30 |
| .7.branch_ip | 10.253.4.25 |
| .7.hub_ip | 10.253.4.26 |
| .8.hub_public_ip | 203.0.113.4 |
| .8.network | 10.253.4.28/30 |
| .8.branch_ip | 10.253.4.29 |
| .8.hub_ip | 10.253.4.30 |
| .9.hub_public_ip | 198.51.100.4 |
| .9.network | 10.253.4.32/30 |
| .9.branch_ip | 10.253.4.33 |
| .9.hub_ip | 10.253.4.34 |
| .10.hub_public_ip | 203.0.113.4 |
| .10.network | 10.253.4.36/30 |
| .10.branch_ip | 10.253.4.37 |
| .10.hub_ip | 10.253.4.38 |
| .11.hub_public_ip | 198.51.100.4 |
| .11.network | 10.253.4.40/30 |
| .11.branch_ip | 10.253.4.41 |
| .11.hub_ip | 10.253.4.42 |
| .12.hub_public_ip | 203.0.113.4 |
| .12.network | 10.253.4.44/30 |
| .12.branch_ip | 10.253.4.45 |
| .12.hub_ip | 10.253.4.46 |
| .13.hub_public_ip | 198.51.100.4 |
| .13.network | 10.253.4.48/30 |
| .13.branch_ip | 10.253.4.49 |
| .13.hub_ip | 10.253.4.50 |
| .14.hub_public_ip | 203.0.113.4 |
| .14.network | 10.253.4.52/30 |
| .14.branch_ip | 10.253.4.53 |
| .14.hub_ip | 10.253.4.54 |
| .15.hub_public_ip | 198.51.100.4 |
| .15.network | 10.253.4.56/30 |
| .15.branch_ip | 10.253.4.57 |
| .15.hub_ip | 10.253.4.58 |
| .16.hub_public_ip | 203.0.113.4 |
| .16.network | 10.253.4.60/30 |
| .16.branch_ip | 10.253.4.61 |
| .16.hub_ip | 10.253.4.62 |

### S05 — La Florida

30 PCs y 30 teléfonos existentes.

| Función | ANTES | DESPUÉS |
| --- | --- | --- |
| Routers | 1 × ISR4321/K9 | 2 × CCR2004-16G-2S+ |
| Switches | 1 × C9200L-48P-4G-E | CRS328-24P-4S+RM + CRS328-24P-4S+RM |
| Firewall | Sin equipo dedicado | Sin appliance remoto; seguridad central |
| Distribución WAN | MPLS y accesos ISP del escenario base | wanA: E50UG; wanB: E50UG |


| Red | VLAN | Subred | Gateway / roles |
| --- | --- | --- | --- |
| users | 10 | 10.70.5.0/25 | 10.70.5.1 |
| voice | 20 | 10.70.69.0/25 | 10.70.69.1 |
| guests | 40 | 10.70.101.0/26 | 10.70.101.1 |
| wifi_users | 110 | 10.81.5.0/25 | 10.81.5.1 |
| wifi_voice | 120 | 10.82.5.0/25 | 10.82.5.1 |
| management | 130 | 10.80.5.0/27 | 10.80.5.1 |


| Gestión | Dirección |
| --- | --- |
| sw1 | 10.80.5.2 |
| sw2 | 10.80.5.3 |
| r1 | 10.80.5.4 |
| r2 | 10.80.5.5 |
| wanA | 10.80.5.6 |
| wanB | 10.80.5.7 |
| ap1 | 10.80.5.24 |
| ap2 | 10.80.5.25 |


| Origen | Puerto | Destino | Puerto | Función | VLAN/red | Mbps | IP / agregado lógico |
| --- | --- | --- | --- | --- | --- | --- | --- |
| cpe:starlink | LAN | wanA | ether1 | WAN_ACCESS | 201 | 1000 | — |
| cpe:entel5g | LAN | wanA | ether2 | WAN_ACCESS | 203 | 1000 | — |
| r1 | ether1 | wanA | ether3 | WAN_TRUNK | 201, 203 | 1000 | — |
| r2 | ether1 | wanA | ether4 | WAN_TRUNK | 201, 203 | 1000 | — |
| wanA | ether5 | sw1 | ether22 | MANAGEMENT_ACCESS | 130 | 1000 | — |
| cpe:leo | LAN | wanB | ether1 | WAN_ACCESS | 202 | 1000 | — |
| cpe:wom4g | LAN | wanB | ether2 | WAN_ACCESS | 204 | 1000 | — |
| r1 | ether2 | wanB | ether3 | WAN_TRUNK | 202, 204 | 1000 | — |
| r2 | ether2 | wanB | ether4 | WAN_TRUNK | 202, 204 | 1000 | — |
| wanB | ether5 | sw2 | ether22 | MANAGEMENT_ACCESS | 130 | 1000 | — |
| r1 | ether3 | sw1 | ether19 | LAN_ROUTED | 172.31.5.0/30 | 1000 | router_ip: 172.31.5.1; stack_ip: 172.31.5.2 |
| r1 | ether4 | sw2 | ether19 | LAN_ROUTED | 172.31.5.4/30 | 1000 | router_ip: 172.31.5.5; stack_ip: 172.31.5.6 |
| r1 | ether5 | sw1 | ether21 | MANAGEMENT_ACCESS | 130 | 1000 | — |
| r2 | ether3 | sw1 | ether20 | LAN_ROUTED | 172.31.5.8/30 | 1000 | router_ip: 172.31.5.9; stack_ip: 172.31.5.10 |
| r2 | ether4 | sw2 | ether20 | LAN_ROUTED | 172.31.5.12/30 | 1000 | router_ip: 172.31.5.13; stack_ip: 172.31.5.14 |
| r2 | ether5 | sw2 | ether21 | MANAGEMENT_ACCESS | 130 | 1000 | — |
| ap1 | LAN | sw1 | ether24 | AP_TRUNK | 40, 110, 120, 130 | 1000 | — |
| ap2 | LAN | sw2 | ether24 | AP_TRUNK | 40, 110, 120, 130 | 1000 | — |
| sw1 | sfp-sfpplus1 | sw2 | sfp-sfpplus2 | STACK | 10, 20, 40, 110, 120, 130 | 10000 | — |
| sw1 | sfp-sfpplus2 | sw2 | sfp-sfpplus1 | STACK | 10, 20, 40, 110, 120, 130 | 10000 | — |


| Puesto | Switch | Puerto | IP PC | IP teléfono | Reserva Wi-Fi PC | Reserva Wi-Fi voz |
| --- | --- | --- | --- | --- | --- | --- |
| s05-pc01 | 1 | 1 | 10.70.5.10 | 10.70.69.10 | 10.81.5.10 | 10.82.5.10 |
| s05-pc02 | 2 | 1 | 10.70.5.11 | 10.70.69.11 | 10.81.5.11 | 10.82.5.11 |
| s05-pc03 | 1 | 2 | 10.70.5.12 | 10.70.69.12 | 10.81.5.12 | 10.82.5.12 |
| s05-pc04 | 2 | 2 | 10.70.5.13 | 10.70.69.13 | 10.81.5.13 | 10.82.5.13 |
| s05-pc05 | 1 | 3 | 10.70.5.14 | 10.70.69.14 | 10.81.5.14 | 10.82.5.14 |
| s05-pc06 | 2 | 3 | 10.70.5.15 | 10.70.69.15 | 10.81.5.15 | 10.82.5.15 |
| s05-pc07 | 1 | 4 | 10.70.5.16 | 10.70.69.16 | 10.81.5.16 | 10.82.5.16 |
| s05-pc08 | 2 | 4 | 10.70.5.17 | 10.70.69.17 | 10.81.5.17 | 10.82.5.17 |
| s05-pc09 | 1 | 5 | 10.70.5.18 | 10.70.69.18 | 10.81.5.18 | 10.82.5.18 |
| s05-pc10 | 2 | 5 | 10.70.5.19 | 10.70.69.19 | 10.81.5.19 | 10.82.5.19 |
| s05-pc11 | 1 | 6 | 10.70.5.20 | 10.70.69.20 | 10.81.5.20 | 10.82.5.20 |
| s05-pc12 | 2 | 6 | 10.70.5.21 | 10.70.69.21 | 10.81.5.21 | 10.82.5.21 |
| s05-pc13 | 1 | 7 | 10.70.5.22 | 10.70.69.22 | 10.81.5.22 | 10.82.5.22 |
| s05-pc14 | 2 | 7 | 10.70.5.23 | 10.70.69.23 | 10.81.5.23 | 10.82.5.23 |
| s05-pc15 | 1 | 8 | 10.70.5.24 | 10.70.69.24 | 10.81.5.24 | 10.82.5.24 |
| s05-pc16 | 2 | 8 | 10.70.5.25 | 10.70.69.25 | 10.81.5.25 | 10.82.5.25 |
| s05-pc17 | 1 | 9 | 10.70.5.26 | 10.70.69.26 | 10.81.5.26 | 10.82.5.26 |
| s05-pc18 | 2 | 9 | 10.70.5.27 | 10.70.69.27 | 10.81.5.27 | 10.82.5.27 |
| s05-pc19 | 1 | 10 | 10.70.5.28 | 10.70.69.28 | 10.81.5.28 | 10.82.5.28 |
| s05-pc20 | 2 | 10 | 10.70.5.29 | 10.70.69.29 | 10.81.5.29 | 10.82.5.29 |
| s05-pc21 | 1 | 11 | 10.70.5.30 | 10.70.69.30 | 10.81.5.30 | 10.82.5.30 |
| s05-pc22 | 2 | 11 | 10.70.5.31 | 10.70.69.31 | 10.81.5.31 | 10.82.5.31 |
| s05-pc23 | 1 | 12 | 10.70.5.32 | 10.70.69.32 | 10.81.5.32 | 10.82.5.32 |
| s05-pc24 | 2 | 12 | 10.70.5.33 | 10.70.69.33 | 10.81.5.33 | 10.82.5.33 |
| s05-pc25 | 1 | 13 | 10.70.5.34 | 10.70.69.34 | 10.81.5.34 | 10.82.5.34 |
| s05-pc26 | 2 | 13 | 10.70.5.35 | 10.70.69.35 | 10.81.5.35 | 10.82.5.35 |
| s05-pc27 | 1 | 14 | 10.70.5.36 | 10.70.69.36 | 10.81.5.36 | 10.82.5.36 |
| s05-pc28 | 2 | 14 | 10.70.5.37 | 10.70.69.37 | 10.81.5.37 | 10.82.5.37 |
| s05-pc29 | 1 | 15 | 10.70.5.38 | 10.70.69.38 | 10.81.5.38 | 10.82.5.38 |
| s05-pc30 | 2 | 15 | 10.70.5.39 | 10.70.69.39 | 10.81.5.39 | 10.82.5.39 |


**Transporte starlink — VLAN 201 — wanA.**

| Rol de entrega | Dirección |
| --- | --- |
| network | 10.252.5.0/29 |
| cpe | 10.252.5.1 |
| r1 | 10.252.5.2 |
| r2 | 10.252.5.3 |


**Transporte leo — VLAN 202 — wanB.**

| Rol de entrega | Dirección |
| --- | --- |
| network | 10.252.5.8/29 |
| cpe | 10.252.5.9 |
| r1 | 10.252.5.10 |
| r2 | 10.252.5.11 |


**Transporte entel5g — VLAN 203 — wanA.**

| Rol de entrega | Dirección |
| --- | --- |
| network | 10.252.5.16/29 |
| cpe | 10.252.5.17 |
| r1 | 10.252.5.18 |
| r2 | 10.252.5.19 |


**Transporte wom4g — VLAN 204 — wanB.**

| Rol de entrega | Dirección |
| --- | --- |
| network | 10.252.5.24/29 |
| cpe | 10.252.5.25 |
| r1 | 10.252.5.26 |
| r2 | 10.252.5.27 |


**Reservas de túneles (numeración según lista de la ficha).**

| Rol / candidato | Dirección |
| --- | --- |
| .1.hub_public_ip | 198.51.100.4 |
| .1.network | 10.253.5.0/30 |
| .1.branch_ip | 10.253.5.1 |
| .1.hub_ip | 10.253.5.2 |
| .2.hub_public_ip | 203.0.113.4 |
| .2.network | 10.253.5.4/30 |
| .2.branch_ip | 10.253.5.5 |
| .2.hub_ip | 10.253.5.6 |
| .3.hub_public_ip | 198.51.100.4 |
| .3.network | 10.253.5.8/30 |
| .3.branch_ip | 10.253.5.9 |
| .3.hub_ip | 10.253.5.10 |
| .4.hub_public_ip | 203.0.113.4 |
| .4.network | 10.253.5.12/30 |
| .4.branch_ip | 10.253.5.13 |
| .4.hub_ip | 10.253.5.14 |
| .5.hub_public_ip | 198.51.100.4 |
| .5.network | 10.253.5.16/30 |
| .5.branch_ip | 10.253.5.17 |
| .5.hub_ip | 10.253.5.18 |
| .6.hub_public_ip | 203.0.113.4 |
| .6.network | 10.253.5.20/30 |
| .6.branch_ip | 10.253.5.21 |
| .6.hub_ip | 10.253.5.22 |
| .7.hub_public_ip | 198.51.100.4 |
| .7.network | 10.253.5.24/30 |
| .7.branch_ip | 10.253.5.25 |
| .7.hub_ip | 10.253.5.26 |
| .8.hub_public_ip | 203.0.113.4 |
| .8.network | 10.253.5.28/30 |
| .8.branch_ip | 10.253.5.29 |
| .8.hub_ip | 10.253.5.30 |
| .9.hub_public_ip | 198.51.100.4 |
| .9.network | 10.253.5.32/30 |
| .9.branch_ip | 10.253.5.33 |
| .9.hub_ip | 10.253.5.34 |
| .10.hub_public_ip | 203.0.113.4 |
| .10.network | 10.253.5.36/30 |
| .10.branch_ip | 10.253.5.37 |
| .10.hub_ip | 10.253.5.38 |
| .11.hub_public_ip | 198.51.100.4 |
| .11.network | 10.253.5.40/30 |
| .11.branch_ip | 10.253.5.41 |
| .11.hub_ip | 10.253.5.42 |
| .12.hub_public_ip | 203.0.113.4 |
| .12.network | 10.253.5.44/30 |
| .12.branch_ip | 10.253.5.45 |
| .12.hub_ip | 10.253.5.46 |
| .13.hub_public_ip | 198.51.100.4 |
| .13.network | 10.253.5.48/30 |
| .13.branch_ip | 10.253.5.49 |
| .13.hub_ip | 10.253.5.50 |
| .14.hub_public_ip | 203.0.113.4 |
| .14.network | 10.253.5.52/30 |
| .14.branch_ip | 10.253.5.53 |
| .14.hub_ip | 10.253.5.54 |
| .15.hub_public_ip | 198.51.100.4 |
| .15.network | 10.253.5.56/30 |
| .15.branch_ip | 10.253.5.57 |
| .15.hub_ip | 10.253.5.58 |
| .16.hub_public_ip | 203.0.113.4 |
| .16.network | 10.253.5.60/30 |
| .16.branch_ip | 10.253.5.61 |
| .16.hub_ip | 10.253.5.62 |

### S06 — Arica

28 PCs y 28 teléfonos existentes.

| Función | ANTES | DESPUÉS |
| --- | --- | --- |
| Routers | 1 × ISR4321/K9 | 2 × CCR2004-16G-2S+ |
| Switches | 1 × C9200L-48P-4G-E | CRS328-24P-4S+RM + CRS328-24P-4S+RM |
| Firewall | Sin equipo dedicado | Sin appliance remoto; seguridad central |
| Distribución WAN | MPLS y accesos ISP del escenario base | wanA: E50UG; wanB: E50UG |


| Red | VLAN | Subred | Gateway / roles |
| --- | --- | --- | --- |
| users | 10 | 10.70.6.0/25 | 10.70.6.1 |
| voice | 20 | 10.70.70.0/25 | 10.70.70.1 |
| guests | 40 | 10.70.102.0/26 | 10.70.102.1 |
| wifi_users | 110 | 10.81.6.0/25 | 10.81.6.1 |
| wifi_voice | 120 | 10.82.6.0/25 | 10.82.6.1 |
| management | 130 | 10.80.6.0/27 | 10.80.6.1 |


| Gestión | Dirección |
| --- | --- |
| sw1 | 10.80.6.2 |
| sw2 | 10.80.6.3 |
| r1 | 10.80.6.4 |
| r2 | 10.80.6.5 |
| wanA | 10.80.6.6 |
| wanB | 10.80.6.7 |
| ap1 | 10.80.6.24 |
| ap2 | 10.80.6.25 |


| Origen | Puerto | Destino | Puerto | Función | VLAN/red | Mbps | IP / agregado lógico |
| --- | --- | --- | --- | --- | --- | --- | --- |
| cpe:starlink | LAN | wanA | ether1 | WAN_ACCESS | 201 | 1000 | — |
| cpe:entel5g | LAN | wanA | ether2 | WAN_ACCESS | 203 | 1000 | — |
| r1 | ether1 | wanA | ether3 | WAN_TRUNK | 201, 203 | 1000 | — |
| r2 | ether1 | wanA | ether4 | WAN_TRUNK | 201, 203 | 1000 | — |
| wanA | ether5 | sw1 | ether22 | MANAGEMENT_ACCESS | 130 | 1000 | — |
| cpe:leo | LAN | wanB | ether1 | WAN_ACCESS | 202 | 1000 | — |
| cpe:wom4g | LAN | wanB | ether2 | WAN_ACCESS | 204 | 1000 | — |
| r1 | ether2 | wanB | ether3 | WAN_TRUNK | 202, 204 | 1000 | — |
| r2 | ether2 | wanB | ether4 | WAN_TRUNK | 202, 204 | 1000 | — |
| wanB | ether5 | sw2 | ether22 | MANAGEMENT_ACCESS | 130 | 1000 | — |
| r1 | ether3 | sw1 | ether19 | LAN_ROUTED | 172.31.6.0/30 | 1000 | router_ip: 172.31.6.1; stack_ip: 172.31.6.2 |
| r1 | ether4 | sw2 | ether19 | LAN_ROUTED | 172.31.6.4/30 | 1000 | router_ip: 172.31.6.5; stack_ip: 172.31.6.6 |
| r1 | ether5 | sw1 | ether21 | MANAGEMENT_ACCESS | 130 | 1000 | — |
| r2 | ether3 | sw1 | ether20 | LAN_ROUTED | 172.31.6.8/30 | 1000 | router_ip: 172.31.6.9; stack_ip: 172.31.6.10 |
| r2 | ether4 | sw2 | ether20 | LAN_ROUTED | 172.31.6.12/30 | 1000 | router_ip: 172.31.6.13; stack_ip: 172.31.6.14 |
| r2 | ether5 | sw2 | ether21 | MANAGEMENT_ACCESS | 130 | 1000 | — |
| ap1 | LAN | sw1 | ether24 | AP_TRUNK | 40, 110, 120, 130 | 1000 | — |
| ap2 | LAN | sw2 | ether24 | AP_TRUNK | 40, 110, 120, 130 | 1000 | — |
| sw1 | sfp-sfpplus1 | sw2 | sfp-sfpplus2 | STACK | 10, 20, 40, 110, 120, 130 | 10000 | — |
| sw1 | sfp-sfpplus2 | sw2 | sfp-sfpplus1 | STACK | 10, 20, 40, 110, 120, 130 | 10000 | — |


| Puesto | Switch | Puerto | IP PC | IP teléfono | Reserva Wi-Fi PC | Reserva Wi-Fi voz |
| --- | --- | --- | --- | --- | --- | --- |
| s06-pc01 | 1 | 1 | 10.70.6.10 | 10.70.70.10 | 10.81.6.10 | 10.82.6.10 |
| s06-pc02 | 2 | 1 | 10.70.6.11 | 10.70.70.11 | 10.81.6.11 | 10.82.6.11 |
| s06-pc03 | 1 | 2 | 10.70.6.12 | 10.70.70.12 | 10.81.6.12 | 10.82.6.12 |
| s06-pc04 | 2 | 2 | 10.70.6.13 | 10.70.70.13 | 10.81.6.13 | 10.82.6.13 |
| s06-pc05 | 1 | 3 | 10.70.6.14 | 10.70.70.14 | 10.81.6.14 | 10.82.6.14 |
| s06-pc06 | 2 | 3 | 10.70.6.15 | 10.70.70.15 | 10.81.6.15 | 10.82.6.15 |
| s06-pc07 | 1 | 4 | 10.70.6.16 | 10.70.70.16 | 10.81.6.16 | 10.82.6.16 |
| s06-pc08 | 2 | 4 | 10.70.6.17 | 10.70.70.17 | 10.81.6.17 | 10.82.6.17 |
| s06-pc09 | 1 | 5 | 10.70.6.18 | 10.70.70.18 | 10.81.6.18 | 10.82.6.18 |
| s06-pc10 | 2 | 5 | 10.70.6.19 | 10.70.70.19 | 10.81.6.19 | 10.82.6.19 |
| s06-pc11 | 1 | 6 | 10.70.6.20 | 10.70.70.20 | 10.81.6.20 | 10.82.6.20 |
| s06-pc12 | 2 | 6 | 10.70.6.21 | 10.70.70.21 | 10.81.6.21 | 10.82.6.21 |
| s06-pc13 | 1 | 7 | 10.70.6.22 | 10.70.70.22 | 10.81.6.22 | 10.82.6.22 |
| s06-pc14 | 2 | 7 | 10.70.6.23 | 10.70.70.23 | 10.81.6.23 | 10.82.6.23 |
| s06-pc15 | 1 | 8 | 10.70.6.24 | 10.70.70.24 | 10.81.6.24 | 10.82.6.24 |
| s06-pc16 | 2 | 8 | 10.70.6.25 | 10.70.70.25 | 10.81.6.25 | 10.82.6.25 |
| s06-pc17 | 1 | 9 | 10.70.6.26 | 10.70.70.26 | 10.81.6.26 | 10.82.6.26 |
| s06-pc18 | 2 | 9 | 10.70.6.27 | 10.70.70.27 | 10.81.6.27 | 10.82.6.27 |
| s06-pc19 | 1 | 10 | 10.70.6.28 | 10.70.70.28 | 10.81.6.28 | 10.82.6.28 |
| s06-pc20 | 2 | 10 | 10.70.6.29 | 10.70.70.29 | 10.81.6.29 | 10.82.6.29 |
| s06-pc21 | 1 | 11 | 10.70.6.30 | 10.70.70.30 | 10.81.6.30 | 10.82.6.30 |
| s06-pc22 | 2 | 11 | 10.70.6.31 | 10.70.70.31 | 10.81.6.31 | 10.82.6.31 |
| s06-pc23 | 1 | 12 | 10.70.6.32 | 10.70.70.32 | 10.81.6.32 | 10.82.6.32 |
| s06-pc24 | 2 | 12 | 10.70.6.33 | 10.70.70.33 | 10.81.6.33 | 10.82.6.33 |
| s06-pc25 | 1 | 13 | 10.70.6.34 | 10.70.70.34 | 10.81.6.34 | 10.82.6.34 |
| s06-pc26 | 2 | 13 | 10.70.6.35 | 10.70.70.35 | 10.81.6.35 | 10.82.6.35 |
| s06-pc27 | 1 | 14 | 10.70.6.36 | 10.70.70.36 | 10.81.6.36 | 10.82.6.36 |
| s06-pc28 | 2 | 14 | 10.70.6.37 | 10.70.70.37 | 10.81.6.37 | 10.82.6.37 |


**Transporte starlink — VLAN 201 — wanA.**

| Rol de entrega | Dirección |
| --- | --- |
| network | 10.252.6.0/29 |
| cpe | 10.252.6.1 |
| r1 | 10.252.6.2 |
| r2 | 10.252.6.3 |


**Transporte leo — VLAN 202 — wanB.**

| Rol de entrega | Dirección |
| --- | --- |
| network | 10.252.6.8/29 |
| cpe | 10.252.6.9 |
| r1 | 10.252.6.10 |
| r2 | 10.252.6.11 |


**Transporte entel5g — VLAN 203 — wanA.**

| Rol de entrega | Dirección |
| --- | --- |
| network | 10.252.6.16/29 |
| cpe | 10.252.6.17 |
| r1 | 10.252.6.18 |
| r2 | 10.252.6.19 |


**Transporte wom4g — VLAN 204 — wanB.**

| Rol de entrega | Dirección |
| --- | --- |
| network | 10.252.6.24/29 |
| cpe | 10.252.6.25 |
| r1 | 10.252.6.26 |
| r2 | 10.252.6.27 |


**Reservas de túneles (numeración según lista de la ficha).**

| Rol / candidato | Dirección |
| --- | --- |
| .1.hub_public_ip | 198.51.100.4 |
| .1.network | 10.253.6.0/30 |
| .1.branch_ip | 10.253.6.1 |
| .1.hub_ip | 10.253.6.2 |
| .2.hub_public_ip | 203.0.113.4 |
| .2.network | 10.253.6.4/30 |
| .2.branch_ip | 10.253.6.5 |
| .2.hub_ip | 10.253.6.6 |
| .3.hub_public_ip | 198.51.100.4 |
| .3.network | 10.253.6.8/30 |
| .3.branch_ip | 10.253.6.9 |
| .3.hub_ip | 10.253.6.10 |
| .4.hub_public_ip | 203.0.113.4 |
| .4.network | 10.253.6.12/30 |
| .4.branch_ip | 10.253.6.13 |
| .4.hub_ip | 10.253.6.14 |
| .5.hub_public_ip | 198.51.100.4 |
| .5.network | 10.253.6.16/30 |
| .5.branch_ip | 10.253.6.17 |
| .5.hub_ip | 10.253.6.18 |
| .6.hub_public_ip | 203.0.113.4 |
| .6.network | 10.253.6.20/30 |
| .6.branch_ip | 10.253.6.21 |
| .6.hub_ip | 10.253.6.22 |
| .7.hub_public_ip | 198.51.100.4 |
| .7.network | 10.253.6.24/30 |
| .7.branch_ip | 10.253.6.25 |
| .7.hub_ip | 10.253.6.26 |
| .8.hub_public_ip | 203.0.113.4 |
| .8.network | 10.253.6.28/30 |
| .8.branch_ip | 10.253.6.29 |
| .8.hub_ip | 10.253.6.30 |
| .9.hub_public_ip | 198.51.100.4 |
| .9.network | 10.253.6.32/30 |
| .9.branch_ip | 10.253.6.33 |
| .9.hub_ip | 10.253.6.34 |
| .10.hub_public_ip | 203.0.113.4 |
| .10.network | 10.253.6.36/30 |
| .10.branch_ip | 10.253.6.37 |
| .10.hub_ip | 10.253.6.38 |
| .11.hub_public_ip | 198.51.100.4 |
| .11.network | 10.253.6.40/30 |
| .11.branch_ip | 10.253.6.41 |
| .11.hub_ip | 10.253.6.42 |
| .12.hub_public_ip | 203.0.113.4 |
| .12.network | 10.253.6.44/30 |
| .12.branch_ip | 10.253.6.45 |
| .12.hub_ip | 10.253.6.46 |
| .13.hub_public_ip | 198.51.100.4 |
| .13.network | 10.253.6.48/30 |
| .13.branch_ip | 10.253.6.49 |
| .13.hub_ip | 10.253.6.50 |
| .14.hub_public_ip | 203.0.113.4 |
| .14.network | 10.253.6.52/30 |
| .14.branch_ip | 10.253.6.53 |
| .14.hub_ip | 10.253.6.54 |
| .15.hub_public_ip | 198.51.100.4 |
| .15.network | 10.253.6.56/30 |
| .15.branch_ip | 10.253.6.57 |
| .15.hub_ip | 10.253.6.58 |
| .16.hub_public_ip | 203.0.113.4 |
| .16.network | 10.253.6.60/30 |
| .16.branch_ip | 10.253.6.61 |
| .16.hub_ip | 10.253.6.62 |

### S07 — Iquique

28 PCs y 28 teléfonos existentes.

| Función | ANTES | DESPUÉS |
| --- | --- | --- |
| Routers | 1 × ISR4321/K9 | 2 × CCR2004-16G-2S+ |
| Switches | 1 × C9200L-48P-4G-E | CRS328-24P-4S+RM + CRS328-24P-4S+RM |
| Firewall | Sin equipo dedicado | Sin appliance remoto; seguridad central |
| Distribución WAN | MPLS y accesos ISP del escenario base | wanA: E50UG; wanB: E50UG |


| Red | VLAN | Subred | Gateway / roles |
| --- | --- | --- | --- |
| users | 10 | 10.70.7.0/25 | 10.70.7.1 |
| voice | 20 | 10.70.71.0/25 | 10.70.71.1 |
| guests | 40 | 10.70.103.0/26 | 10.70.103.1 |
| wifi_users | 110 | 10.81.7.0/25 | 10.81.7.1 |
| wifi_voice | 120 | 10.82.7.0/25 | 10.82.7.1 |
| management | 130 | 10.80.7.0/27 | 10.80.7.1 |


| Gestión | Dirección |
| --- | --- |
| sw1 | 10.80.7.2 |
| sw2 | 10.80.7.3 |
| r1 | 10.80.7.4 |
| r2 | 10.80.7.5 |
| wanA | 10.80.7.6 |
| wanB | 10.80.7.7 |
| ap1 | 10.80.7.24 |
| ap2 | 10.80.7.25 |


| Origen | Puerto | Destino | Puerto | Función | VLAN/red | Mbps | IP / agregado lógico |
| --- | --- | --- | --- | --- | --- | --- | --- |
| cpe:starlink | LAN | wanA | ether1 | WAN_ACCESS | 201 | 1000 | — |
| cpe:entel5g | LAN | wanA | ether2 | WAN_ACCESS | 203 | 1000 | — |
| r1 | ether1 | wanA | ether3 | WAN_TRUNK | 201, 203 | 1000 | — |
| r2 | ether1 | wanA | ether4 | WAN_TRUNK | 201, 203 | 1000 | — |
| wanA | ether5 | sw1 | ether22 | MANAGEMENT_ACCESS | 130 | 1000 | — |
| cpe:leo | LAN | wanB | ether1 | WAN_ACCESS | 202 | 1000 | — |
| cpe:wom4g | LAN | wanB | ether2 | WAN_ACCESS | 204 | 1000 | — |
| r1 | ether2 | wanB | ether3 | WAN_TRUNK | 202, 204 | 1000 | — |
| r2 | ether2 | wanB | ether4 | WAN_TRUNK | 202, 204 | 1000 | — |
| wanB | ether5 | sw2 | ether22 | MANAGEMENT_ACCESS | 130 | 1000 | — |
| r1 | ether3 | sw1 | ether19 | LAN_ROUTED | 172.31.7.0/30 | 1000 | router_ip: 172.31.7.1; stack_ip: 172.31.7.2 |
| r1 | ether4 | sw2 | ether19 | LAN_ROUTED | 172.31.7.4/30 | 1000 | router_ip: 172.31.7.5; stack_ip: 172.31.7.6 |
| r1 | ether5 | sw1 | ether21 | MANAGEMENT_ACCESS | 130 | 1000 | — |
| r2 | ether3 | sw1 | ether20 | LAN_ROUTED | 172.31.7.8/30 | 1000 | router_ip: 172.31.7.9; stack_ip: 172.31.7.10 |
| r2 | ether4 | sw2 | ether20 | LAN_ROUTED | 172.31.7.12/30 | 1000 | router_ip: 172.31.7.13; stack_ip: 172.31.7.14 |
| r2 | ether5 | sw2 | ether21 | MANAGEMENT_ACCESS | 130 | 1000 | — |
| ap1 | LAN | sw1 | ether24 | AP_TRUNK | 40, 110, 120, 130 | 1000 | — |
| ap2 | LAN | sw2 | ether24 | AP_TRUNK | 40, 110, 120, 130 | 1000 | — |
| sw1 | sfp-sfpplus1 | sw2 | sfp-sfpplus2 | STACK | 10, 20, 40, 110, 120, 130 | 10000 | — |
| sw1 | sfp-sfpplus2 | sw2 | sfp-sfpplus1 | STACK | 10, 20, 40, 110, 120, 130 | 10000 | — |


| Puesto | Switch | Puerto | IP PC | IP teléfono | Reserva Wi-Fi PC | Reserva Wi-Fi voz |
| --- | --- | --- | --- | --- | --- | --- |
| s07-pc01 | 1 | 1 | 10.70.7.10 | 10.70.71.10 | 10.81.7.10 | 10.82.7.10 |
| s07-pc02 | 2 | 1 | 10.70.7.11 | 10.70.71.11 | 10.81.7.11 | 10.82.7.11 |
| s07-pc03 | 1 | 2 | 10.70.7.12 | 10.70.71.12 | 10.81.7.12 | 10.82.7.12 |
| s07-pc04 | 2 | 2 | 10.70.7.13 | 10.70.71.13 | 10.81.7.13 | 10.82.7.13 |
| s07-pc05 | 1 | 3 | 10.70.7.14 | 10.70.71.14 | 10.81.7.14 | 10.82.7.14 |
| s07-pc06 | 2 | 3 | 10.70.7.15 | 10.70.71.15 | 10.81.7.15 | 10.82.7.15 |
| s07-pc07 | 1 | 4 | 10.70.7.16 | 10.70.71.16 | 10.81.7.16 | 10.82.7.16 |
| s07-pc08 | 2 | 4 | 10.70.7.17 | 10.70.71.17 | 10.81.7.17 | 10.82.7.17 |
| s07-pc09 | 1 | 5 | 10.70.7.18 | 10.70.71.18 | 10.81.7.18 | 10.82.7.18 |
| s07-pc10 | 2 | 5 | 10.70.7.19 | 10.70.71.19 | 10.81.7.19 | 10.82.7.19 |
| s07-pc11 | 1 | 6 | 10.70.7.20 | 10.70.71.20 | 10.81.7.20 | 10.82.7.20 |
| s07-pc12 | 2 | 6 | 10.70.7.21 | 10.70.71.21 | 10.81.7.21 | 10.82.7.21 |
| s07-pc13 | 1 | 7 | 10.70.7.22 | 10.70.71.22 | 10.81.7.22 | 10.82.7.22 |
| s07-pc14 | 2 | 7 | 10.70.7.23 | 10.70.71.23 | 10.81.7.23 | 10.82.7.23 |
| s07-pc15 | 1 | 8 | 10.70.7.24 | 10.70.71.24 | 10.81.7.24 | 10.82.7.24 |
| s07-pc16 | 2 | 8 | 10.70.7.25 | 10.70.71.25 | 10.81.7.25 | 10.82.7.25 |
| s07-pc17 | 1 | 9 | 10.70.7.26 | 10.70.71.26 | 10.81.7.26 | 10.82.7.26 |
| s07-pc18 | 2 | 9 | 10.70.7.27 | 10.70.71.27 | 10.81.7.27 | 10.82.7.27 |
| s07-pc19 | 1 | 10 | 10.70.7.28 | 10.70.71.28 | 10.81.7.28 | 10.82.7.28 |
| s07-pc20 | 2 | 10 | 10.70.7.29 | 10.70.71.29 | 10.81.7.29 | 10.82.7.29 |
| s07-pc21 | 1 | 11 | 10.70.7.30 | 10.70.71.30 | 10.81.7.30 | 10.82.7.30 |
| s07-pc22 | 2 | 11 | 10.70.7.31 | 10.70.71.31 | 10.81.7.31 | 10.82.7.31 |
| s07-pc23 | 1 | 12 | 10.70.7.32 | 10.70.71.32 | 10.81.7.32 | 10.82.7.32 |
| s07-pc24 | 2 | 12 | 10.70.7.33 | 10.70.71.33 | 10.81.7.33 | 10.82.7.33 |
| s07-pc25 | 1 | 13 | 10.70.7.34 | 10.70.71.34 | 10.81.7.34 | 10.82.7.34 |
| s07-pc26 | 2 | 13 | 10.70.7.35 | 10.70.71.35 | 10.81.7.35 | 10.82.7.35 |
| s07-pc27 | 1 | 14 | 10.70.7.36 | 10.70.71.36 | 10.81.7.36 | 10.82.7.36 |
| s07-pc28 | 2 | 14 | 10.70.7.37 | 10.70.71.37 | 10.81.7.37 | 10.82.7.37 |


**Transporte starlink — VLAN 201 — wanA.**

| Rol de entrega | Dirección |
| --- | --- |
| network | 10.252.7.0/29 |
| cpe | 10.252.7.1 |
| r1 | 10.252.7.2 |
| r2 | 10.252.7.3 |


**Transporte leo — VLAN 202 — wanB.**

| Rol de entrega | Dirección |
| --- | --- |
| network | 10.252.7.8/29 |
| cpe | 10.252.7.9 |
| r1 | 10.252.7.10 |
| r2 | 10.252.7.11 |


**Transporte entel5g — VLAN 203 — wanA.**

| Rol de entrega | Dirección |
| --- | --- |
| network | 10.252.7.16/29 |
| cpe | 10.252.7.17 |
| r1 | 10.252.7.18 |
| r2 | 10.252.7.19 |


**Transporte wom4g — VLAN 204 — wanB.**

| Rol de entrega | Dirección |
| --- | --- |
| network | 10.252.7.24/29 |
| cpe | 10.252.7.25 |
| r1 | 10.252.7.26 |
| r2 | 10.252.7.27 |


**Reservas de túneles (numeración según lista de la ficha).**

| Rol / candidato | Dirección |
| --- | --- |
| .1.hub_public_ip | 198.51.100.4 |
| .1.network | 10.253.7.0/30 |
| .1.branch_ip | 10.253.7.1 |
| .1.hub_ip | 10.253.7.2 |
| .2.hub_public_ip | 203.0.113.4 |
| .2.network | 10.253.7.4/30 |
| .2.branch_ip | 10.253.7.5 |
| .2.hub_ip | 10.253.7.6 |
| .3.hub_public_ip | 198.51.100.4 |
| .3.network | 10.253.7.8/30 |
| .3.branch_ip | 10.253.7.9 |
| .3.hub_ip | 10.253.7.10 |
| .4.hub_public_ip | 203.0.113.4 |
| .4.network | 10.253.7.12/30 |
| .4.branch_ip | 10.253.7.13 |
| .4.hub_ip | 10.253.7.14 |
| .5.hub_public_ip | 198.51.100.4 |
| .5.network | 10.253.7.16/30 |
| .5.branch_ip | 10.253.7.17 |
| .5.hub_ip | 10.253.7.18 |
| .6.hub_public_ip | 203.0.113.4 |
| .6.network | 10.253.7.20/30 |
| .6.branch_ip | 10.253.7.21 |
| .6.hub_ip | 10.253.7.22 |
| .7.hub_public_ip | 198.51.100.4 |
| .7.network | 10.253.7.24/30 |
| .7.branch_ip | 10.253.7.25 |
| .7.hub_ip | 10.253.7.26 |
| .8.hub_public_ip | 203.0.113.4 |
| .8.network | 10.253.7.28/30 |
| .8.branch_ip | 10.253.7.29 |
| .8.hub_ip | 10.253.7.30 |
| .9.hub_public_ip | 198.51.100.4 |
| .9.network | 10.253.7.32/30 |
| .9.branch_ip | 10.253.7.33 |
| .9.hub_ip | 10.253.7.34 |
| .10.hub_public_ip | 203.0.113.4 |
| .10.network | 10.253.7.36/30 |
| .10.branch_ip | 10.253.7.37 |
| .10.hub_ip | 10.253.7.38 |
| .11.hub_public_ip | 198.51.100.4 |
| .11.network | 10.253.7.40/30 |
| .11.branch_ip | 10.253.7.41 |
| .11.hub_ip | 10.253.7.42 |
| .12.hub_public_ip | 203.0.113.4 |
| .12.network | 10.253.7.44/30 |
| .12.branch_ip | 10.253.7.45 |
| .12.hub_ip | 10.253.7.46 |
| .13.hub_public_ip | 198.51.100.4 |
| .13.network | 10.253.7.48/30 |
| .13.branch_ip | 10.253.7.49 |
| .13.hub_ip | 10.253.7.50 |
| .14.hub_public_ip | 203.0.113.4 |
| .14.network | 10.253.7.52/30 |
| .14.branch_ip | 10.253.7.53 |
| .14.hub_ip | 10.253.7.54 |
| .15.hub_public_ip | 198.51.100.4 |
| .15.network | 10.253.7.56/30 |
| .15.branch_ip | 10.253.7.57 |
| .15.hub_ip | 10.253.7.58 |
| .16.hub_public_ip | 203.0.113.4 |
| .16.network | 10.253.7.60/30 |
| .16.branch_ip | 10.253.7.61 |
| .16.hub_ip | 10.253.7.62 |

### S08 — Antofagasta

28 PCs y 28 teléfonos existentes.

| Función | ANTES | DESPUÉS |
| --- | --- | --- |
| Routers | 1 × ISR4321/K9 | 2 × CCR2004-16G-2S+ |
| Switches | 1 × C9200L-48P-4G-E | CRS328-24P-4S+RM + CRS328-24P-4S+RM |
| Firewall | Sin equipo dedicado | Sin appliance remoto; seguridad central |
| Distribución WAN | MPLS y accesos ISP del escenario base | wanA: E50UG; wanB: E50UG |


| Red | VLAN | Subred | Gateway / roles |
| --- | --- | --- | --- |
| users | 10 | 10.70.8.0/25 | 10.70.8.1 |
| voice | 20 | 10.70.72.0/25 | 10.70.72.1 |
| guests | 40 | 10.70.104.0/26 | 10.70.104.1 |
| wifi_users | 110 | 10.81.8.0/25 | 10.81.8.1 |
| wifi_voice | 120 | 10.82.8.0/25 | 10.82.8.1 |
| management | 130 | 10.80.8.0/27 | 10.80.8.1 |


| Gestión | Dirección |
| --- | --- |
| sw1 | 10.80.8.2 |
| sw2 | 10.80.8.3 |
| r1 | 10.80.8.4 |
| r2 | 10.80.8.5 |
| wanA | 10.80.8.6 |
| wanB | 10.80.8.7 |
| ap1 | 10.80.8.24 |
| ap2 | 10.80.8.25 |


| Origen | Puerto | Destino | Puerto | Función | VLAN/red | Mbps | IP / agregado lógico |
| --- | --- | --- | --- | --- | --- | --- | --- |
| cpe:starlink | LAN | wanA | ether1 | WAN_ACCESS | 201 | 1000 | — |
| cpe:entel5g | LAN | wanA | ether2 | WAN_ACCESS | 203 | 1000 | — |
| r1 | ether1 | wanA | ether3 | WAN_TRUNK | 201, 203 | 1000 | — |
| r2 | ether1 | wanA | ether4 | WAN_TRUNK | 201, 203 | 1000 | — |
| wanA | ether5 | sw1 | ether22 | MANAGEMENT_ACCESS | 130 | 1000 | — |
| cpe:leo | LAN | wanB | ether1 | WAN_ACCESS | 202 | 1000 | — |
| cpe:wom4g | LAN | wanB | ether2 | WAN_ACCESS | 204 | 1000 | — |
| r1 | ether2 | wanB | ether3 | WAN_TRUNK | 202, 204 | 1000 | — |
| r2 | ether2 | wanB | ether4 | WAN_TRUNK | 202, 204 | 1000 | — |
| wanB | ether5 | sw2 | ether22 | MANAGEMENT_ACCESS | 130 | 1000 | — |
| r1 | ether3 | sw1 | ether19 | LAN_ROUTED | 172.31.8.0/30 | 1000 | router_ip: 172.31.8.1; stack_ip: 172.31.8.2 |
| r1 | ether4 | sw2 | ether19 | LAN_ROUTED | 172.31.8.4/30 | 1000 | router_ip: 172.31.8.5; stack_ip: 172.31.8.6 |
| r1 | ether5 | sw1 | ether21 | MANAGEMENT_ACCESS | 130 | 1000 | — |
| r2 | ether3 | sw1 | ether20 | LAN_ROUTED | 172.31.8.8/30 | 1000 | router_ip: 172.31.8.9; stack_ip: 172.31.8.10 |
| r2 | ether4 | sw2 | ether20 | LAN_ROUTED | 172.31.8.12/30 | 1000 | router_ip: 172.31.8.13; stack_ip: 172.31.8.14 |
| r2 | ether5 | sw2 | ether21 | MANAGEMENT_ACCESS | 130 | 1000 | — |
| ap1 | LAN | sw1 | ether24 | AP_TRUNK | 40, 110, 120, 130 | 1000 | — |
| ap2 | LAN | sw2 | ether24 | AP_TRUNK | 40, 110, 120, 130 | 1000 | — |
| sw1 | sfp-sfpplus1 | sw2 | sfp-sfpplus2 | STACK | 10, 20, 40, 110, 120, 130 | 10000 | — |
| sw1 | sfp-sfpplus2 | sw2 | sfp-sfpplus1 | STACK | 10, 20, 40, 110, 120, 130 | 10000 | — |


| Puesto | Switch | Puerto | IP PC | IP teléfono | Reserva Wi-Fi PC | Reserva Wi-Fi voz |
| --- | --- | --- | --- | --- | --- | --- |
| s08-pc01 | 1 | 1 | 10.70.8.10 | 10.70.72.10 | 10.81.8.10 | 10.82.8.10 |
| s08-pc02 | 2 | 1 | 10.70.8.11 | 10.70.72.11 | 10.81.8.11 | 10.82.8.11 |
| s08-pc03 | 1 | 2 | 10.70.8.12 | 10.70.72.12 | 10.81.8.12 | 10.82.8.12 |
| s08-pc04 | 2 | 2 | 10.70.8.13 | 10.70.72.13 | 10.81.8.13 | 10.82.8.13 |
| s08-pc05 | 1 | 3 | 10.70.8.14 | 10.70.72.14 | 10.81.8.14 | 10.82.8.14 |
| s08-pc06 | 2 | 3 | 10.70.8.15 | 10.70.72.15 | 10.81.8.15 | 10.82.8.15 |
| s08-pc07 | 1 | 4 | 10.70.8.16 | 10.70.72.16 | 10.81.8.16 | 10.82.8.16 |
| s08-pc08 | 2 | 4 | 10.70.8.17 | 10.70.72.17 | 10.81.8.17 | 10.82.8.17 |
| s08-pc09 | 1 | 5 | 10.70.8.18 | 10.70.72.18 | 10.81.8.18 | 10.82.8.18 |
| s08-pc10 | 2 | 5 | 10.70.8.19 | 10.70.72.19 | 10.81.8.19 | 10.82.8.19 |
| s08-pc11 | 1 | 6 | 10.70.8.20 | 10.70.72.20 | 10.81.8.20 | 10.82.8.20 |
| s08-pc12 | 2 | 6 | 10.70.8.21 | 10.70.72.21 | 10.81.8.21 | 10.82.8.21 |
| s08-pc13 | 1 | 7 | 10.70.8.22 | 10.70.72.22 | 10.81.8.22 | 10.82.8.22 |
| s08-pc14 | 2 | 7 | 10.70.8.23 | 10.70.72.23 | 10.81.8.23 | 10.82.8.23 |
| s08-pc15 | 1 | 8 | 10.70.8.24 | 10.70.72.24 | 10.81.8.24 | 10.82.8.24 |
| s08-pc16 | 2 | 8 | 10.70.8.25 | 10.70.72.25 | 10.81.8.25 | 10.82.8.25 |
| s08-pc17 | 1 | 9 | 10.70.8.26 | 10.70.72.26 | 10.81.8.26 | 10.82.8.26 |
| s08-pc18 | 2 | 9 | 10.70.8.27 | 10.70.72.27 | 10.81.8.27 | 10.82.8.27 |
| s08-pc19 | 1 | 10 | 10.70.8.28 | 10.70.72.28 | 10.81.8.28 | 10.82.8.28 |
| s08-pc20 | 2 | 10 | 10.70.8.29 | 10.70.72.29 | 10.81.8.29 | 10.82.8.29 |
| s08-pc21 | 1 | 11 | 10.70.8.30 | 10.70.72.30 | 10.81.8.30 | 10.82.8.30 |
| s08-pc22 | 2 | 11 | 10.70.8.31 | 10.70.72.31 | 10.81.8.31 | 10.82.8.31 |
| s08-pc23 | 1 | 12 | 10.70.8.32 | 10.70.72.32 | 10.81.8.32 | 10.82.8.32 |
| s08-pc24 | 2 | 12 | 10.70.8.33 | 10.70.72.33 | 10.81.8.33 | 10.82.8.33 |
| s08-pc25 | 1 | 13 | 10.70.8.34 | 10.70.72.34 | 10.81.8.34 | 10.82.8.34 |
| s08-pc26 | 2 | 13 | 10.70.8.35 | 10.70.72.35 | 10.81.8.35 | 10.82.8.35 |
| s08-pc27 | 1 | 14 | 10.70.8.36 | 10.70.72.36 | 10.81.8.36 | 10.82.8.36 |
| s08-pc28 | 2 | 14 | 10.70.8.37 | 10.70.72.37 | 10.81.8.37 | 10.82.8.37 |


**Transporte starlink — VLAN 201 — wanA.**

| Rol de entrega | Dirección |
| --- | --- |
| network | 10.252.8.0/29 |
| cpe | 10.252.8.1 |
| r1 | 10.252.8.2 |
| r2 | 10.252.8.3 |


**Transporte leo — VLAN 202 — wanB.**

| Rol de entrega | Dirección |
| --- | --- |
| network | 10.252.8.8/29 |
| cpe | 10.252.8.9 |
| r1 | 10.252.8.10 |
| r2 | 10.252.8.11 |


**Transporte entel5g — VLAN 203 — wanA.**

| Rol de entrega | Dirección |
| --- | --- |
| network | 10.252.8.16/29 |
| cpe | 10.252.8.17 |
| r1 | 10.252.8.18 |
| r2 | 10.252.8.19 |


**Transporte wom4g — VLAN 204 — wanB.**

| Rol de entrega | Dirección |
| --- | --- |
| network | 10.252.8.24/29 |
| cpe | 10.252.8.25 |
| r1 | 10.252.8.26 |
| r2 | 10.252.8.27 |


**Reservas de túneles (numeración según lista de la ficha).**

| Rol / candidato | Dirección |
| --- | --- |
| .1.hub_public_ip | 198.51.100.4 |
| .1.network | 10.253.8.0/30 |
| .1.branch_ip | 10.253.8.1 |
| .1.hub_ip | 10.253.8.2 |
| .2.hub_public_ip | 203.0.113.4 |
| .2.network | 10.253.8.4/30 |
| .2.branch_ip | 10.253.8.5 |
| .2.hub_ip | 10.253.8.6 |
| .3.hub_public_ip | 198.51.100.4 |
| .3.network | 10.253.8.8/30 |
| .3.branch_ip | 10.253.8.9 |
| .3.hub_ip | 10.253.8.10 |
| .4.hub_public_ip | 203.0.113.4 |
| .4.network | 10.253.8.12/30 |
| .4.branch_ip | 10.253.8.13 |
| .4.hub_ip | 10.253.8.14 |
| .5.hub_public_ip | 198.51.100.4 |
| .5.network | 10.253.8.16/30 |
| .5.branch_ip | 10.253.8.17 |
| .5.hub_ip | 10.253.8.18 |
| .6.hub_public_ip | 203.0.113.4 |
| .6.network | 10.253.8.20/30 |
| .6.branch_ip | 10.253.8.21 |
| .6.hub_ip | 10.253.8.22 |
| .7.hub_public_ip | 198.51.100.4 |
| .7.network | 10.253.8.24/30 |
| .7.branch_ip | 10.253.8.25 |
| .7.hub_ip | 10.253.8.26 |
| .8.hub_public_ip | 203.0.113.4 |
| .8.network | 10.253.8.28/30 |
| .8.branch_ip | 10.253.8.29 |
| .8.hub_ip | 10.253.8.30 |
| .9.hub_public_ip | 198.51.100.4 |
| .9.network | 10.253.8.32/30 |
| .9.branch_ip | 10.253.8.33 |
| .9.hub_ip | 10.253.8.34 |
| .10.hub_public_ip | 203.0.113.4 |
| .10.network | 10.253.8.36/30 |
| .10.branch_ip | 10.253.8.37 |
| .10.hub_ip | 10.253.8.38 |
| .11.hub_public_ip | 198.51.100.4 |
| .11.network | 10.253.8.40/30 |
| .11.branch_ip | 10.253.8.41 |
| .11.hub_ip | 10.253.8.42 |
| .12.hub_public_ip | 203.0.113.4 |
| .12.network | 10.253.8.44/30 |
| .12.branch_ip | 10.253.8.45 |
| .12.hub_ip | 10.253.8.46 |
| .13.hub_public_ip | 198.51.100.4 |
| .13.network | 10.253.8.48/30 |
| .13.branch_ip | 10.253.8.49 |
| .13.hub_ip | 10.253.8.50 |
| .14.hub_public_ip | 203.0.113.4 |
| .14.network | 10.253.8.52/30 |
| .14.branch_ip | 10.253.8.53 |
| .14.hub_ip | 10.253.8.54 |
| .15.hub_public_ip | 198.51.100.4 |
| .15.network | 10.253.8.56/30 |
| .15.branch_ip | 10.253.8.57 |
| .15.hub_ip | 10.253.8.58 |
| .16.hub_public_ip | 203.0.113.4 |
| .16.network | 10.253.8.60/30 |
| .16.branch_ip | 10.253.8.61 |
| .16.hub_ip | 10.253.8.62 |

### S09 — Copiapó

28 PCs y 28 teléfonos existentes.

| Función | ANTES | DESPUÉS |
| --- | --- | --- |
| Routers | 1 × C1121X-8P | 2 × CCR2004-16G-2S+ |
| Switches | 1 × C9200L-48P-4G-E | CRS328-24P-4S+RM + CRS328-24P-4S+RM |
| Firewall | Sin equipo dedicado | Sin appliance remoto; seguridad central |
| Distribución WAN | MPLS y accesos ISP del escenario base | wanA: E50UG; wanB: E50UG |


| Red | VLAN | Subred | Gateway / roles |
| --- | --- | --- | --- |
| users | 10 | 10.70.9.0/25 | 10.70.9.1 |
| voice | 20 | 10.70.73.0/25 | 10.70.73.1 |
| guests | 40 | 10.70.105.0/26 | 10.70.105.1 |
| wifi_users | 110 | 10.81.9.0/25 | 10.81.9.1 |
| wifi_voice | 120 | 10.82.9.0/25 | 10.82.9.1 |
| management | 130 | 10.80.9.0/27 | 10.80.9.1 |


| Gestión | Dirección |
| --- | --- |
| sw1 | 10.80.9.2 |
| sw2 | 10.80.9.3 |
| r1 | 10.80.9.4 |
| r2 | 10.80.9.5 |
| wanA | 10.80.9.6 |
| wanB | 10.80.9.7 |
| ap1 | 10.80.9.24 |
| ap2 | 10.80.9.25 |


| Origen | Puerto | Destino | Puerto | Función | VLAN/red | Mbps | IP / agregado lógico |
| --- | --- | --- | --- | --- | --- | --- | --- |
| cpe:starlink | LAN | wanA | ether1 | WAN_ACCESS | 201 | 1000 | — |
| cpe:entel5g | LAN | wanA | ether2 | WAN_ACCESS | 203 | 1000 | — |
| r1 | ether1 | wanA | ether3 | WAN_TRUNK | 201, 203 | 1000 | — |
| r2 | ether1 | wanA | ether4 | WAN_TRUNK | 201, 203 | 1000 | — |
| wanA | ether5 | sw1 | ether22 | MANAGEMENT_ACCESS | 130 | 1000 | — |
| cpe:leo | LAN | wanB | ether1 | WAN_ACCESS | 202 | 1000 | — |
| cpe:wom4g | LAN | wanB | ether2 | WAN_ACCESS | 204 | 1000 | — |
| r1 | ether2 | wanB | ether3 | WAN_TRUNK | 202, 204 | 1000 | — |
| r2 | ether2 | wanB | ether4 | WAN_TRUNK | 202, 204 | 1000 | — |
| wanB | ether5 | sw2 | ether22 | MANAGEMENT_ACCESS | 130 | 1000 | — |
| r1 | ether3 | sw1 | ether19 | LAN_ROUTED | 172.31.9.0/30 | 1000 | router_ip: 172.31.9.1; stack_ip: 172.31.9.2 |
| r1 | ether4 | sw2 | ether19 | LAN_ROUTED | 172.31.9.4/30 | 1000 | router_ip: 172.31.9.5; stack_ip: 172.31.9.6 |
| r1 | ether5 | sw1 | ether21 | MANAGEMENT_ACCESS | 130 | 1000 | — |
| r2 | ether3 | sw1 | ether20 | LAN_ROUTED | 172.31.9.8/30 | 1000 | router_ip: 172.31.9.9; stack_ip: 172.31.9.10 |
| r2 | ether4 | sw2 | ether20 | LAN_ROUTED | 172.31.9.12/30 | 1000 | router_ip: 172.31.9.13; stack_ip: 172.31.9.14 |
| r2 | ether5 | sw2 | ether21 | MANAGEMENT_ACCESS | 130 | 1000 | — |
| ap1 | LAN | sw1 | ether24 | AP_TRUNK | 40, 110, 120, 130 | 1000 | — |
| ap2 | LAN | sw2 | ether24 | AP_TRUNK | 40, 110, 120, 130 | 1000 | — |
| sw1 | sfp-sfpplus1 | sw2 | sfp-sfpplus2 | STACK | 10, 20, 40, 110, 120, 130 | 10000 | — |
| sw1 | sfp-sfpplus2 | sw2 | sfp-sfpplus1 | STACK | 10, 20, 40, 110, 120, 130 | 10000 | — |


| Puesto | Switch | Puerto | IP PC | IP teléfono | Reserva Wi-Fi PC | Reserva Wi-Fi voz |
| --- | --- | --- | --- | --- | --- | --- |
| s09-pc01 | 1 | 1 | 10.70.9.10 | 10.70.73.10 | 10.81.9.10 | 10.82.9.10 |
| s09-pc02 | 2 | 1 | 10.70.9.11 | 10.70.73.11 | 10.81.9.11 | 10.82.9.11 |
| s09-pc03 | 1 | 2 | 10.70.9.12 | 10.70.73.12 | 10.81.9.12 | 10.82.9.12 |
| s09-pc04 | 2 | 2 | 10.70.9.13 | 10.70.73.13 | 10.81.9.13 | 10.82.9.13 |
| s09-pc05 | 1 | 3 | 10.70.9.14 | 10.70.73.14 | 10.81.9.14 | 10.82.9.14 |
| s09-pc06 | 2 | 3 | 10.70.9.15 | 10.70.73.15 | 10.81.9.15 | 10.82.9.15 |
| s09-pc07 | 1 | 4 | 10.70.9.16 | 10.70.73.16 | 10.81.9.16 | 10.82.9.16 |
| s09-pc08 | 2 | 4 | 10.70.9.17 | 10.70.73.17 | 10.81.9.17 | 10.82.9.17 |
| s09-pc09 | 1 | 5 | 10.70.9.18 | 10.70.73.18 | 10.81.9.18 | 10.82.9.18 |
| s09-pc10 | 2 | 5 | 10.70.9.19 | 10.70.73.19 | 10.81.9.19 | 10.82.9.19 |
| s09-pc11 | 1 | 6 | 10.70.9.20 | 10.70.73.20 | 10.81.9.20 | 10.82.9.20 |
| s09-pc12 | 2 | 6 | 10.70.9.21 | 10.70.73.21 | 10.81.9.21 | 10.82.9.21 |
| s09-pc13 | 1 | 7 | 10.70.9.22 | 10.70.73.22 | 10.81.9.22 | 10.82.9.22 |
| s09-pc14 | 2 | 7 | 10.70.9.23 | 10.70.73.23 | 10.81.9.23 | 10.82.9.23 |
| s09-pc15 | 1 | 8 | 10.70.9.24 | 10.70.73.24 | 10.81.9.24 | 10.82.9.24 |
| s09-pc16 | 2 | 8 | 10.70.9.25 | 10.70.73.25 | 10.81.9.25 | 10.82.9.25 |
| s09-pc17 | 1 | 9 | 10.70.9.26 | 10.70.73.26 | 10.81.9.26 | 10.82.9.26 |
| s09-pc18 | 2 | 9 | 10.70.9.27 | 10.70.73.27 | 10.81.9.27 | 10.82.9.27 |
| s09-pc19 | 1 | 10 | 10.70.9.28 | 10.70.73.28 | 10.81.9.28 | 10.82.9.28 |
| s09-pc20 | 2 | 10 | 10.70.9.29 | 10.70.73.29 | 10.81.9.29 | 10.82.9.29 |
| s09-pc21 | 1 | 11 | 10.70.9.30 | 10.70.73.30 | 10.81.9.30 | 10.82.9.30 |
| s09-pc22 | 2 | 11 | 10.70.9.31 | 10.70.73.31 | 10.81.9.31 | 10.82.9.31 |
| s09-pc23 | 1 | 12 | 10.70.9.32 | 10.70.73.32 | 10.81.9.32 | 10.82.9.32 |
| s09-pc24 | 2 | 12 | 10.70.9.33 | 10.70.73.33 | 10.81.9.33 | 10.82.9.33 |
| s09-pc25 | 1 | 13 | 10.70.9.34 | 10.70.73.34 | 10.81.9.34 | 10.82.9.34 |
| s09-pc26 | 2 | 13 | 10.70.9.35 | 10.70.73.35 | 10.81.9.35 | 10.82.9.35 |
| s09-pc27 | 1 | 14 | 10.70.9.36 | 10.70.73.36 | 10.81.9.36 | 10.82.9.36 |
| s09-pc28 | 2 | 14 | 10.70.9.37 | 10.70.73.37 | 10.81.9.37 | 10.82.9.37 |


**Transporte starlink — VLAN 201 — wanA.**

| Rol de entrega | Dirección |
| --- | --- |
| network | 10.252.9.0/29 |
| cpe | 10.252.9.1 |
| r1 | 10.252.9.2 |
| r2 | 10.252.9.3 |


**Transporte leo — VLAN 202 — wanB.**

| Rol de entrega | Dirección |
| --- | --- |
| network | 10.252.9.8/29 |
| cpe | 10.252.9.9 |
| r1 | 10.252.9.10 |
| r2 | 10.252.9.11 |


**Transporte entel5g — VLAN 203 — wanA.**

| Rol de entrega | Dirección |
| --- | --- |
| network | 10.252.9.16/29 |
| cpe | 10.252.9.17 |
| r1 | 10.252.9.18 |
| r2 | 10.252.9.19 |


**Transporte wom4g — VLAN 204 — wanB.**

| Rol de entrega | Dirección |
| --- | --- |
| network | 10.252.9.24/29 |
| cpe | 10.252.9.25 |
| r1 | 10.252.9.26 |
| r2 | 10.252.9.27 |


**Reservas de túneles (numeración según lista de la ficha).**

| Rol / candidato | Dirección |
| --- | --- |
| .1.hub_public_ip | 198.51.100.4 |
| .1.network | 10.253.9.0/30 |
| .1.branch_ip | 10.253.9.1 |
| .1.hub_ip | 10.253.9.2 |
| .2.hub_public_ip | 203.0.113.4 |
| .2.network | 10.253.9.4/30 |
| .2.branch_ip | 10.253.9.5 |
| .2.hub_ip | 10.253.9.6 |
| .3.hub_public_ip | 198.51.100.4 |
| .3.network | 10.253.9.8/30 |
| .3.branch_ip | 10.253.9.9 |
| .3.hub_ip | 10.253.9.10 |
| .4.hub_public_ip | 203.0.113.4 |
| .4.network | 10.253.9.12/30 |
| .4.branch_ip | 10.253.9.13 |
| .4.hub_ip | 10.253.9.14 |
| .5.hub_public_ip | 198.51.100.4 |
| .5.network | 10.253.9.16/30 |
| .5.branch_ip | 10.253.9.17 |
| .5.hub_ip | 10.253.9.18 |
| .6.hub_public_ip | 203.0.113.4 |
| .6.network | 10.253.9.20/30 |
| .6.branch_ip | 10.253.9.21 |
| .6.hub_ip | 10.253.9.22 |
| .7.hub_public_ip | 198.51.100.4 |
| .7.network | 10.253.9.24/30 |
| .7.branch_ip | 10.253.9.25 |
| .7.hub_ip | 10.253.9.26 |
| .8.hub_public_ip | 203.0.113.4 |
| .8.network | 10.253.9.28/30 |
| .8.branch_ip | 10.253.9.29 |
| .8.hub_ip | 10.253.9.30 |
| .9.hub_public_ip | 198.51.100.4 |
| .9.network | 10.253.9.32/30 |
| .9.branch_ip | 10.253.9.33 |
| .9.hub_ip | 10.253.9.34 |
| .10.hub_public_ip | 203.0.113.4 |
| .10.network | 10.253.9.36/30 |
| .10.branch_ip | 10.253.9.37 |
| .10.hub_ip | 10.253.9.38 |
| .11.hub_public_ip | 198.51.100.4 |
| .11.network | 10.253.9.40/30 |
| .11.branch_ip | 10.253.9.41 |
| .11.hub_ip | 10.253.9.42 |
| .12.hub_public_ip | 203.0.113.4 |
| .12.network | 10.253.9.44/30 |
| .12.branch_ip | 10.253.9.45 |
| .12.hub_ip | 10.253.9.46 |
| .13.hub_public_ip | 198.51.100.4 |
| .13.network | 10.253.9.48/30 |
| .13.branch_ip | 10.253.9.49 |
| .13.hub_ip | 10.253.9.50 |
| .14.hub_public_ip | 203.0.113.4 |
| .14.network | 10.253.9.52/30 |
| .14.branch_ip | 10.253.9.53 |
| .14.hub_ip | 10.253.9.54 |
| .15.hub_public_ip | 198.51.100.4 |
| .15.network | 10.253.9.56/30 |
| .15.branch_ip | 10.253.9.57 |
| .15.hub_ip | 10.253.9.58 |
| .16.hub_public_ip | 203.0.113.4 |
| .16.network | 10.253.9.60/30 |
| .16.branch_ip | 10.253.9.61 |
| .16.hub_ip | 10.253.9.62 |

### S10 — La Serena

28 PCs y 28 teléfonos existentes.

| Función | ANTES | DESPUÉS |
| --- | --- | --- |
| Routers | 1 × ISR4321/K9 | 2 × CCR2004-16G-2S+ |
| Switches | 1 × C9200L-48P-4G-E | CRS328-24P-4S+RM + CRS328-24P-4S+RM |
| Firewall | Sin equipo dedicado | Sin appliance remoto; seguridad central |
| Distribución WAN | MPLS y accesos ISP del escenario base | wanA: E50UG; wanB: E50UG |


| Red | VLAN | Subred | Gateway / roles |
| --- | --- | --- | --- |
| users | 10 | 10.70.10.0/25 | 10.70.10.1 |
| voice | 20 | 10.70.74.0/25 | 10.70.74.1 |
| guests | 40 | 10.70.106.0/26 | 10.70.106.1 |
| wifi_users | 110 | 10.81.10.0/25 | 10.81.10.1 |
| wifi_voice | 120 | 10.82.10.0/25 | 10.82.10.1 |
| management | 130 | 10.80.10.0/27 | 10.80.10.1 |


| Gestión | Dirección |
| --- | --- |
| sw1 | 10.80.10.2 |
| sw2 | 10.80.10.3 |
| r1 | 10.80.10.4 |
| r2 | 10.80.10.5 |
| wanA | 10.80.10.6 |
| wanB | 10.80.10.7 |
| ap1 | 10.80.10.24 |
| ap2 | 10.80.10.25 |


| Origen | Puerto | Destino | Puerto | Función | VLAN/red | Mbps | IP / agregado lógico |
| --- | --- | --- | --- | --- | --- | --- | --- |
| cpe:starlink | LAN | wanA | ether1 | WAN_ACCESS | 201 | 1000 | — |
| cpe:entel5g | LAN | wanA | ether2 | WAN_ACCESS | 203 | 1000 | — |
| r1 | ether1 | wanA | ether3 | WAN_TRUNK | 201, 203 | 1000 | — |
| r2 | ether1 | wanA | ether4 | WAN_TRUNK | 201, 203 | 1000 | — |
| wanA | ether5 | sw1 | ether22 | MANAGEMENT_ACCESS | 130 | 1000 | — |
| cpe:leo | LAN | wanB | ether1 | WAN_ACCESS | 202 | 1000 | — |
| cpe:wom4g | LAN | wanB | ether2 | WAN_ACCESS | 204 | 1000 | — |
| r1 | ether2 | wanB | ether3 | WAN_TRUNK | 202, 204 | 1000 | — |
| r2 | ether2 | wanB | ether4 | WAN_TRUNK | 202, 204 | 1000 | — |
| wanB | ether5 | sw2 | ether22 | MANAGEMENT_ACCESS | 130 | 1000 | — |
| r1 | ether3 | sw1 | ether19 | LAN_ROUTED | 172.31.10.0/30 | 1000 | router_ip: 172.31.10.1; stack_ip: 172.31.10.2 |
| r1 | ether4 | sw2 | ether19 | LAN_ROUTED | 172.31.10.4/30 | 1000 | router_ip: 172.31.10.5; stack_ip: 172.31.10.6 |
| r1 | ether5 | sw1 | ether21 | MANAGEMENT_ACCESS | 130 | 1000 | — |
| r2 | ether3 | sw1 | ether20 | LAN_ROUTED | 172.31.10.8/30 | 1000 | router_ip: 172.31.10.9; stack_ip: 172.31.10.10 |
| r2 | ether4 | sw2 | ether20 | LAN_ROUTED | 172.31.10.12/30 | 1000 | router_ip: 172.31.10.13; stack_ip: 172.31.10.14 |
| r2 | ether5 | sw2 | ether21 | MANAGEMENT_ACCESS | 130 | 1000 | — |
| ap1 | LAN | sw1 | ether24 | AP_TRUNK | 40, 110, 120, 130 | 1000 | — |
| ap2 | LAN | sw2 | ether24 | AP_TRUNK | 40, 110, 120, 130 | 1000 | — |
| sw1 | sfp-sfpplus1 | sw2 | sfp-sfpplus2 | STACK | 10, 20, 40, 110, 120, 130 | 10000 | — |
| sw1 | sfp-sfpplus2 | sw2 | sfp-sfpplus1 | STACK | 10, 20, 40, 110, 120, 130 | 10000 | — |


| Puesto | Switch | Puerto | IP PC | IP teléfono | Reserva Wi-Fi PC | Reserva Wi-Fi voz |
| --- | --- | --- | --- | --- | --- | --- |
| s10-pc01 | 1 | 1 | 10.70.10.10 | 10.70.74.10 | 10.81.10.10 | 10.82.10.10 |
| s10-pc02 | 2 | 1 | 10.70.10.11 | 10.70.74.11 | 10.81.10.11 | 10.82.10.11 |
| s10-pc03 | 1 | 2 | 10.70.10.12 | 10.70.74.12 | 10.81.10.12 | 10.82.10.12 |
| s10-pc04 | 2 | 2 | 10.70.10.13 | 10.70.74.13 | 10.81.10.13 | 10.82.10.13 |
| s10-pc05 | 1 | 3 | 10.70.10.14 | 10.70.74.14 | 10.81.10.14 | 10.82.10.14 |
| s10-pc06 | 2 | 3 | 10.70.10.15 | 10.70.74.15 | 10.81.10.15 | 10.82.10.15 |
| s10-pc07 | 1 | 4 | 10.70.10.16 | 10.70.74.16 | 10.81.10.16 | 10.82.10.16 |
| s10-pc08 | 2 | 4 | 10.70.10.17 | 10.70.74.17 | 10.81.10.17 | 10.82.10.17 |
| s10-pc09 | 1 | 5 | 10.70.10.18 | 10.70.74.18 | 10.81.10.18 | 10.82.10.18 |
| s10-pc10 | 2 | 5 | 10.70.10.19 | 10.70.74.19 | 10.81.10.19 | 10.82.10.19 |
| s10-pc11 | 1 | 6 | 10.70.10.20 | 10.70.74.20 | 10.81.10.20 | 10.82.10.20 |
| s10-pc12 | 2 | 6 | 10.70.10.21 | 10.70.74.21 | 10.81.10.21 | 10.82.10.21 |
| s10-pc13 | 1 | 7 | 10.70.10.22 | 10.70.74.22 | 10.81.10.22 | 10.82.10.22 |
| s10-pc14 | 2 | 7 | 10.70.10.23 | 10.70.74.23 | 10.81.10.23 | 10.82.10.23 |
| s10-pc15 | 1 | 8 | 10.70.10.24 | 10.70.74.24 | 10.81.10.24 | 10.82.10.24 |
| s10-pc16 | 2 | 8 | 10.70.10.25 | 10.70.74.25 | 10.81.10.25 | 10.82.10.25 |
| s10-pc17 | 1 | 9 | 10.70.10.26 | 10.70.74.26 | 10.81.10.26 | 10.82.10.26 |
| s10-pc18 | 2 | 9 | 10.70.10.27 | 10.70.74.27 | 10.81.10.27 | 10.82.10.27 |
| s10-pc19 | 1 | 10 | 10.70.10.28 | 10.70.74.28 | 10.81.10.28 | 10.82.10.28 |
| s10-pc20 | 2 | 10 | 10.70.10.29 | 10.70.74.29 | 10.81.10.29 | 10.82.10.29 |
| s10-pc21 | 1 | 11 | 10.70.10.30 | 10.70.74.30 | 10.81.10.30 | 10.82.10.30 |
| s10-pc22 | 2 | 11 | 10.70.10.31 | 10.70.74.31 | 10.81.10.31 | 10.82.10.31 |
| s10-pc23 | 1 | 12 | 10.70.10.32 | 10.70.74.32 | 10.81.10.32 | 10.82.10.32 |
| s10-pc24 | 2 | 12 | 10.70.10.33 | 10.70.74.33 | 10.81.10.33 | 10.82.10.33 |
| s10-pc25 | 1 | 13 | 10.70.10.34 | 10.70.74.34 | 10.81.10.34 | 10.82.10.34 |
| s10-pc26 | 2 | 13 | 10.70.10.35 | 10.70.74.35 | 10.81.10.35 | 10.82.10.35 |
| s10-pc27 | 1 | 14 | 10.70.10.36 | 10.70.74.36 | 10.81.10.36 | 10.82.10.36 |
| s10-pc28 | 2 | 14 | 10.70.10.37 | 10.70.74.37 | 10.81.10.37 | 10.82.10.37 |


**Transporte starlink — VLAN 201 — wanA.**

| Rol de entrega | Dirección |
| --- | --- |
| network | 10.252.10.0/29 |
| cpe | 10.252.10.1 |
| r1 | 10.252.10.2 |
| r2 | 10.252.10.3 |


**Transporte leo — VLAN 202 — wanB.**

| Rol de entrega | Dirección |
| --- | --- |
| network | 10.252.10.8/29 |
| cpe | 10.252.10.9 |
| r1 | 10.252.10.10 |
| r2 | 10.252.10.11 |


**Transporte entel5g — VLAN 203 — wanA.**

| Rol de entrega | Dirección |
| --- | --- |
| network | 10.252.10.16/29 |
| cpe | 10.252.10.17 |
| r1 | 10.252.10.18 |
| r2 | 10.252.10.19 |


**Transporte wom4g — VLAN 204 — wanB.**

| Rol de entrega | Dirección |
| --- | --- |
| network | 10.252.10.24/29 |
| cpe | 10.252.10.25 |
| r1 | 10.252.10.26 |
| r2 | 10.252.10.27 |


**Reservas de túneles (numeración según lista de la ficha).**

| Rol / candidato | Dirección |
| --- | --- |
| .1.hub_public_ip | 198.51.100.4 |
| .1.network | 10.253.10.0/30 |
| .1.branch_ip | 10.253.10.1 |
| .1.hub_ip | 10.253.10.2 |
| .2.hub_public_ip | 203.0.113.4 |
| .2.network | 10.253.10.4/30 |
| .2.branch_ip | 10.253.10.5 |
| .2.hub_ip | 10.253.10.6 |
| .3.hub_public_ip | 198.51.100.4 |
| .3.network | 10.253.10.8/30 |
| .3.branch_ip | 10.253.10.9 |
| .3.hub_ip | 10.253.10.10 |
| .4.hub_public_ip | 203.0.113.4 |
| .4.network | 10.253.10.12/30 |
| .4.branch_ip | 10.253.10.13 |
| .4.hub_ip | 10.253.10.14 |
| .5.hub_public_ip | 198.51.100.4 |
| .5.network | 10.253.10.16/30 |
| .5.branch_ip | 10.253.10.17 |
| .5.hub_ip | 10.253.10.18 |
| .6.hub_public_ip | 203.0.113.4 |
| .6.network | 10.253.10.20/30 |
| .6.branch_ip | 10.253.10.21 |
| .6.hub_ip | 10.253.10.22 |
| .7.hub_public_ip | 198.51.100.4 |
| .7.network | 10.253.10.24/30 |
| .7.branch_ip | 10.253.10.25 |
| .7.hub_ip | 10.253.10.26 |
| .8.hub_public_ip | 203.0.113.4 |
| .8.network | 10.253.10.28/30 |
| .8.branch_ip | 10.253.10.29 |
| .8.hub_ip | 10.253.10.30 |
| .9.hub_public_ip | 198.51.100.4 |
| .9.network | 10.253.10.32/30 |
| .9.branch_ip | 10.253.10.33 |
| .9.hub_ip | 10.253.10.34 |
| .10.hub_public_ip | 203.0.113.4 |
| .10.network | 10.253.10.36/30 |
| .10.branch_ip | 10.253.10.37 |
| .10.hub_ip | 10.253.10.38 |
| .11.hub_public_ip | 198.51.100.4 |
| .11.network | 10.253.10.40/30 |
| .11.branch_ip | 10.253.10.41 |
| .11.hub_ip | 10.253.10.42 |
| .12.hub_public_ip | 203.0.113.4 |
| .12.network | 10.253.10.44/30 |
| .12.branch_ip | 10.253.10.45 |
| .12.hub_ip | 10.253.10.46 |
| .13.hub_public_ip | 198.51.100.4 |
| .13.network | 10.253.10.48/30 |
| .13.branch_ip | 10.253.10.49 |
| .13.hub_ip | 10.253.10.50 |
| .14.hub_public_ip | 203.0.113.4 |
| .14.network | 10.253.10.52/30 |
| .14.branch_ip | 10.253.10.53 |
| .14.hub_ip | 10.253.10.54 |
| .15.hub_public_ip | 198.51.100.4 |
| .15.network | 10.253.10.56/30 |
| .15.branch_ip | 10.253.10.57 |
| .15.hub_ip | 10.253.10.58 |
| .16.hub_public_ip | 203.0.113.4 |
| .16.network | 10.253.10.60/30 |
| .16.branch_ip | 10.253.10.61 |
| .16.hub_ip | 10.253.10.62 |

### S11 — Valparaíso

28 PCs y 28 teléfonos existentes.

| Función | ANTES | DESPUÉS |
| --- | --- | --- |
| Routers | 1 × CISCO1921-SEC/K9 | 2 × CCR2004-16G-2S+ |
| Switches | 1 × WS-C2960S-48LPS-L | CRS328-24P-4S+RM + CRS328-24P-4S+RM |
| Firewall | Sin equipo dedicado | Sin appliance remoto; seguridad central |
| Distribución WAN | MPLS y accesos ISP del escenario base | wanA: E50UG; wanB: E50UG |


| Red | VLAN | Subred | Gateway / roles |
| --- | --- | --- | --- |
| users | 10 | 10.70.11.0/25 | 10.70.11.1 |
| voice | 20 | 10.70.75.0/25 | 10.70.75.1 |
| guests | 40 | 10.70.107.0/26 | 10.70.107.1 |
| wifi_users | 110 | 10.81.11.0/25 | 10.81.11.1 |
| wifi_voice | 120 | 10.82.11.0/25 | 10.82.11.1 |
| management | 130 | 10.80.11.0/27 | 10.80.11.1 |


| Gestión | Dirección |
| --- | --- |
| sw1 | 10.80.11.2 |
| sw2 | 10.80.11.3 |
| r1 | 10.80.11.4 |
| r2 | 10.80.11.5 |
| wanA | 10.80.11.6 |
| wanB | 10.80.11.7 |
| ap1 | 10.80.11.24 |
| ap2 | 10.80.11.25 |


| Origen | Puerto | Destino | Puerto | Función | VLAN/red | Mbps | IP / agregado lógico |
| --- | --- | --- | --- | --- | --- | --- | --- |
| cpe:starlink | LAN | wanA | ether1 | WAN_ACCESS | 201 | 1000 | — |
| cpe:entel5g | LAN | wanA | ether2 | WAN_ACCESS | 203 | 1000 | — |
| r1 | ether1 | wanA | ether3 | WAN_TRUNK | 201, 203 | 1000 | — |
| r2 | ether1 | wanA | ether4 | WAN_TRUNK | 201, 203 | 1000 | — |
| wanA | ether5 | sw1 | ether22 | MANAGEMENT_ACCESS | 130 | 1000 | — |
| cpe:leo | LAN | wanB | ether1 | WAN_ACCESS | 202 | 1000 | — |
| cpe:wom4g | LAN | wanB | ether2 | WAN_ACCESS | 204 | 1000 | — |
| r1 | ether2 | wanB | ether3 | WAN_TRUNK | 202, 204 | 1000 | — |
| r2 | ether2 | wanB | ether4 | WAN_TRUNK | 202, 204 | 1000 | — |
| wanB | ether5 | sw2 | ether22 | MANAGEMENT_ACCESS | 130 | 1000 | — |
| r1 | ether3 | sw1 | ether19 | LAN_ROUTED | 172.31.11.0/30 | 1000 | router_ip: 172.31.11.1; stack_ip: 172.31.11.2 |
| r1 | ether4 | sw2 | ether19 | LAN_ROUTED | 172.31.11.4/30 | 1000 | router_ip: 172.31.11.5; stack_ip: 172.31.11.6 |
| r1 | ether5 | sw1 | ether21 | MANAGEMENT_ACCESS | 130 | 1000 | — |
| r2 | ether3 | sw1 | ether20 | LAN_ROUTED | 172.31.11.8/30 | 1000 | router_ip: 172.31.11.9; stack_ip: 172.31.11.10 |
| r2 | ether4 | sw2 | ether20 | LAN_ROUTED | 172.31.11.12/30 | 1000 | router_ip: 172.31.11.13; stack_ip: 172.31.11.14 |
| r2 | ether5 | sw2 | ether21 | MANAGEMENT_ACCESS | 130 | 1000 | — |
| ap1 | LAN | sw1 | ether24 | AP_TRUNK | 40, 110, 120, 130 | 1000 | — |
| ap2 | LAN | sw2 | ether24 | AP_TRUNK | 40, 110, 120, 130 | 1000 | — |
| sw1 | sfp-sfpplus1 | sw2 | sfp-sfpplus2 | STACK | 10, 20, 40, 110, 120, 130 | 10000 | — |
| sw1 | sfp-sfpplus2 | sw2 | sfp-sfpplus1 | STACK | 10, 20, 40, 110, 120, 130 | 10000 | — |


| Puesto | Switch | Puerto | IP PC | IP teléfono | Reserva Wi-Fi PC | Reserva Wi-Fi voz |
| --- | --- | --- | --- | --- | --- | --- |
| s11-pc01 | 1 | 1 | 10.70.11.10 | 10.70.75.10 | 10.81.11.10 | 10.82.11.10 |
| s11-pc02 | 2 | 1 | 10.70.11.11 | 10.70.75.11 | 10.81.11.11 | 10.82.11.11 |
| s11-pc03 | 1 | 2 | 10.70.11.12 | 10.70.75.12 | 10.81.11.12 | 10.82.11.12 |
| s11-pc04 | 2 | 2 | 10.70.11.13 | 10.70.75.13 | 10.81.11.13 | 10.82.11.13 |
| s11-pc05 | 1 | 3 | 10.70.11.14 | 10.70.75.14 | 10.81.11.14 | 10.82.11.14 |
| s11-pc06 | 2 | 3 | 10.70.11.15 | 10.70.75.15 | 10.81.11.15 | 10.82.11.15 |
| s11-pc07 | 1 | 4 | 10.70.11.16 | 10.70.75.16 | 10.81.11.16 | 10.82.11.16 |
| s11-pc08 | 2 | 4 | 10.70.11.17 | 10.70.75.17 | 10.81.11.17 | 10.82.11.17 |
| s11-pc09 | 1 | 5 | 10.70.11.18 | 10.70.75.18 | 10.81.11.18 | 10.82.11.18 |
| s11-pc10 | 2 | 5 | 10.70.11.19 | 10.70.75.19 | 10.81.11.19 | 10.82.11.19 |
| s11-pc11 | 1 | 6 | 10.70.11.20 | 10.70.75.20 | 10.81.11.20 | 10.82.11.20 |
| s11-pc12 | 2 | 6 | 10.70.11.21 | 10.70.75.21 | 10.81.11.21 | 10.82.11.21 |
| s11-pc13 | 1 | 7 | 10.70.11.22 | 10.70.75.22 | 10.81.11.22 | 10.82.11.22 |
| s11-pc14 | 2 | 7 | 10.70.11.23 | 10.70.75.23 | 10.81.11.23 | 10.82.11.23 |
| s11-pc15 | 1 | 8 | 10.70.11.24 | 10.70.75.24 | 10.81.11.24 | 10.82.11.24 |
| s11-pc16 | 2 | 8 | 10.70.11.25 | 10.70.75.25 | 10.81.11.25 | 10.82.11.25 |
| s11-pc17 | 1 | 9 | 10.70.11.26 | 10.70.75.26 | 10.81.11.26 | 10.82.11.26 |
| s11-pc18 | 2 | 9 | 10.70.11.27 | 10.70.75.27 | 10.81.11.27 | 10.82.11.27 |
| s11-pc19 | 1 | 10 | 10.70.11.28 | 10.70.75.28 | 10.81.11.28 | 10.82.11.28 |
| s11-pc20 | 2 | 10 | 10.70.11.29 | 10.70.75.29 | 10.81.11.29 | 10.82.11.29 |
| s11-pc21 | 1 | 11 | 10.70.11.30 | 10.70.75.30 | 10.81.11.30 | 10.82.11.30 |
| s11-pc22 | 2 | 11 | 10.70.11.31 | 10.70.75.31 | 10.81.11.31 | 10.82.11.31 |
| s11-pc23 | 1 | 12 | 10.70.11.32 | 10.70.75.32 | 10.81.11.32 | 10.82.11.32 |
| s11-pc24 | 2 | 12 | 10.70.11.33 | 10.70.75.33 | 10.81.11.33 | 10.82.11.33 |
| s11-pc25 | 1 | 13 | 10.70.11.34 | 10.70.75.34 | 10.81.11.34 | 10.82.11.34 |
| s11-pc26 | 2 | 13 | 10.70.11.35 | 10.70.75.35 | 10.81.11.35 | 10.82.11.35 |
| s11-pc27 | 1 | 14 | 10.70.11.36 | 10.70.75.36 | 10.81.11.36 | 10.82.11.36 |
| s11-pc28 | 2 | 14 | 10.70.11.37 | 10.70.75.37 | 10.81.11.37 | 10.82.11.37 |


**Transporte starlink — VLAN 201 — wanA.**

| Rol de entrega | Dirección |
| --- | --- |
| network | 10.252.11.0/29 |
| cpe | 10.252.11.1 |
| r1 | 10.252.11.2 |
| r2 | 10.252.11.3 |


**Transporte leo — VLAN 202 — wanB.**

| Rol de entrega | Dirección |
| --- | --- |
| network | 10.252.11.8/29 |
| cpe | 10.252.11.9 |
| r1 | 10.252.11.10 |
| r2 | 10.252.11.11 |


**Transporte entel5g — VLAN 203 — wanA.**

| Rol de entrega | Dirección |
| --- | --- |
| network | 10.252.11.16/29 |
| cpe | 10.252.11.17 |
| r1 | 10.252.11.18 |
| r2 | 10.252.11.19 |


**Transporte wom4g — VLAN 204 — wanB.**

| Rol de entrega | Dirección |
| --- | --- |
| network | 10.252.11.24/29 |
| cpe | 10.252.11.25 |
| r1 | 10.252.11.26 |
| r2 | 10.252.11.27 |


**Reservas de túneles (numeración según lista de la ficha).**

| Rol / candidato | Dirección |
| --- | --- |
| .1.hub_public_ip | 198.51.100.4 |
| .1.network | 10.253.11.0/30 |
| .1.branch_ip | 10.253.11.1 |
| .1.hub_ip | 10.253.11.2 |
| .2.hub_public_ip | 203.0.113.4 |
| .2.network | 10.253.11.4/30 |
| .2.branch_ip | 10.253.11.5 |
| .2.hub_ip | 10.253.11.6 |
| .3.hub_public_ip | 198.51.100.4 |
| .3.network | 10.253.11.8/30 |
| .3.branch_ip | 10.253.11.9 |
| .3.hub_ip | 10.253.11.10 |
| .4.hub_public_ip | 203.0.113.4 |
| .4.network | 10.253.11.12/30 |
| .4.branch_ip | 10.253.11.13 |
| .4.hub_ip | 10.253.11.14 |
| .5.hub_public_ip | 198.51.100.4 |
| .5.network | 10.253.11.16/30 |
| .5.branch_ip | 10.253.11.17 |
| .5.hub_ip | 10.253.11.18 |
| .6.hub_public_ip | 203.0.113.4 |
| .6.network | 10.253.11.20/30 |
| .6.branch_ip | 10.253.11.21 |
| .6.hub_ip | 10.253.11.22 |
| .7.hub_public_ip | 198.51.100.4 |
| .7.network | 10.253.11.24/30 |
| .7.branch_ip | 10.253.11.25 |
| .7.hub_ip | 10.253.11.26 |
| .8.hub_public_ip | 203.0.113.4 |
| .8.network | 10.253.11.28/30 |
| .8.branch_ip | 10.253.11.29 |
| .8.hub_ip | 10.253.11.30 |
| .9.hub_public_ip | 198.51.100.4 |
| .9.network | 10.253.11.32/30 |
| .9.branch_ip | 10.253.11.33 |
| .9.hub_ip | 10.253.11.34 |
| .10.hub_public_ip | 203.0.113.4 |
| .10.network | 10.253.11.36/30 |
| .10.branch_ip | 10.253.11.37 |
| .10.hub_ip | 10.253.11.38 |
| .11.hub_public_ip | 198.51.100.4 |
| .11.network | 10.253.11.40/30 |
| .11.branch_ip | 10.253.11.41 |
| .11.hub_ip | 10.253.11.42 |
| .12.hub_public_ip | 203.0.113.4 |
| .12.network | 10.253.11.44/30 |
| .12.branch_ip | 10.253.11.45 |
| .12.hub_ip | 10.253.11.46 |
| .13.hub_public_ip | 198.51.100.4 |
| .13.network | 10.253.11.48/30 |
| .13.branch_ip | 10.253.11.49 |
| .13.hub_ip | 10.253.11.50 |
| .14.hub_public_ip | 203.0.113.4 |
| .14.network | 10.253.11.52/30 |
| .14.branch_ip | 10.253.11.53 |
| .14.hub_ip | 10.253.11.54 |
| .15.hub_public_ip | 198.51.100.4 |
| .15.network | 10.253.11.56/30 |
| .15.branch_ip | 10.253.11.57 |
| .15.hub_ip | 10.253.11.58 |
| .16.hub_public_ip | 203.0.113.4 |
| .16.network | 10.253.11.60/30 |
| .16.branch_ip | 10.253.11.61 |
| .16.hub_ip | 10.253.11.62 |

### S12 — Rancagua

28 PCs y 28 teléfonos existentes.

| Función | ANTES | DESPUÉS |
| --- | --- | --- |
| Routers | 1 × CISCO1921-SEC/K9 | 2 × CCR2004-16G-2S+ |
| Switches | 1 × WS-C2960S-48LPS-L | CRS328-24P-4S+RM + CRS328-24P-4S+RM |
| Firewall | Sin equipo dedicado | Sin appliance remoto; seguridad central |
| Distribución WAN | MPLS y accesos ISP del escenario base | wanA: E50UG; wanB: E50UG |


| Red | VLAN | Subred | Gateway / roles |
| --- | --- | --- | --- |
| users | 10 | 10.70.12.0/25 | 10.70.12.1 |
| voice | 20 | 10.70.76.0/25 | 10.70.76.1 |
| guests | 40 | 10.70.108.0/26 | 10.70.108.1 |
| wifi_users | 110 | 10.81.12.0/25 | 10.81.12.1 |
| wifi_voice | 120 | 10.82.12.0/25 | 10.82.12.1 |
| management | 130 | 10.80.12.0/27 | 10.80.12.1 |


| Gestión | Dirección |
| --- | --- |
| sw1 | 10.80.12.2 |
| sw2 | 10.80.12.3 |
| r1 | 10.80.12.4 |
| r2 | 10.80.12.5 |
| wanA | 10.80.12.6 |
| wanB | 10.80.12.7 |
| ap1 | 10.80.12.24 |
| ap2 | 10.80.12.25 |


| Origen | Puerto | Destino | Puerto | Función | VLAN/red | Mbps | IP / agregado lógico |
| --- | --- | --- | --- | --- | --- | --- | --- |
| cpe:starlink | LAN | wanA | ether1 | WAN_ACCESS | 201 | 1000 | — |
| cpe:entel5g | LAN | wanA | ether2 | WAN_ACCESS | 203 | 1000 | — |
| r1 | ether1 | wanA | ether3 | WAN_TRUNK | 201, 203 | 1000 | — |
| r2 | ether1 | wanA | ether4 | WAN_TRUNK | 201, 203 | 1000 | — |
| wanA | ether5 | sw1 | ether22 | MANAGEMENT_ACCESS | 130 | 1000 | — |
| cpe:leo | LAN | wanB | ether1 | WAN_ACCESS | 202 | 1000 | — |
| cpe:wom4g | LAN | wanB | ether2 | WAN_ACCESS | 204 | 1000 | — |
| r1 | ether2 | wanB | ether3 | WAN_TRUNK | 202, 204 | 1000 | — |
| r2 | ether2 | wanB | ether4 | WAN_TRUNK | 202, 204 | 1000 | — |
| wanB | ether5 | sw2 | ether22 | MANAGEMENT_ACCESS | 130 | 1000 | — |
| r1 | ether3 | sw1 | ether19 | LAN_ROUTED | 172.31.12.0/30 | 1000 | router_ip: 172.31.12.1; stack_ip: 172.31.12.2 |
| r1 | ether4 | sw2 | ether19 | LAN_ROUTED | 172.31.12.4/30 | 1000 | router_ip: 172.31.12.5; stack_ip: 172.31.12.6 |
| r1 | ether5 | sw1 | ether21 | MANAGEMENT_ACCESS | 130 | 1000 | — |
| r2 | ether3 | sw1 | ether20 | LAN_ROUTED | 172.31.12.8/30 | 1000 | router_ip: 172.31.12.9; stack_ip: 172.31.12.10 |
| r2 | ether4 | sw2 | ether20 | LAN_ROUTED | 172.31.12.12/30 | 1000 | router_ip: 172.31.12.13; stack_ip: 172.31.12.14 |
| r2 | ether5 | sw2 | ether21 | MANAGEMENT_ACCESS | 130 | 1000 | — |
| ap1 | LAN | sw1 | ether24 | AP_TRUNK | 40, 110, 120, 130 | 1000 | — |
| ap2 | LAN | sw2 | ether24 | AP_TRUNK | 40, 110, 120, 130 | 1000 | — |
| sw1 | sfp-sfpplus1 | sw2 | sfp-sfpplus2 | STACK | 10, 20, 40, 110, 120, 130 | 10000 | — |
| sw1 | sfp-sfpplus2 | sw2 | sfp-sfpplus1 | STACK | 10, 20, 40, 110, 120, 130 | 10000 | — |


| Puesto | Switch | Puerto | IP PC | IP teléfono | Reserva Wi-Fi PC | Reserva Wi-Fi voz |
| --- | --- | --- | --- | --- | --- | --- |
| s12-pc01 | 1 | 1 | 10.70.12.10 | 10.70.76.10 | 10.81.12.10 | 10.82.12.10 |
| s12-pc02 | 2 | 1 | 10.70.12.11 | 10.70.76.11 | 10.81.12.11 | 10.82.12.11 |
| s12-pc03 | 1 | 2 | 10.70.12.12 | 10.70.76.12 | 10.81.12.12 | 10.82.12.12 |
| s12-pc04 | 2 | 2 | 10.70.12.13 | 10.70.76.13 | 10.81.12.13 | 10.82.12.13 |
| s12-pc05 | 1 | 3 | 10.70.12.14 | 10.70.76.14 | 10.81.12.14 | 10.82.12.14 |
| s12-pc06 | 2 | 3 | 10.70.12.15 | 10.70.76.15 | 10.81.12.15 | 10.82.12.15 |
| s12-pc07 | 1 | 4 | 10.70.12.16 | 10.70.76.16 | 10.81.12.16 | 10.82.12.16 |
| s12-pc08 | 2 | 4 | 10.70.12.17 | 10.70.76.17 | 10.81.12.17 | 10.82.12.17 |
| s12-pc09 | 1 | 5 | 10.70.12.18 | 10.70.76.18 | 10.81.12.18 | 10.82.12.18 |
| s12-pc10 | 2 | 5 | 10.70.12.19 | 10.70.76.19 | 10.81.12.19 | 10.82.12.19 |
| s12-pc11 | 1 | 6 | 10.70.12.20 | 10.70.76.20 | 10.81.12.20 | 10.82.12.20 |
| s12-pc12 | 2 | 6 | 10.70.12.21 | 10.70.76.21 | 10.81.12.21 | 10.82.12.21 |
| s12-pc13 | 1 | 7 | 10.70.12.22 | 10.70.76.22 | 10.81.12.22 | 10.82.12.22 |
| s12-pc14 | 2 | 7 | 10.70.12.23 | 10.70.76.23 | 10.81.12.23 | 10.82.12.23 |
| s12-pc15 | 1 | 8 | 10.70.12.24 | 10.70.76.24 | 10.81.12.24 | 10.82.12.24 |
| s12-pc16 | 2 | 8 | 10.70.12.25 | 10.70.76.25 | 10.81.12.25 | 10.82.12.25 |
| s12-pc17 | 1 | 9 | 10.70.12.26 | 10.70.76.26 | 10.81.12.26 | 10.82.12.26 |
| s12-pc18 | 2 | 9 | 10.70.12.27 | 10.70.76.27 | 10.81.12.27 | 10.82.12.27 |
| s12-pc19 | 1 | 10 | 10.70.12.28 | 10.70.76.28 | 10.81.12.28 | 10.82.12.28 |
| s12-pc20 | 2 | 10 | 10.70.12.29 | 10.70.76.29 | 10.81.12.29 | 10.82.12.29 |
| s12-pc21 | 1 | 11 | 10.70.12.30 | 10.70.76.30 | 10.81.12.30 | 10.82.12.30 |
| s12-pc22 | 2 | 11 | 10.70.12.31 | 10.70.76.31 | 10.81.12.31 | 10.82.12.31 |
| s12-pc23 | 1 | 12 | 10.70.12.32 | 10.70.76.32 | 10.81.12.32 | 10.82.12.32 |
| s12-pc24 | 2 | 12 | 10.70.12.33 | 10.70.76.33 | 10.81.12.33 | 10.82.12.33 |
| s12-pc25 | 1 | 13 | 10.70.12.34 | 10.70.76.34 | 10.81.12.34 | 10.82.12.34 |
| s12-pc26 | 2 | 13 | 10.70.12.35 | 10.70.76.35 | 10.81.12.35 | 10.82.12.35 |
| s12-pc27 | 1 | 14 | 10.70.12.36 | 10.70.76.36 | 10.81.12.36 | 10.82.12.36 |
| s12-pc28 | 2 | 14 | 10.70.12.37 | 10.70.76.37 | 10.81.12.37 | 10.82.12.37 |


**Transporte starlink — VLAN 201 — wanA.**

| Rol de entrega | Dirección |
| --- | --- |
| network | 10.252.12.0/29 |
| cpe | 10.252.12.1 |
| r1 | 10.252.12.2 |
| r2 | 10.252.12.3 |


**Transporte leo — VLAN 202 — wanB.**

| Rol de entrega | Dirección |
| --- | --- |
| network | 10.252.12.8/29 |
| cpe | 10.252.12.9 |
| r1 | 10.252.12.10 |
| r2 | 10.252.12.11 |


**Transporte entel5g — VLAN 203 — wanA.**

| Rol de entrega | Dirección |
| --- | --- |
| network | 10.252.12.16/29 |
| cpe | 10.252.12.17 |
| r1 | 10.252.12.18 |
| r2 | 10.252.12.19 |


**Transporte wom4g — VLAN 204 — wanB.**

| Rol de entrega | Dirección |
| --- | --- |
| network | 10.252.12.24/29 |
| cpe | 10.252.12.25 |
| r1 | 10.252.12.26 |
| r2 | 10.252.12.27 |


**Reservas de túneles (numeración según lista de la ficha).**

| Rol / candidato | Dirección |
| --- | --- |
| .1.hub_public_ip | 198.51.100.4 |
| .1.network | 10.253.12.0/30 |
| .1.branch_ip | 10.253.12.1 |
| .1.hub_ip | 10.253.12.2 |
| .2.hub_public_ip | 203.0.113.4 |
| .2.network | 10.253.12.4/30 |
| .2.branch_ip | 10.253.12.5 |
| .2.hub_ip | 10.253.12.6 |
| .3.hub_public_ip | 198.51.100.4 |
| .3.network | 10.253.12.8/30 |
| .3.branch_ip | 10.253.12.9 |
| .3.hub_ip | 10.253.12.10 |
| .4.hub_public_ip | 203.0.113.4 |
| .4.network | 10.253.12.12/30 |
| .4.branch_ip | 10.253.12.13 |
| .4.hub_ip | 10.253.12.14 |
| .5.hub_public_ip | 198.51.100.4 |
| .5.network | 10.253.12.16/30 |
| .5.branch_ip | 10.253.12.17 |
| .5.hub_ip | 10.253.12.18 |
| .6.hub_public_ip | 203.0.113.4 |
| .6.network | 10.253.12.20/30 |
| .6.branch_ip | 10.253.12.21 |
| .6.hub_ip | 10.253.12.22 |
| .7.hub_public_ip | 198.51.100.4 |
| .7.network | 10.253.12.24/30 |
| .7.branch_ip | 10.253.12.25 |
| .7.hub_ip | 10.253.12.26 |
| .8.hub_public_ip | 203.0.113.4 |
| .8.network | 10.253.12.28/30 |
| .8.branch_ip | 10.253.12.29 |
| .8.hub_ip | 10.253.12.30 |
| .9.hub_public_ip | 198.51.100.4 |
| .9.network | 10.253.12.32/30 |
| .9.branch_ip | 10.253.12.33 |
| .9.hub_ip | 10.253.12.34 |
| .10.hub_public_ip | 203.0.113.4 |
| .10.network | 10.253.12.36/30 |
| .10.branch_ip | 10.253.12.37 |
| .10.hub_ip | 10.253.12.38 |
| .11.hub_public_ip | 198.51.100.4 |
| .11.network | 10.253.12.40/30 |
| .11.branch_ip | 10.253.12.41 |
| .11.hub_ip | 10.253.12.42 |
| .12.hub_public_ip | 203.0.113.4 |
| .12.network | 10.253.12.44/30 |
| .12.branch_ip | 10.253.12.45 |
| .12.hub_ip | 10.253.12.46 |
| .13.hub_public_ip | 198.51.100.4 |
| .13.network | 10.253.12.48/30 |
| .13.branch_ip | 10.253.12.49 |
| .13.hub_ip | 10.253.12.50 |
| .14.hub_public_ip | 203.0.113.4 |
| .14.network | 10.253.12.52/30 |
| .14.branch_ip | 10.253.12.53 |
| .14.hub_ip | 10.253.12.54 |
| .15.hub_public_ip | 198.51.100.4 |
| .15.network | 10.253.12.56/30 |
| .15.branch_ip | 10.253.12.57 |
| .15.hub_ip | 10.253.12.58 |
| .16.hub_public_ip | 203.0.113.4 |
| .16.network | 10.253.12.60/30 |
| .16.branch_ip | 10.253.12.61 |
| .16.hub_ip | 10.253.12.62 |

### S13 — Talca

28 PCs y 28 teléfonos existentes.

| Función | ANTES | DESPUÉS |
| --- | --- | --- |
| Routers | 1 × ISR4321/K9 | 2 × CCR2004-16G-2S+ |
| Switches | 1 × C9200L-48P-4G-E | CRS328-24P-4S+RM + CRS328-24P-4S+RM |
| Firewall | Sin equipo dedicado | Sin appliance remoto; seguridad central |
| Distribución WAN | MPLS y accesos ISP del escenario base | wanA: E50UG; wanB: E50UG |


| Red | VLAN | Subred | Gateway / roles |
| --- | --- | --- | --- |
| users | 10 | 10.70.13.0/25 | 10.70.13.1 |
| voice | 20 | 10.70.77.0/25 | 10.70.77.1 |
| guests | 40 | 10.70.109.0/26 | 10.70.109.1 |
| wifi_users | 110 | 10.81.13.0/25 | 10.81.13.1 |
| wifi_voice | 120 | 10.82.13.0/25 | 10.82.13.1 |
| management | 130 | 10.80.13.0/27 | 10.80.13.1 |


| Gestión | Dirección |
| --- | --- |
| sw1 | 10.80.13.2 |
| sw2 | 10.80.13.3 |
| r1 | 10.80.13.4 |
| r2 | 10.80.13.5 |
| wanA | 10.80.13.6 |
| wanB | 10.80.13.7 |
| ap1 | 10.80.13.24 |
| ap2 | 10.80.13.25 |


| Origen | Puerto | Destino | Puerto | Función | VLAN/red | Mbps | IP / agregado lógico |
| --- | --- | --- | --- | --- | --- | --- | --- |
| cpe:starlink | LAN | wanA | ether1 | WAN_ACCESS | 201 | 1000 | — |
| cpe:entel5g | LAN | wanA | ether2 | WAN_ACCESS | 203 | 1000 | — |
| r1 | ether1 | wanA | ether3 | WAN_TRUNK | 201, 203 | 1000 | — |
| r2 | ether1 | wanA | ether4 | WAN_TRUNK | 201, 203 | 1000 | — |
| wanA | ether5 | sw1 | ether22 | MANAGEMENT_ACCESS | 130 | 1000 | — |
| cpe:leo | LAN | wanB | ether1 | WAN_ACCESS | 202 | 1000 | — |
| cpe:wom4g | LAN | wanB | ether2 | WAN_ACCESS | 204 | 1000 | — |
| r1 | ether2 | wanB | ether3 | WAN_TRUNK | 202, 204 | 1000 | — |
| r2 | ether2 | wanB | ether4 | WAN_TRUNK | 202, 204 | 1000 | — |
| wanB | ether5 | sw2 | ether22 | MANAGEMENT_ACCESS | 130 | 1000 | — |
| r1 | ether3 | sw1 | ether19 | LAN_ROUTED | 172.31.13.0/30 | 1000 | router_ip: 172.31.13.1; stack_ip: 172.31.13.2 |
| r1 | ether4 | sw2 | ether19 | LAN_ROUTED | 172.31.13.4/30 | 1000 | router_ip: 172.31.13.5; stack_ip: 172.31.13.6 |
| r1 | ether5 | sw1 | ether21 | MANAGEMENT_ACCESS | 130 | 1000 | — |
| r2 | ether3 | sw1 | ether20 | LAN_ROUTED | 172.31.13.8/30 | 1000 | router_ip: 172.31.13.9; stack_ip: 172.31.13.10 |
| r2 | ether4 | sw2 | ether20 | LAN_ROUTED | 172.31.13.12/30 | 1000 | router_ip: 172.31.13.13; stack_ip: 172.31.13.14 |
| r2 | ether5 | sw2 | ether21 | MANAGEMENT_ACCESS | 130 | 1000 | — |
| ap1 | LAN | sw1 | ether24 | AP_TRUNK | 40, 110, 120, 130 | 1000 | — |
| ap2 | LAN | sw2 | ether24 | AP_TRUNK | 40, 110, 120, 130 | 1000 | — |
| sw1 | sfp-sfpplus1 | sw2 | sfp-sfpplus2 | STACK | 10, 20, 40, 110, 120, 130 | 10000 | — |
| sw1 | sfp-sfpplus2 | sw2 | sfp-sfpplus1 | STACK | 10, 20, 40, 110, 120, 130 | 10000 | — |


| Puesto | Switch | Puerto | IP PC | IP teléfono | Reserva Wi-Fi PC | Reserva Wi-Fi voz |
| --- | --- | --- | --- | --- | --- | --- |
| s13-pc01 | 1 | 1 | 10.70.13.10 | 10.70.77.10 | 10.81.13.10 | 10.82.13.10 |
| s13-pc02 | 2 | 1 | 10.70.13.11 | 10.70.77.11 | 10.81.13.11 | 10.82.13.11 |
| s13-pc03 | 1 | 2 | 10.70.13.12 | 10.70.77.12 | 10.81.13.12 | 10.82.13.12 |
| s13-pc04 | 2 | 2 | 10.70.13.13 | 10.70.77.13 | 10.81.13.13 | 10.82.13.13 |
| s13-pc05 | 1 | 3 | 10.70.13.14 | 10.70.77.14 | 10.81.13.14 | 10.82.13.14 |
| s13-pc06 | 2 | 3 | 10.70.13.15 | 10.70.77.15 | 10.81.13.15 | 10.82.13.15 |
| s13-pc07 | 1 | 4 | 10.70.13.16 | 10.70.77.16 | 10.81.13.16 | 10.82.13.16 |
| s13-pc08 | 2 | 4 | 10.70.13.17 | 10.70.77.17 | 10.81.13.17 | 10.82.13.17 |
| s13-pc09 | 1 | 5 | 10.70.13.18 | 10.70.77.18 | 10.81.13.18 | 10.82.13.18 |
| s13-pc10 | 2 | 5 | 10.70.13.19 | 10.70.77.19 | 10.81.13.19 | 10.82.13.19 |
| s13-pc11 | 1 | 6 | 10.70.13.20 | 10.70.77.20 | 10.81.13.20 | 10.82.13.20 |
| s13-pc12 | 2 | 6 | 10.70.13.21 | 10.70.77.21 | 10.81.13.21 | 10.82.13.21 |
| s13-pc13 | 1 | 7 | 10.70.13.22 | 10.70.77.22 | 10.81.13.22 | 10.82.13.22 |
| s13-pc14 | 2 | 7 | 10.70.13.23 | 10.70.77.23 | 10.81.13.23 | 10.82.13.23 |
| s13-pc15 | 1 | 8 | 10.70.13.24 | 10.70.77.24 | 10.81.13.24 | 10.82.13.24 |
| s13-pc16 | 2 | 8 | 10.70.13.25 | 10.70.77.25 | 10.81.13.25 | 10.82.13.25 |
| s13-pc17 | 1 | 9 | 10.70.13.26 | 10.70.77.26 | 10.81.13.26 | 10.82.13.26 |
| s13-pc18 | 2 | 9 | 10.70.13.27 | 10.70.77.27 | 10.81.13.27 | 10.82.13.27 |
| s13-pc19 | 1 | 10 | 10.70.13.28 | 10.70.77.28 | 10.81.13.28 | 10.82.13.28 |
| s13-pc20 | 2 | 10 | 10.70.13.29 | 10.70.77.29 | 10.81.13.29 | 10.82.13.29 |
| s13-pc21 | 1 | 11 | 10.70.13.30 | 10.70.77.30 | 10.81.13.30 | 10.82.13.30 |
| s13-pc22 | 2 | 11 | 10.70.13.31 | 10.70.77.31 | 10.81.13.31 | 10.82.13.31 |
| s13-pc23 | 1 | 12 | 10.70.13.32 | 10.70.77.32 | 10.81.13.32 | 10.82.13.32 |
| s13-pc24 | 2 | 12 | 10.70.13.33 | 10.70.77.33 | 10.81.13.33 | 10.82.13.33 |
| s13-pc25 | 1 | 13 | 10.70.13.34 | 10.70.77.34 | 10.81.13.34 | 10.82.13.34 |
| s13-pc26 | 2 | 13 | 10.70.13.35 | 10.70.77.35 | 10.81.13.35 | 10.82.13.35 |
| s13-pc27 | 1 | 14 | 10.70.13.36 | 10.70.77.36 | 10.81.13.36 | 10.82.13.36 |
| s13-pc28 | 2 | 14 | 10.70.13.37 | 10.70.77.37 | 10.81.13.37 | 10.82.13.37 |


**Transporte starlink — VLAN 201 — wanA.**

| Rol de entrega | Dirección |
| --- | --- |
| network | 10.252.13.0/29 |
| cpe | 10.252.13.1 |
| r1 | 10.252.13.2 |
| r2 | 10.252.13.3 |


**Transporte leo — VLAN 202 — wanB.**

| Rol de entrega | Dirección |
| --- | --- |
| network | 10.252.13.8/29 |
| cpe | 10.252.13.9 |
| r1 | 10.252.13.10 |
| r2 | 10.252.13.11 |


**Transporte entel5g — VLAN 203 — wanA.**

| Rol de entrega | Dirección |
| --- | --- |
| network | 10.252.13.16/29 |
| cpe | 10.252.13.17 |
| r1 | 10.252.13.18 |
| r2 | 10.252.13.19 |


**Transporte wom4g — VLAN 204 — wanB.**

| Rol de entrega | Dirección |
| --- | --- |
| network | 10.252.13.24/29 |
| cpe | 10.252.13.25 |
| r1 | 10.252.13.26 |
| r2 | 10.252.13.27 |


**Reservas de túneles (numeración según lista de la ficha).**

| Rol / candidato | Dirección |
| --- | --- |
| .1.hub_public_ip | 198.51.100.4 |
| .1.network | 10.253.13.0/30 |
| .1.branch_ip | 10.253.13.1 |
| .1.hub_ip | 10.253.13.2 |
| .2.hub_public_ip | 203.0.113.4 |
| .2.network | 10.253.13.4/30 |
| .2.branch_ip | 10.253.13.5 |
| .2.hub_ip | 10.253.13.6 |
| .3.hub_public_ip | 198.51.100.4 |
| .3.network | 10.253.13.8/30 |
| .3.branch_ip | 10.253.13.9 |
| .3.hub_ip | 10.253.13.10 |
| .4.hub_public_ip | 203.0.113.4 |
| .4.network | 10.253.13.12/30 |
| .4.branch_ip | 10.253.13.13 |
| .4.hub_ip | 10.253.13.14 |
| .5.hub_public_ip | 198.51.100.4 |
| .5.network | 10.253.13.16/30 |
| .5.branch_ip | 10.253.13.17 |
| .5.hub_ip | 10.253.13.18 |
| .6.hub_public_ip | 203.0.113.4 |
| .6.network | 10.253.13.20/30 |
| .6.branch_ip | 10.253.13.21 |
| .6.hub_ip | 10.253.13.22 |
| .7.hub_public_ip | 198.51.100.4 |
| .7.network | 10.253.13.24/30 |
| .7.branch_ip | 10.253.13.25 |
| .7.hub_ip | 10.253.13.26 |
| .8.hub_public_ip | 203.0.113.4 |
| .8.network | 10.253.13.28/30 |
| .8.branch_ip | 10.253.13.29 |
| .8.hub_ip | 10.253.13.30 |
| .9.hub_public_ip | 198.51.100.4 |
| .9.network | 10.253.13.32/30 |
| .9.branch_ip | 10.253.13.33 |
| .9.hub_ip | 10.253.13.34 |
| .10.hub_public_ip | 203.0.113.4 |
| .10.network | 10.253.13.36/30 |
| .10.branch_ip | 10.253.13.37 |
| .10.hub_ip | 10.253.13.38 |
| .11.hub_public_ip | 198.51.100.4 |
| .11.network | 10.253.13.40/30 |
| .11.branch_ip | 10.253.13.41 |
| .11.hub_ip | 10.253.13.42 |
| .12.hub_public_ip | 203.0.113.4 |
| .12.network | 10.253.13.44/30 |
| .12.branch_ip | 10.253.13.45 |
| .12.hub_ip | 10.253.13.46 |
| .13.hub_public_ip | 198.51.100.4 |
| .13.network | 10.253.13.48/30 |
| .13.branch_ip | 10.253.13.49 |
| .13.hub_ip | 10.253.13.50 |
| .14.hub_public_ip | 203.0.113.4 |
| .14.network | 10.253.13.52/30 |
| .14.branch_ip | 10.253.13.53 |
| .14.hub_ip | 10.253.13.54 |
| .15.hub_public_ip | 198.51.100.4 |
| .15.network | 10.253.13.56/30 |
| .15.branch_ip | 10.253.13.57 |
| .15.hub_ip | 10.253.13.58 |
| .16.hub_public_ip | 203.0.113.4 |
| .16.network | 10.253.13.60/30 |
| .16.branch_ip | 10.253.13.61 |
| .16.hub_ip | 10.253.13.62 |

### S14 — Chillán

28 PCs y 28 teléfonos existentes.

| Función | ANTES | DESPUÉS |
| --- | --- | --- |
| Routers | 1 × C1121X-8P | 2 × CCR2004-16G-2S+ |
| Switches | 1 × C9200L-48P-4G-E | CRS328-24P-4S+RM + CRS328-24P-4S+RM |
| Firewall | Sin equipo dedicado | Sin appliance remoto; seguridad central |
| Distribución WAN | MPLS y accesos ISP del escenario base | wanA: E50UG; wanB: E50UG |


| Red | VLAN | Subred | Gateway / roles |
| --- | --- | --- | --- |
| users | 10 | 10.70.14.0/25 | 10.70.14.1 |
| voice | 20 | 10.70.78.0/25 | 10.70.78.1 |
| guests | 40 | 10.70.110.0/26 | 10.70.110.1 |
| wifi_users | 110 | 10.81.14.0/25 | 10.81.14.1 |
| wifi_voice | 120 | 10.82.14.0/25 | 10.82.14.1 |
| management | 130 | 10.80.14.0/27 | 10.80.14.1 |


| Gestión | Dirección |
| --- | --- |
| sw1 | 10.80.14.2 |
| sw2 | 10.80.14.3 |
| r1 | 10.80.14.4 |
| r2 | 10.80.14.5 |
| wanA | 10.80.14.6 |
| wanB | 10.80.14.7 |
| ap1 | 10.80.14.24 |
| ap2 | 10.80.14.25 |


| Origen | Puerto | Destino | Puerto | Función | VLAN/red | Mbps | IP / agregado lógico |
| --- | --- | --- | --- | --- | --- | --- | --- |
| cpe:starlink | LAN | wanA | ether1 | WAN_ACCESS | 201 | 1000 | — |
| cpe:entel5g | LAN | wanA | ether2 | WAN_ACCESS | 203 | 1000 | — |
| r1 | ether1 | wanA | ether3 | WAN_TRUNK | 201, 203 | 1000 | — |
| r2 | ether1 | wanA | ether4 | WAN_TRUNK | 201, 203 | 1000 | — |
| wanA | ether5 | sw1 | ether22 | MANAGEMENT_ACCESS | 130 | 1000 | — |
| cpe:leo | LAN | wanB | ether1 | WAN_ACCESS | 202 | 1000 | — |
| cpe:wom4g | LAN | wanB | ether2 | WAN_ACCESS | 204 | 1000 | — |
| r1 | ether2 | wanB | ether3 | WAN_TRUNK | 202, 204 | 1000 | — |
| r2 | ether2 | wanB | ether4 | WAN_TRUNK | 202, 204 | 1000 | — |
| wanB | ether5 | sw2 | ether22 | MANAGEMENT_ACCESS | 130 | 1000 | — |
| r1 | ether3 | sw1 | ether19 | LAN_ROUTED | 172.31.14.0/30 | 1000 | router_ip: 172.31.14.1; stack_ip: 172.31.14.2 |
| r1 | ether4 | sw2 | ether19 | LAN_ROUTED | 172.31.14.4/30 | 1000 | router_ip: 172.31.14.5; stack_ip: 172.31.14.6 |
| r1 | ether5 | sw1 | ether21 | MANAGEMENT_ACCESS | 130 | 1000 | — |
| r2 | ether3 | sw1 | ether20 | LAN_ROUTED | 172.31.14.8/30 | 1000 | router_ip: 172.31.14.9; stack_ip: 172.31.14.10 |
| r2 | ether4 | sw2 | ether20 | LAN_ROUTED | 172.31.14.12/30 | 1000 | router_ip: 172.31.14.13; stack_ip: 172.31.14.14 |
| r2 | ether5 | sw2 | ether21 | MANAGEMENT_ACCESS | 130 | 1000 | — |
| ap1 | LAN | sw1 | ether24 | AP_TRUNK | 40, 110, 120, 130 | 1000 | — |
| ap2 | LAN | sw2 | ether24 | AP_TRUNK | 40, 110, 120, 130 | 1000 | — |
| sw1 | sfp-sfpplus1 | sw2 | sfp-sfpplus2 | STACK | 10, 20, 40, 110, 120, 130 | 10000 | — |
| sw1 | sfp-sfpplus2 | sw2 | sfp-sfpplus1 | STACK | 10, 20, 40, 110, 120, 130 | 10000 | — |


| Puesto | Switch | Puerto | IP PC | IP teléfono | Reserva Wi-Fi PC | Reserva Wi-Fi voz |
| --- | --- | --- | --- | --- | --- | --- |
| s14-pc01 | 1 | 1 | 10.70.14.10 | 10.70.78.10 | 10.81.14.10 | 10.82.14.10 |
| s14-pc02 | 2 | 1 | 10.70.14.11 | 10.70.78.11 | 10.81.14.11 | 10.82.14.11 |
| s14-pc03 | 1 | 2 | 10.70.14.12 | 10.70.78.12 | 10.81.14.12 | 10.82.14.12 |
| s14-pc04 | 2 | 2 | 10.70.14.13 | 10.70.78.13 | 10.81.14.13 | 10.82.14.13 |
| s14-pc05 | 1 | 3 | 10.70.14.14 | 10.70.78.14 | 10.81.14.14 | 10.82.14.14 |
| s14-pc06 | 2 | 3 | 10.70.14.15 | 10.70.78.15 | 10.81.14.15 | 10.82.14.15 |
| s14-pc07 | 1 | 4 | 10.70.14.16 | 10.70.78.16 | 10.81.14.16 | 10.82.14.16 |
| s14-pc08 | 2 | 4 | 10.70.14.17 | 10.70.78.17 | 10.81.14.17 | 10.82.14.17 |
| s14-pc09 | 1 | 5 | 10.70.14.18 | 10.70.78.18 | 10.81.14.18 | 10.82.14.18 |
| s14-pc10 | 2 | 5 | 10.70.14.19 | 10.70.78.19 | 10.81.14.19 | 10.82.14.19 |
| s14-pc11 | 1 | 6 | 10.70.14.20 | 10.70.78.20 | 10.81.14.20 | 10.82.14.20 |
| s14-pc12 | 2 | 6 | 10.70.14.21 | 10.70.78.21 | 10.81.14.21 | 10.82.14.21 |
| s14-pc13 | 1 | 7 | 10.70.14.22 | 10.70.78.22 | 10.81.14.22 | 10.82.14.22 |
| s14-pc14 | 2 | 7 | 10.70.14.23 | 10.70.78.23 | 10.81.14.23 | 10.82.14.23 |
| s14-pc15 | 1 | 8 | 10.70.14.24 | 10.70.78.24 | 10.81.14.24 | 10.82.14.24 |
| s14-pc16 | 2 | 8 | 10.70.14.25 | 10.70.78.25 | 10.81.14.25 | 10.82.14.25 |
| s14-pc17 | 1 | 9 | 10.70.14.26 | 10.70.78.26 | 10.81.14.26 | 10.82.14.26 |
| s14-pc18 | 2 | 9 | 10.70.14.27 | 10.70.78.27 | 10.81.14.27 | 10.82.14.27 |
| s14-pc19 | 1 | 10 | 10.70.14.28 | 10.70.78.28 | 10.81.14.28 | 10.82.14.28 |
| s14-pc20 | 2 | 10 | 10.70.14.29 | 10.70.78.29 | 10.81.14.29 | 10.82.14.29 |
| s14-pc21 | 1 | 11 | 10.70.14.30 | 10.70.78.30 | 10.81.14.30 | 10.82.14.30 |
| s14-pc22 | 2 | 11 | 10.70.14.31 | 10.70.78.31 | 10.81.14.31 | 10.82.14.31 |
| s14-pc23 | 1 | 12 | 10.70.14.32 | 10.70.78.32 | 10.81.14.32 | 10.82.14.32 |
| s14-pc24 | 2 | 12 | 10.70.14.33 | 10.70.78.33 | 10.81.14.33 | 10.82.14.33 |
| s14-pc25 | 1 | 13 | 10.70.14.34 | 10.70.78.34 | 10.81.14.34 | 10.82.14.34 |
| s14-pc26 | 2 | 13 | 10.70.14.35 | 10.70.78.35 | 10.81.14.35 | 10.82.14.35 |
| s14-pc27 | 1 | 14 | 10.70.14.36 | 10.70.78.36 | 10.81.14.36 | 10.82.14.36 |
| s14-pc28 | 2 | 14 | 10.70.14.37 | 10.70.78.37 | 10.81.14.37 | 10.82.14.37 |


**Transporte starlink — VLAN 201 — wanA.**

| Rol de entrega | Dirección |
| --- | --- |
| network | 10.252.14.0/29 |
| cpe | 10.252.14.1 |
| r1 | 10.252.14.2 |
| r2 | 10.252.14.3 |


**Transporte leo — VLAN 202 — wanB.**

| Rol de entrega | Dirección |
| --- | --- |
| network | 10.252.14.8/29 |
| cpe | 10.252.14.9 |
| r1 | 10.252.14.10 |
| r2 | 10.252.14.11 |


**Transporte entel5g — VLAN 203 — wanA.**

| Rol de entrega | Dirección |
| --- | --- |
| network | 10.252.14.16/29 |
| cpe | 10.252.14.17 |
| r1 | 10.252.14.18 |
| r2 | 10.252.14.19 |


**Transporte wom4g — VLAN 204 — wanB.**

| Rol de entrega | Dirección |
| --- | --- |
| network | 10.252.14.24/29 |
| cpe | 10.252.14.25 |
| r1 | 10.252.14.26 |
| r2 | 10.252.14.27 |


**Reservas de túneles (numeración según lista de la ficha).**

| Rol / candidato | Dirección |
| --- | --- |
| .1.hub_public_ip | 198.51.100.4 |
| .1.network | 10.253.14.0/30 |
| .1.branch_ip | 10.253.14.1 |
| .1.hub_ip | 10.253.14.2 |
| .2.hub_public_ip | 203.0.113.4 |
| .2.network | 10.253.14.4/30 |
| .2.branch_ip | 10.253.14.5 |
| .2.hub_ip | 10.253.14.6 |
| .3.hub_public_ip | 198.51.100.4 |
| .3.network | 10.253.14.8/30 |
| .3.branch_ip | 10.253.14.9 |
| .3.hub_ip | 10.253.14.10 |
| .4.hub_public_ip | 203.0.113.4 |
| .4.network | 10.253.14.12/30 |
| .4.branch_ip | 10.253.14.13 |
| .4.hub_ip | 10.253.14.14 |
| .5.hub_public_ip | 198.51.100.4 |
| .5.network | 10.253.14.16/30 |
| .5.branch_ip | 10.253.14.17 |
| .5.hub_ip | 10.253.14.18 |
| .6.hub_public_ip | 203.0.113.4 |
| .6.network | 10.253.14.20/30 |
| .6.branch_ip | 10.253.14.21 |
| .6.hub_ip | 10.253.14.22 |
| .7.hub_public_ip | 198.51.100.4 |
| .7.network | 10.253.14.24/30 |
| .7.branch_ip | 10.253.14.25 |
| .7.hub_ip | 10.253.14.26 |
| .8.hub_public_ip | 203.0.113.4 |
| .8.network | 10.253.14.28/30 |
| .8.branch_ip | 10.253.14.29 |
| .8.hub_ip | 10.253.14.30 |
| .9.hub_public_ip | 198.51.100.4 |
| .9.network | 10.253.14.32/30 |
| .9.branch_ip | 10.253.14.33 |
| .9.hub_ip | 10.253.14.34 |
| .10.hub_public_ip | 203.0.113.4 |
| .10.network | 10.253.14.36/30 |
| .10.branch_ip | 10.253.14.37 |
| .10.hub_ip | 10.253.14.38 |
| .11.hub_public_ip | 198.51.100.4 |
| .11.network | 10.253.14.40/30 |
| .11.branch_ip | 10.253.14.41 |
| .11.hub_ip | 10.253.14.42 |
| .12.hub_public_ip | 203.0.113.4 |
| .12.network | 10.253.14.44/30 |
| .12.branch_ip | 10.253.14.45 |
| .12.hub_ip | 10.253.14.46 |
| .13.hub_public_ip | 198.51.100.4 |
| .13.network | 10.253.14.48/30 |
| .13.branch_ip | 10.253.14.49 |
| .13.hub_ip | 10.253.14.50 |
| .14.hub_public_ip | 203.0.113.4 |
| .14.network | 10.253.14.52/30 |
| .14.branch_ip | 10.253.14.53 |
| .14.hub_ip | 10.253.14.54 |
| .15.hub_public_ip | 198.51.100.4 |
| .15.network | 10.253.14.56/30 |
| .15.branch_ip | 10.253.14.57 |
| .15.hub_ip | 10.253.14.58 |
| .16.hub_public_ip | 203.0.113.4 |
| .16.network | 10.253.14.60/30 |
| .16.branch_ip | 10.253.14.61 |
| .16.hub_ip | 10.253.14.62 |

### S15 — Concepción

28 PCs y 28 teléfonos existentes.

| Función | ANTES | DESPUÉS |
| --- | --- | --- |
| Routers | 1 × CISCO1921-SEC/K9 | 2 × CCR2004-16G-2S+ |
| Switches | 1 × WS-C2960S-48LPS-L | CRS328-24P-4S+RM + CRS328-24P-4S+RM |
| Firewall | Sin equipo dedicado | Sin appliance remoto; seguridad central |
| Distribución WAN | MPLS y accesos ISP del escenario base | wanA: E50UG; wanB: E50UG |


| Red | VLAN | Subred | Gateway / roles |
| --- | --- | --- | --- |
| users | 10 | 10.70.15.0/25 | 10.70.15.1 |
| voice | 20 | 10.70.79.0/25 | 10.70.79.1 |
| guests | 40 | 10.70.111.0/26 | 10.70.111.1 |
| wifi_users | 110 | 10.81.15.0/25 | 10.81.15.1 |
| wifi_voice | 120 | 10.82.15.0/25 | 10.82.15.1 |
| management | 130 | 10.80.15.0/27 | 10.80.15.1 |


| Gestión | Dirección |
| --- | --- |
| sw1 | 10.80.15.2 |
| sw2 | 10.80.15.3 |
| r1 | 10.80.15.4 |
| r2 | 10.80.15.5 |
| wanA | 10.80.15.6 |
| wanB | 10.80.15.7 |
| ap1 | 10.80.15.24 |
| ap2 | 10.80.15.25 |


| Origen | Puerto | Destino | Puerto | Función | VLAN/red | Mbps | IP / agregado lógico |
| --- | --- | --- | --- | --- | --- | --- | --- |
| cpe:starlink | LAN | wanA | ether1 | WAN_ACCESS | 201 | 1000 | — |
| cpe:entel5g | LAN | wanA | ether2 | WAN_ACCESS | 203 | 1000 | — |
| r1 | ether1 | wanA | ether3 | WAN_TRUNK | 201, 203 | 1000 | — |
| r2 | ether1 | wanA | ether4 | WAN_TRUNK | 201, 203 | 1000 | — |
| wanA | ether5 | sw1 | ether22 | MANAGEMENT_ACCESS | 130 | 1000 | — |
| cpe:leo | LAN | wanB | ether1 | WAN_ACCESS | 202 | 1000 | — |
| cpe:wom4g | LAN | wanB | ether2 | WAN_ACCESS | 204 | 1000 | — |
| r1 | ether2 | wanB | ether3 | WAN_TRUNK | 202, 204 | 1000 | — |
| r2 | ether2 | wanB | ether4 | WAN_TRUNK | 202, 204 | 1000 | — |
| wanB | ether5 | sw2 | ether22 | MANAGEMENT_ACCESS | 130 | 1000 | — |
| r1 | ether3 | sw1 | ether19 | LAN_ROUTED | 172.31.15.0/30 | 1000 | router_ip: 172.31.15.1; stack_ip: 172.31.15.2 |
| r1 | ether4 | sw2 | ether19 | LAN_ROUTED | 172.31.15.4/30 | 1000 | router_ip: 172.31.15.5; stack_ip: 172.31.15.6 |
| r1 | ether5 | sw1 | ether21 | MANAGEMENT_ACCESS | 130 | 1000 | — |
| r2 | ether3 | sw1 | ether20 | LAN_ROUTED | 172.31.15.8/30 | 1000 | router_ip: 172.31.15.9; stack_ip: 172.31.15.10 |
| r2 | ether4 | sw2 | ether20 | LAN_ROUTED | 172.31.15.12/30 | 1000 | router_ip: 172.31.15.13; stack_ip: 172.31.15.14 |
| r2 | ether5 | sw2 | ether21 | MANAGEMENT_ACCESS | 130 | 1000 | — |
| ap1 | LAN | sw1 | ether24 | AP_TRUNK | 40, 110, 120, 130 | 1000 | — |
| ap2 | LAN | sw2 | ether24 | AP_TRUNK | 40, 110, 120, 130 | 1000 | — |
| sw1 | sfp-sfpplus1 | sw2 | sfp-sfpplus2 | STACK | 10, 20, 40, 110, 120, 130 | 10000 | — |
| sw1 | sfp-sfpplus2 | sw2 | sfp-sfpplus1 | STACK | 10, 20, 40, 110, 120, 130 | 10000 | — |


| Puesto | Switch | Puerto | IP PC | IP teléfono | Reserva Wi-Fi PC | Reserva Wi-Fi voz |
| --- | --- | --- | --- | --- | --- | --- |
| s15-pc01 | 1 | 1 | 10.70.15.10 | 10.70.79.10 | 10.81.15.10 | 10.82.15.10 |
| s15-pc02 | 2 | 1 | 10.70.15.11 | 10.70.79.11 | 10.81.15.11 | 10.82.15.11 |
| s15-pc03 | 1 | 2 | 10.70.15.12 | 10.70.79.12 | 10.81.15.12 | 10.82.15.12 |
| s15-pc04 | 2 | 2 | 10.70.15.13 | 10.70.79.13 | 10.81.15.13 | 10.82.15.13 |
| s15-pc05 | 1 | 3 | 10.70.15.14 | 10.70.79.14 | 10.81.15.14 | 10.82.15.14 |
| s15-pc06 | 2 | 3 | 10.70.15.15 | 10.70.79.15 | 10.81.15.15 | 10.82.15.15 |
| s15-pc07 | 1 | 4 | 10.70.15.16 | 10.70.79.16 | 10.81.15.16 | 10.82.15.16 |
| s15-pc08 | 2 | 4 | 10.70.15.17 | 10.70.79.17 | 10.81.15.17 | 10.82.15.17 |
| s15-pc09 | 1 | 5 | 10.70.15.18 | 10.70.79.18 | 10.81.15.18 | 10.82.15.18 |
| s15-pc10 | 2 | 5 | 10.70.15.19 | 10.70.79.19 | 10.81.15.19 | 10.82.15.19 |
| s15-pc11 | 1 | 6 | 10.70.15.20 | 10.70.79.20 | 10.81.15.20 | 10.82.15.20 |
| s15-pc12 | 2 | 6 | 10.70.15.21 | 10.70.79.21 | 10.81.15.21 | 10.82.15.21 |
| s15-pc13 | 1 | 7 | 10.70.15.22 | 10.70.79.22 | 10.81.15.22 | 10.82.15.22 |
| s15-pc14 | 2 | 7 | 10.70.15.23 | 10.70.79.23 | 10.81.15.23 | 10.82.15.23 |
| s15-pc15 | 1 | 8 | 10.70.15.24 | 10.70.79.24 | 10.81.15.24 | 10.82.15.24 |
| s15-pc16 | 2 | 8 | 10.70.15.25 | 10.70.79.25 | 10.81.15.25 | 10.82.15.25 |
| s15-pc17 | 1 | 9 | 10.70.15.26 | 10.70.79.26 | 10.81.15.26 | 10.82.15.26 |
| s15-pc18 | 2 | 9 | 10.70.15.27 | 10.70.79.27 | 10.81.15.27 | 10.82.15.27 |
| s15-pc19 | 1 | 10 | 10.70.15.28 | 10.70.79.28 | 10.81.15.28 | 10.82.15.28 |
| s15-pc20 | 2 | 10 | 10.70.15.29 | 10.70.79.29 | 10.81.15.29 | 10.82.15.29 |
| s15-pc21 | 1 | 11 | 10.70.15.30 | 10.70.79.30 | 10.81.15.30 | 10.82.15.30 |
| s15-pc22 | 2 | 11 | 10.70.15.31 | 10.70.79.31 | 10.81.15.31 | 10.82.15.31 |
| s15-pc23 | 1 | 12 | 10.70.15.32 | 10.70.79.32 | 10.81.15.32 | 10.82.15.32 |
| s15-pc24 | 2 | 12 | 10.70.15.33 | 10.70.79.33 | 10.81.15.33 | 10.82.15.33 |
| s15-pc25 | 1 | 13 | 10.70.15.34 | 10.70.79.34 | 10.81.15.34 | 10.82.15.34 |
| s15-pc26 | 2 | 13 | 10.70.15.35 | 10.70.79.35 | 10.81.15.35 | 10.82.15.35 |
| s15-pc27 | 1 | 14 | 10.70.15.36 | 10.70.79.36 | 10.81.15.36 | 10.82.15.36 |
| s15-pc28 | 2 | 14 | 10.70.15.37 | 10.70.79.37 | 10.81.15.37 | 10.82.15.37 |


**Transporte starlink — VLAN 201 — wanA.**

| Rol de entrega | Dirección |
| --- | --- |
| network | 10.252.15.0/29 |
| cpe | 10.252.15.1 |
| r1 | 10.252.15.2 |
| r2 | 10.252.15.3 |


**Transporte leo — VLAN 202 — wanB.**

| Rol de entrega | Dirección |
| --- | --- |
| network | 10.252.15.8/29 |
| cpe | 10.252.15.9 |
| r1 | 10.252.15.10 |
| r2 | 10.252.15.11 |


**Transporte entel5g — VLAN 203 — wanA.**

| Rol de entrega | Dirección |
| --- | --- |
| network | 10.252.15.16/29 |
| cpe | 10.252.15.17 |
| r1 | 10.252.15.18 |
| r2 | 10.252.15.19 |


**Transporte wom4g — VLAN 204 — wanB.**

| Rol de entrega | Dirección |
| --- | --- |
| network | 10.252.15.24/29 |
| cpe | 10.252.15.25 |
| r1 | 10.252.15.26 |
| r2 | 10.252.15.27 |


**Reservas de túneles (numeración según lista de la ficha).**

| Rol / candidato | Dirección |
| --- | --- |
| .1.hub_public_ip | 198.51.100.4 |
| .1.network | 10.253.15.0/30 |
| .1.branch_ip | 10.253.15.1 |
| .1.hub_ip | 10.253.15.2 |
| .2.hub_public_ip | 203.0.113.4 |
| .2.network | 10.253.15.4/30 |
| .2.branch_ip | 10.253.15.5 |
| .2.hub_ip | 10.253.15.6 |
| .3.hub_public_ip | 198.51.100.4 |
| .3.network | 10.253.15.8/30 |
| .3.branch_ip | 10.253.15.9 |
| .3.hub_ip | 10.253.15.10 |
| .4.hub_public_ip | 203.0.113.4 |
| .4.network | 10.253.15.12/30 |
| .4.branch_ip | 10.253.15.13 |
| .4.hub_ip | 10.253.15.14 |
| .5.hub_public_ip | 198.51.100.4 |
| .5.network | 10.253.15.16/30 |
| .5.branch_ip | 10.253.15.17 |
| .5.hub_ip | 10.253.15.18 |
| .6.hub_public_ip | 203.0.113.4 |
| .6.network | 10.253.15.20/30 |
| .6.branch_ip | 10.253.15.21 |
| .6.hub_ip | 10.253.15.22 |
| .7.hub_public_ip | 198.51.100.4 |
| .7.network | 10.253.15.24/30 |
| .7.branch_ip | 10.253.15.25 |
| .7.hub_ip | 10.253.15.26 |
| .8.hub_public_ip | 203.0.113.4 |
| .8.network | 10.253.15.28/30 |
| .8.branch_ip | 10.253.15.29 |
| .8.hub_ip | 10.253.15.30 |
| .9.hub_public_ip | 198.51.100.4 |
| .9.network | 10.253.15.32/30 |
| .9.branch_ip | 10.253.15.33 |
| .9.hub_ip | 10.253.15.34 |
| .10.hub_public_ip | 203.0.113.4 |
| .10.network | 10.253.15.36/30 |
| .10.branch_ip | 10.253.15.37 |
| .10.hub_ip | 10.253.15.38 |
| .11.hub_public_ip | 198.51.100.4 |
| .11.network | 10.253.15.40/30 |
| .11.branch_ip | 10.253.15.41 |
| .11.hub_ip | 10.253.15.42 |
| .12.hub_public_ip | 203.0.113.4 |
| .12.network | 10.253.15.44/30 |
| .12.branch_ip | 10.253.15.45 |
| .12.hub_ip | 10.253.15.46 |
| .13.hub_public_ip | 198.51.100.4 |
| .13.network | 10.253.15.48/30 |
| .13.branch_ip | 10.253.15.49 |
| .13.hub_ip | 10.253.15.50 |
| .14.hub_public_ip | 203.0.113.4 |
| .14.network | 10.253.15.52/30 |
| .14.branch_ip | 10.253.15.53 |
| .14.hub_ip | 10.253.15.54 |
| .15.hub_public_ip | 198.51.100.4 |
| .15.network | 10.253.15.56/30 |
| .15.branch_ip | 10.253.15.57 |
| .15.hub_ip | 10.253.15.58 |
| .16.hub_public_ip | 203.0.113.4 |
| .16.network | 10.253.15.60/30 |
| .16.branch_ip | 10.253.15.61 |
| .16.hub_ip | 10.253.15.62 |

### S16 — Temuco

28 PCs y 28 teléfonos existentes.

| Función | ANTES | DESPUÉS |
| --- | --- | --- |
| Routers | 1 × ISR4321/K9 | 2 × CCR2004-16G-2S+ |
| Switches | 1 × C9200L-48P-4G-E | CRS328-24P-4S+RM + CRS328-24P-4S+RM |
| Firewall | Sin equipo dedicado | Sin appliance remoto; seguridad central |
| Distribución WAN | MPLS y accesos ISP del escenario base | wanA: E50UG; wanB: E50UG |


| Red | VLAN | Subred | Gateway / roles |
| --- | --- | --- | --- |
| users | 10 | 10.70.16.0/25 | 10.70.16.1 |
| voice | 20 | 10.70.80.0/25 | 10.70.80.1 |
| guests | 40 | 10.70.112.0/26 | 10.70.112.1 |
| wifi_users | 110 | 10.81.16.0/25 | 10.81.16.1 |
| wifi_voice | 120 | 10.82.16.0/25 | 10.82.16.1 |
| management | 130 | 10.80.16.0/27 | 10.80.16.1 |


| Gestión | Dirección |
| --- | --- |
| sw1 | 10.80.16.2 |
| sw2 | 10.80.16.3 |
| r1 | 10.80.16.4 |
| r2 | 10.80.16.5 |
| wanA | 10.80.16.6 |
| wanB | 10.80.16.7 |
| ap1 | 10.80.16.24 |
| ap2 | 10.80.16.25 |


| Origen | Puerto | Destino | Puerto | Función | VLAN/red | Mbps | IP / agregado lógico |
| --- | --- | --- | --- | --- | --- | --- | --- |
| cpe:starlink | LAN | wanA | ether1 | WAN_ACCESS | 201 | 1000 | — |
| cpe:entel5g | LAN | wanA | ether2 | WAN_ACCESS | 203 | 1000 | — |
| r1 | ether1 | wanA | ether3 | WAN_TRUNK | 201, 203 | 1000 | — |
| r2 | ether1 | wanA | ether4 | WAN_TRUNK | 201, 203 | 1000 | — |
| wanA | ether5 | sw1 | ether22 | MANAGEMENT_ACCESS | 130 | 1000 | — |
| cpe:leo | LAN | wanB | ether1 | WAN_ACCESS | 202 | 1000 | — |
| cpe:wom4g | LAN | wanB | ether2 | WAN_ACCESS | 204 | 1000 | — |
| r1 | ether2 | wanB | ether3 | WAN_TRUNK | 202, 204 | 1000 | — |
| r2 | ether2 | wanB | ether4 | WAN_TRUNK | 202, 204 | 1000 | — |
| wanB | ether5 | sw2 | ether22 | MANAGEMENT_ACCESS | 130 | 1000 | — |
| r1 | ether3 | sw1 | ether19 | LAN_ROUTED | 172.31.16.0/30 | 1000 | router_ip: 172.31.16.1; stack_ip: 172.31.16.2 |
| r1 | ether4 | sw2 | ether19 | LAN_ROUTED | 172.31.16.4/30 | 1000 | router_ip: 172.31.16.5; stack_ip: 172.31.16.6 |
| r1 | ether5 | sw1 | ether21 | MANAGEMENT_ACCESS | 130 | 1000 | — |
| r2 | ether3 | sw1 | ether20 | LAN_ROUTED | 172.31.16.8/30 | 1000 | router_ip: 172.31.16.9; stack_ip: 172.31.16.10 |
| r2 | ether4 | sw2 | ether20 | LAN_ROUTED | 172.31.16.12/30 | 1000 | router_ip: 172.31.16.13; stack_ip: 172.31.16.14 |
| r2 | ether5 | sw2 | ether21 | MANAGEMENT_ACCESS | 130 | 1000 | — |
| ap1 | LAN | sw1 | ether24 | AP_TRUNK | 40, 110, 120, 130 | 1000 | — |
| ap2 | LAN | sw2 | ether24 | AP_TRUNK | 40, 110, 120, 130 | 1000 | — |
| sw1 | sfp-sfpplus1 | sw2 | sfp-sfpplus2 | STACK | 10, 20, 40, 110, 120, 130 | 10000 | — |
| sw1 | sfp-sfpplus2 | sw2 | sfp-sfpplus1 | STACK | 10, 20, 40, 110, 120, 130 | 10000 | — |


| Puesto | Switch | Puerto | IP PC | IP teléfono | Reserva Wi-Fi PC | Reserva Wi-Fi voz |
| --- | --- | --- | --- | --- | --- | --- |
| s16-pc01 | 1 | 1 | 10.70.16.10 | 10.70.80.10 | 10.81.16.10 | 10.82.16.10 |
| s16-pc02 | 2 | 1 | 10.70.16.11 | 10.70.80.11 | 10.81.16.11 | 10.82.16.11 |
| s16-pc03 | 1 | 2 | 10.70.16.12 | 10.70.80.12 | 10.81.16.12 | 10.82.16.12 |
| s16-pc04 | 2 | 2 | 10.70.16.13 | 10.70.80.13 | 10.81.16.13 | 10.82.16.13 |
| s16-pc05 | 1 | 3 | 10.70.16.14 | 10.70.80.14 | 10.81.16.14 | 10.82.16.14 |
| s16-pc06 | 2 | 3 | 10.70.16.15 | 10.70.80.15 | 10.81.16.15 | 10.82.16.15 |
| s16-pc07 | 1 | 4 | 10.70.16.16 | 10.70.80.16 | 10.81.16.16 | 10.82.16.16 |
| s16-pc08 | 2 | 4 | 10.70.16.17 | 10.70.80.17 | 10.81.16.17 | 10.82.16.17 |
| s16-pc09 | 1 | 5 | 10.70.16.18 | 10.70.80.18 | 10.81.16.18 | 10.82.16.18 |
| s16-pc10 | 2 | 5 | 10.70.16.19 | 10.70.80.19 | 10.81.16.19 | 10.82.16.19 |
| s16-pc11 | 1 | 6 | 10.70.16.20 | 10.70.80.20 | 10.81.16.20 | 10.82.16.20 |
| s16-pc12 | 2 | 6 | 10.70.16.21 | 10.70.80.21 | 10.81.16.21 | 10.82.16.21 |
| s16-pc13 | 1 | 7 | 10.70.16.22 | 10.70.80.22 | 10.81.16.22 | 10.82.16.22 |
| s16-pc14 | 2 | 7 | 10.70.16.23 | 10.70.80.23 | 10.81.16.23 | 10.82.16.23 |
| s16-pc15 | 1 | 8 | 10.70.16.24 | 10.70.80.24 | 10.81.16.24 | 10.82.16.24 |
| s16-pc16 | 2 | 8 | 10.70.16.25 | 10.70.80.25 | 10.81.16.25 | 10.82.16.25 |
| s16-pc17 | 1 | 9 | 10.70.16.26 | 10.70.80.26 | 10.81.16.26 | 10.82.16.26 |
| s16-pc18 | 2 | 9 | 10.70.16.27 | 10.70.80.27 | 10.81.16.27 | 10.82.16.27 |
| s16-pc19 | 1 | 10 | 10.70.16.28 | 10.70.80.28 | 10.81.16.28 | 10.82.16.28 |
| s16-pc20 | 2 | 10 | 10.70.16.29 | 10.70.80.29 | 10.81.16.29 | 10.82.16.29 |
| s16-pc21 | 1 | 11 | 10.70.16.30 | 10.70.80.30 | 10.81.16.30 | 10.82.16.30 |
| s16-pc22 | 2 | 11 | 10.70.16.31 | 10.70.80.31 | 10.81.16.31 | 10.82.16.31 |
| s16-pc23 | 1 | 12 | 10.70.16.32 | 10.70.80.32 | 10.81.16.32 | 10.82.16.32 |
| s16-pc24 | 2 | 12 | 10.70.16.33 | 10.70.80.33 | 10.81.16.33 | 10.82.16.33 |
| s16-pc25 | 1 | 13 | 10.70.16.34 | 10.70.80.34 | 10.81.16.34 | 10.82.16.34 |
| s16-pc26 | 2 | 13 | 10.70.16.35 | 10.70.80.35 | 10.81.16.35 | 10.82.16.35 |
| s16-pc27 | 1 | 14 | 10.70.16.36 | 10.70.80.36 | 10.81.16.36 | 10.82.16.36 |
| s16-pc28 | 2 | 14 | 10.70.16.37 | 10.70.80.37 | 10.81.16.37 | 10.82.16.37 |


**Transporte starlink — VLAN 201 — wanA.**

| Rol de entrega | Dirección |
| --- | --- |
| network | 10.252.16.0/29 |
| cpe | 10.252.16.1 |
| r1 | 10.252.16.2 |
| r2 | 10.252.16.3 |


**Transporte leo — VLAN 202 — wanB.**

| Rol de entrega | Dirección |
| --- | --- |
| network | 10.252.16.8/29 |
| cpe | 10.252.16.9 |
| r1 | 10.252.16.10 |
| r2 | 10.252.16.11 |


**Transporte entel5g — VLAN 203 — wanA.**

| Rol de entrega | Dirección |
| --- | --- |
| network | 10.252.16.16/29 |
| cpe | 10.252.16.17 |
| r1 | 10.252.16.18 |
| r2 | 10.252.16.19 |


**Transporte wom4g — VLAN 204 — wanB.**

| Rol de entrega | Dirección |
| --- | --- |
| network | 10.252.16.24/29 |
| cpe | 10.252.16.25 |
| r1 | 10.252.16.26 |
| r2 | 10.252.16.27 |


**Reservas de túneles (numeración según lista de la ficha).**

| Rol / candidato | Dirección |
| --- | --- |
| .1.hub_public_ip | 198.51.100.4 |
| .1.network | 10.253.16.0/30 |
| .1.branch_ip | 10.253.16.1 |
| .1.hub_ip | 10.253.16.2 |
| .2.hub_public_ip | 203.0.113.4 |
| .2.network | 10.253.16.4/30 |
| .2.branch_ip | 10.253.16.5 |
| .2.hub_ip | 10.253.16.6 |
| .3.hub_public_ip | 198.51.100.4 |
| .3.network | 10.253.16.8/30 |
| .3.branch_ip | 10.253.16.9 |
| .3.hub_ip | 10.253.16.10 |
| .4.hub_public_ip | 203.0.113.4 |
| .4.network | 10.253.16.12/30 |
| .4.branch_ip | 10.253.16.13 |
| .4.hub_ip | 10.253.16.14 |
| .5.hub_public_ip | 198.51.100.4 |
| .5.network | 10.253.16.16/30 |
| .5.branch_ip | 10.253.16.17 |
| .5.hub_ip | 10.253.16.18 |
| .6.hub_public_ip | 203.0.113.4 |
| .6.network | 10.253.16.20/30 |
| .6.branch_ip | 10.253.16.21 |
| .6.hub_ip | 10.253.16.22 |
| .7.hub_public_ip | 198.51.100.4 |
| .7.network | 10.253.16.24/30 |
| .7.branch_ip | 10.253.16.25 |
| .7.hub_ip | 10.253.16.26 |
| .8.hub_public_ip | 203.0.113.4 |
| .8.network | 10.253.16.28/30 |
| .8.branch_ip | 10.253.16.29 |
| .8.hub_ip | 10.253.16.30 |
| .9.hub_public_ip | 198.51.100.4 |
| .9.network | 10.253.16.32/30 |
| .9.branch_ip | 10.253.16.33 |
| .9.hub_ip | 10.253.16.34 |
| .10.hub_public_ip | 203.0.113.4 |
| .10.network | 10.253.16.36/30 |
| .10.branch_ip | 10.253.16.37 |
| .10.hub_ip | 10.253.16.38 |
| .11.hub_public_ip | 198.51.100.4 |
| .11.network | 10.253.16.40/30 |
| .11.branch_ip | 10.253.16.41 |
| .11.hub_ip | 10.253.16.42 |
| .12.hub_public_ip | 203.0.113.4 |
| .12.network | 10.253.16.44/30 |
| .12.branch_ip | 10.253.16.45 |
| .12.hub_ip | 10.253.16.46 |
| .13.hub_public_ip | 198.51.100.4 |
| .13.network | 10.253.16.48/30 |
| .13.branch_ip | 10.253.16.49 |
| .13.hub_ip | 10.253.16.50 |
| .14.hub_public_ip | 203.0.113.4 |
| .14.network | 10.253.16.52/30 |
| .14.branch_ip | 10.253.16.53 |
| .14.hub_ip | 10.253.16.54 |
| .15.hub_public_ip | 198.51.100.4 |
| .15.network | 10.253.16.56/30 |
| .15.branch_ip | 10.253.16.57 |
| .15.hub_ip | 10.253.16.58 |
| .16.hub_public_ip | 203.0.113.4 |
| .16.network | 10.253.16.60/30 |
| .16.branch_ip | 10.253.16.61 |
| .16.hub_ip | 10.253.16.62 |

### S17 — Valdivia

28 PCs y 28 teléfonos existentes.

| Función | ANTES | DESPUÉS |
| --- | --- | --- |
| Routers | 1 × C1121X-8P | 2 × CCR2004-16G-2S+ |
| Switches | 1 × C9200L-48P-4G-E | CRS328-24P-4S+RM + CRS328-24P-4S+RM |
| Firewall | Sin equipo dedicado | Sin appliance remoto; seguridad central |
| Distribución WAN | MPLS y accesos ISP del escenario base | wanA: E50UG; wanB: E50UG |


| Red | VLAN | Subred | Gateway / roles |
| --- | --- | --- | --- |
| users | 10 | 10.70.17.0/25 | 10.70.17.1 |
| voice | 20 | 10.70.81.0/25 | 10.70.81.1 |
| guests | 40 | 10.70.113.0/26 | 10.70.113.1 |
| wifi_users | 110 | 10.81.17.0/25 | 10.81.17.1 |
| wifi_voice | 120 | 10.82.17.0/25 | 10.82.17.1 |
| management | 130 | 10.80.17.0/27 | 10.80.17.1 |


| Gestión | Dirección |
| --- | --- |
| sw1 | 10.80.17.2 |
| sw2 | 10.80.17.3 |
| r1 | 10.80.17.4 |
| r2 | 10.80.17.5 |
| wanA | 10.80.17.6 |
| wanB | 10.80.17.7 |
| ap1 | 10.80.17.24 |
| ap2 | 10.80.17.25 |


| Origen | Puerto | Destino | Puerto | Función | VLAN/red | Mbps | IP / agregado lógico |
| --- | --- | --- | --- | --- | --- | --- | --- |
| cpe:starlink | LAN | wanA | ether1 | WAN_ACCESS | 201 | 1000 | — |
| cpe:entel5g | LAN | wanA | ether2 | WAN_ACCESS | 203 | 1000 | — |
| r1 | ether1 | wanA | ether3 | WAN_TRUNK | 201, 203 | 1000 | — |
| r2 | ether1 | wanA | ether4 | WAN_TRUNK | 201, 203 | 1000 | — |
| wanA | ether5 | sw1 | ether22 | MANAGEMENT_ACCESS | 130 | 1000 | — |
| cpe:leo | LAN | wanB | ether1 | WAN_ACCESS | 202 | 1000 | — |
| cpe:wom4g | LAN | wanB | ether2 | WAN_ACCESS | 204 | 1000 | — |
| r1 | ether2 | wanB | ether3 | WAN_TRUNK | 202, 204 | 1000 | — |
| r2 | ether2 | wanB | ether4 | WAN_TRUNK | 202, 204 | 1000 | — |
| wanB | ether5 | sw2 | ether22 | MANAGEMENT_ACCESS | 130 | 1000 | — |
| r1 | ether3 | sw1 | ether19 | LAN_ROUTED | 172.31.17.0/30 | 1000 | router_ip: 172.31.17.1; stack_ip: 172.31.17.2 |
| r1 | ether4 | sw2 | ether19 | LAN_ROUTED | 172.31.17.4/30 | 1000 | router_ip: 172.31.17.5; stack_ip: 172.31.17.6 |
| r1 | ether5 | sw1 | ether21 | MANAGEMENT_ACCESS | 130 | 1000 | — |
| r2 | ether3 | sw1 | ether20 | LAN_ROUTED | 172.31.17.8/30 | 1000 | router_ip: 172.31.17.9; stack_ip: 172.31.17.10 |
| r2 | ether4 | sw2 | ether20 | LAN_ROUTED | 172.31.17.12/30 | 1000 | router_ip: 172.31.17.13; stack_ip: 172.31.17.14 |
| r2 | ether5 | sw2 | ether21 | MANAGEMENT_ACCESS | 130 | 1000 | — |
| ap1 | LAN | sw1 | ether24 | AP_TRUNK | 40, 110, 120, 130 | 1000 | — |
| ap2 | LAN | sw2 | ether24 | AP_TRUNK | 40, 110, 120, 130 | 1000 | — |
| sw1 | sfp-sfpplus1 | sw2 | sfp-sfpplus2 | STACK | 10, 20, 40, 110, 120, 130 | 10000 | — |
| sw1 | sfp-sfpplus2 | sw2 | sfp-sfpplus1 | STACK | 10, 20, 40, 110, 120, 130 | 10000 | — |


| Puesto | Switch | Puerto | IP PC | IP teléfono | Reserva Wi-Fi PC | Reserva Wi-Fi voz |
| --- | --- | --- | --- | --- | --- | --- |
| s17-pc01 | 1 | 1 | 10.70.17.10 | 10.70.81.10 | 10.81.17.10 | 10.82.17.10 |
| s17-pc02 | 2 | 1 | 10.70.17.11 | 10.70.81.11 | 10.81.17.11 | 10.82.17.11 |
| s17-pc03 | 1 | 2 | 10.70.17.12 | 10.70.81.12 | 10.81.17.12 | 10.82.17.12 |
| s17-pc04 | 2 | 2 | 10.70.17.13 | 10.70.81.13 | 10.81.17.13 | 10.82.17.13 |
| s17-pc05 | 1 | 3 | 10.70.17.14 | 10.70.81.14 | 10.81.17.14 | 10.82.17.14 |
| s17-pc06 | 2 | 3 | 10.70.17.15 | 10.70.81.15 | 10.81.17.15 | 10.82.17.15 |
| s17-pc07 | 1 | 4 | 10.70.17.16 | 10.70.81.16 | 10.81.17.16 | 10.82.17.16 |
| s17-pc08 | 2 | 4 | 10.70.17.17 | 10.70.81.17 | 10.81.17.17 | 10.82.17.17 |
| s17-pc09 | 1 | 5 | 10.70.17.18 | 10.70.81.18 | 10.81.17.18 | 10.82.17.18 |
| s17-pc10 | 2 | 5 | 10.70.17.19 | 10.70.81.19 | 10.81.17.19 | 10.82.17.19 |
| s17-pc11 | 1 | 6 | 10.70.17.20 | 10.70.81.20 | 10.81.17.20 | 10.82.17.20 |
| s17-pc12 | 2 | 6 | 10.70.17.21 | 10.70.81.21 | 10.81.17.21 | 10.82.17.21 |
| s17-pc13 | 1 | 7 | 10.70.17.22 | 10.70.81.22 | 10.81.17.22 | 10.82.17.22 |
| s17-pc14 | 2 | 7 | 10.70.17.23 | 10.70.81.23 | 10.81.17.23 | 10.82.17.23 |
| s17-pc15 | 1 | 8 | 10.70.17.24 | 10.70.81.24 | 10.81.17.24 | 10.82.17.24 |
| s17-pc16 | 2 | 8 | 10.70.17.25 | 10.70.81.25 | 10.81.17.25 | 10.82.17.25 |
| s17-pc17 | 1 | 9 | 10.70.17.26 | 10.70.81.26 | 10.81.17.26 | 10.82.17.26 |
| s17-pc18 | 2 | 9 | 10.70.17.27 | 10.70.81.27 | 10.81.17.27 | 10.82.17.27 |
| s17-pc19 | 1 | 10 | 10.70.17.28 | 10.70.81.28 | 10.81.17.28 | 10.82.17.28 |
| s17-pc20 | 2 | 10 | 10.70.17.29 | 10.70.81.29 | 10.81.17.29 | 10.82.17.29 |
| s17-pc21 | 1 | 11 | 10.70.17.30 | 10.70.81.30 | 10.81.17.30 | 10.82.17.30 |
| s17-pc22 | 2 | 11 | 10.70.17.31 | 10.70.81.31 | 10.81.17.31 | 10.82.17.31 |
| s17-pc23 | 1 | 12 | 10.70.17.32 | 10.70.81.32 | 10.81.17.32 | 10.82.17.32 |
| s17-pc24 | 2 | 12 | 10.70.17.33 | 10.70.81.33 | 10.81.17.33 | 10.82.17.33 |
| s17-pc25 | 1 | 13 | 10.70.17.34 | 10.70.81.34 | 10.81.17.34 | 10.82.17.34 |
| s17-pc26 | 2 | 13 | 10.70.17.35 | 10.70.81.35 | 10.81.17.35 | 10.82.17.35 |
| s17-pc27 | 1 | 14 | 10.70.17.36 | 10.70.81.36 | 10.81.17.36 | 10.82.17.36 |
| s17-pc28 | 2 | 14 | 10.70.17.37 | 10.70.81.37 | 10.81.17.37 | 10.82.17.37 |


**Transporte starlink — VLAN 201 — wanA.**

| Rol de entrega | Dirección |
| --- | --- |
| network | 10.252.17.0/29 |
| cpe | 10.252.17.1 |
| r1 | 10.252.17.2 |
| r2 | 10.252.17.3 |


**Transporte leo — VLAN 202 — wanB.**

| Rol de entrega | Dirección |
| --- | --- |
| network | 10.252.17.8/29 |
| cpe | 10.252.17.9 |
| r1 | 10.252.17.10 |
| r2 | 10.252.17.11 |


**Transporte entel5g — VLAN 203 — wanA.**

| Rol de entrega | Dirección |
| --- | --- |
| network | 10.252.17.16/29 |
| cpe | 10.252.17.17 |
| r1 | 10.252.17.18 |
| r2 | 10.252.17.19 |


**Transporte wom4g — VLAN 204 — wanB.**

| Rol de entrega | Dirección |
| --- | --- |
| network | 10.252.17.24/29 |
| cpe | 10.252.17.25 |
| r1 | 10.252.17.26 |
| r2 | 10.252.17.27 |


**Reservas de túneles (numeración según lista de la ficha).**

| Rol / candidato | Dirección |
| --- | --- |
| .1.hub_public_ip | 198.51.100.4 |
| .1.network | 10.253.17.0/30 |
| .1.branch_ip | 10.253.17.1 |
| .1.hub_ip | 10.253.17.2 |
| .2.hub_public_ip | 203.0.113.4 |
| .2.network | 10.253.17.4/30 |
| .2.branch_ip | 10.253.17.5 |
| .2.hub_ip | 10.253.17.6 |
| .3.hub_public_ip | 198.51.100.4 |
| .3.network | 10.253.17.8/30 |
| .3.branch_ip | 10.253.17.9 |
| .3.hub_ip | 10.253.17.10 |
| .4.hub_public_ip | 203.0.113.4 |
| .4.network | 10.253.17.12/30 |
| .4.branch_ip | 10.253.17.13 |
| .4.hub_ip | 10.253.17.14 |
| .5.hub_public_ip | 198.51.100.4 |
| .5.network | 10.253.17.16/30 |
| .5.branch_ip | 10.253.17.17 |
| .5.hub_ip | 10.253.17.18 |
| .6.hub_public_ip | 203.0.113.4 |
| .6.network | 10.253.17.20/30 |
| .6.branch_ip | 10.253.17.21 |
| .6.hub_ip | 10.253.17.22 |
| .7.hub_public_ip | 198.51.100.4 |
| .7.network | 10.253.17.24/30 |
| .7.branch_ip | 10.253.17.25 |
| .7.hub_ip | 10.253.17.26 |
| .8.hub_public_ip | 203.0.113.4 |
| .8.network | 10.253.17.28/30 |
| .8.branch_ip | 10.253.17.29 |
| .8.hub_ip | 10.253.17.30 |
| .9.hub_public_ip | 198.51.100.4 |
| .9.network | 10.253.17.32/30 |
| .9.branch_ip | 10.253.17.33 |
| .9.hub_ip | 10.253.17.34 |
| .10.hub_public_ip | 203.0.113.4 |
| .10.network | 10.253.17.36/30 |
| .10.branch_ip | 10.253.17.37 |
| .10.hub_ip | 10.253.17.38 |
| .11.hub_public_ip | 198.51.100.4 |
| .11.network | 10.253.17.40/30 |
| .11.branch_ip | 10.253.17.41 |
| .11.hub_ip | 10.253.17.42 |
| .12.hub_public_ip | 203.0.113.4 |
| .12.network | 10.253.17.44/30 |
| .12.branch_ip | 10.253.17.45 |
| .12.hub_ip | 10.253.17.46 |
| .13.hub_public_ip | 198.51.100.4 |
| .13.network | 10.253.17.48/30 |
| .13.branch_ip | 10.253.17.49 |
| .13.hub_ip | 10.253.17.50 |
| .14.hub_public_ip | 203.0.113.4 |
| .14.network | 10.253.17.52/30 |
| .14.branch_ip | 10.253.17.53 |
| .14.hub_ip | 10.253.17.54 |
| .15.hub_public_ip | 198.51.100.4 |
| .15.network | 10.253.17.56/30 |
| .15.branch_ip | 10.253.17.57 |
| .15.hub_ip | 10.253.17.58 |
| .16.hub_public_ip | 203.0.113.4 |
| .16.network | 10.253.17.60/30 |
| .16.branch_ip | 10.253.17.61 |
| .16.hub_ip | 10.253.17.62 |

### S18 — Puerto Montt

28 PCs y 28 teléfonos existentes.

| Función | ANTES | DESPUÉS |
| --- | --- | --- |
| Routers | 1 × ISR4321/K9 | 2 × CCR2004-16G-2S+ |
| Switches | 1 × C9200L-48P-4G-E | CRS328-24P-4S+RM + CRS328-24P-4S+RM |
| Firewall | Sin equipo dedicado | Sin appliance remoto; seguridad central |
| Distribución WAN | MPLS y accesos ISP del escenario base | wanA: E50UG; wanB: E50UG |


| Red | VLAN | Subred | Gateway / roles |
| --- | --- | --- | --- |
| users | 10 | 10.70.18.0/25 | 10.70.18.1 |
| voice | 20 | 10.70.82.0/25 | 10.70.82.1 |
| guests | 40 | 10.70.114.0/26 | 10.70.114.1 |
| wifi_users | 110 | 10.81.18.0/25 | 10.81.18.1 |
| wifi_voice | 120 | 10.82.18.0/25 | 10.82.18.1 |
| management | 130 | 10.80.18.0/27 | 10.80.18.1 |


| Gestión | Dirección |
| --- | --- |
| sw1 | 10.80.18.2 |
| sw2 | 10.80.18.3 |
| r1 | 10.80.18.4 |
| r2 | 10.80.18.5 |
| wanA | 10.80.18.6 |
| wanB | 10.80.18.7 |
| ap1 | 10.80.18.24 |
| ap2 | 10.80.18.25 |


| Origen | Puerto | Destino | Puerto | Función | VLAN/red | Mbps | IP / agregado lógico |
| --- | --- | --- | --- | --- | --- | --- | --- |
| cpe:starlink | LAN | wanA | ether1 | WAN_ACCESS | 201 | 1000 | — |
| cpe:entel5g | LAN | wanA | ether2 | WAN_ACCESS | 203 | 1000 | — |
| r1 | ether1 | wanA | ether3 | WAN_TRUNK | 201, 203 | 1000 | — |
| r2 | ether1 | wanA | ether4 | WAN_TRUNK | 201, 203 | 1000 | — |
| wanA | ether5 | sw1 | ether22 | MANAGEMENT_ACCESS | 130 | 1000 | — |
| cpe:leo | LAN | wanB | ether1 | WAN_ACCESS | 202 | 1000 | — |
| cpe:wom4g | LAN | wanB | ether2 | WAN_ACCESS | 204 | 1000 | — |
| r1 | ether2 | wanB | ether3 | WAN_TRUNK | 202, 204 | 1000 | — |
| r2 | ether2 | wanB | ether4 | WAN_TRUNK | 202, 204 | 1000 | — |
| wanB | ether5 | sw2 | ether22 | MANAGEMENT_ACCESS | 130 | 1000 | — |
| r1 | ether3 | sw1 | ether19 | LAN_ROUTED | 172.31.18.0/30 | 1000 | router_ip: 172.31.18.1; stack_ip: 172.31.18.2 |
| r1 | ether4 | sw2 | ether19 | LAN_ROUTED | 172.31.18.4/30 | 1000 | router_ip: 172.31.18.5; stack_ip: 172.31.18.6 |
| r1 | ether5 | sw1 | ether21 | MANAGEMENT_ACCESS | 130 | 1000 | — |
| r2 | ether3 | sw1 | ether20 | LAN_ROUTED | 172.31.18.8/30 | 1000 | router_ip: 172.31.18.9; stack_ip: 172.31.18.10 |
| r2 | ether4 | sw2 | ether20 | LAN_ROUTED | 172.31.18.12/30 | 1000 | router_ip: 172.31.18.13; stack_ip: 172.31.18.14 |
| r2 | ether5 | sw2 | ether21 | MANAGEMENT_ACCESS | 130 | 1000 | — |
| ap1 | LAN | sw1 | ether24 | AP_TRUNK | 40, 110, 120, 130 | 1000 | — |
| ap2 | LAN | sw2 | ether24 | AP_TRUNK | 40, 110, 120, 130 | 1000 | — |
| sw1 | sfp-sfpplus1 | sw2 | sfp-sfpplus2 | STACK | 10, 20, 40, 110, 120, 130 | 10000 | — |
| sw1 | sfp-sfpplus2 | sw2 | sfp-sfpplus1 | STACK | 10, 20, 40, 110, 120, 130 | 10000 | — |


| Puesto | Switch | Puerto | IP PC | IP teléfono | Reserva Wi-Fi PC | Reserva Wi-Fi voz |
| --- | --- | --- | --- | --- | --- | --- |
| s18-pc01 | 1 | 1 | 10.70.18.10 | 10.70.82.10 | 10.81.18.10 | 10.82.18.10 |
| s18-pc02 | 2 | 1 | 10.70.18.11 | 10.70.82.11 | 10.81.18.11 | 10.82.18.11 |
| s18-pc03 | 1 | 2 | 10.70.18.12 | 10.70.82.12 | 10.81.18.12 | 10.82.18.12 |
| s18-pc04 | 2 | 2 | 10.70.18.13 | 10.70.82.13 | 10.81.18.13 | 10.82.18.13 |
| s18-pc05 | 1 | 3 | 10.70.18.14 | 10.70.82.14 | 10.81.18.14 | 10.82.18.14 |
| s18-pc06 | 2 | 3 | 10.70.18.15 | 10.70.82.15 | 10.81.18.15 | 10.82.18.15 |
| s18-pc07 | 1 | 4 | 10.70.18.16 | 10.70.82.16 | 10.81.18.16 | 10.82.18.16 |
| s18-pc08 | 2 | 4 | 10.70.18.17 | 10.70.82.17 | 10.81.18.17 | 10.82.18.17 |
| s18-pc09 | 1 | 5 | 10.70.18.18 | 10.70.82.18 | 10.81.18.18 | 10.82.18.18 |
| s18-pc10 | 2 | 5 | 10.70.18.19 | 10.70.82.19 | 10.81.18.19 | 10.82.18.19 |
| s18-pc11 | 1 | 6 | 10.70.18.20 | 10.70.82.20 | 10.81.18.20 | 10.82.18.20 |
| s18-pc12 | 2 | 6 | 10.70.18.21 | 10.70.82.21 | 10.81.18.21 | 10.82.18.21 |
| s18-pc13 | 1 | 7 | 10.70.18.22 | 10.70.82.22 | 10.81.18.22 | 10.82.18.22 |
| s18-pc14 | 2 | 7 | 10.70.18.23 | 10.70.82.23 | 10.81.18.23 | 10.82.18.23 |
| s18-pc15 | 1 | 8 | 10.70.18.24 | 10.70.82.24 | 10.81.18.24 | 10.82.18.24 |
| s18-pc16 | 2 | 8 | 10.70.18.25 | 10.70.82.25 | 10.81.18.25 | 10.82.18.25 |
| s18-pc17 | 1 | 9 | 10.70.18.26 | 10.70.82.26 | 10.81.18.26 | 10.82.18.26 |
| s18-pc18 | 2 | 9 | 10.70.18.27 | 10.70.82.27 | 10.81.18.27 | 10.82.18.27 |
| s18-pc19 | 1 | 10 | 10.70.18.28 | 10.70.82.28 | 10.81.18.28 | 10.82.18.28 |
| s18-pc20 | 2 | 10 | 10.70.18.29 | 10.70.82.29 | 10.81.18.29 | 10.82.18.29 |
| s18-pc21 | 1 | 11 | 10.70.18.30 | 10.70.82.30 | 10.81.18.30 | 10.82.18.30 |
| s18-pc22 | 2 | 11 | 10.70.18.31 | 10.70.82.31 | 10.81.18.31 | 10.82.18.31 |
| s18-pc23 | 1 | 12 | 10.70.18.32 | 10.70.82.32 | 10.81.18.32 | 10.82.18.32 |
| s18-pc24 | 2 | 12 | 10.70.18.33 | 10.70.82.33 | 10.81.18.33 | 10.82.18.33 |
| s18-pc25 | 1 | 13 | 10.70.18.34 | 10.70.82.34 | 10.81.18.34 | 10.82.18.34 |
| s18-pc26 | 2 | 13 | 10.70.18.35 | 10.70.82.35 | 10.81.18.35 | 10.82.18.35 |
| s18-pc27 | 1 | 14 | 10.70.18.36 | 10.70.82.36 | 10.81.18.36 | 10.82.18.36 |
| s18-pc28 | 2 | 14 | 10.70.18.37 | 10.70.82.37 | 10.81.18.37 | 10.82.18.37 |


**Transporte starlink — VLAN 201 — wanA.**

| Rol de entrega | Dirección |
| --- | --- |
| network | 10.252.18.0/29 |
| cpe | 10.252.18.1 |
| r1 | 10.252.18.2 |
| r2 | 10.252.18.3 |


**Transporte leo — VLAN 202 — wanB.**

| Rol de entrega | Dirección |
| --- | --- |
| network | 10.252.18.8/29 |
| cpe | 10.252.18.9 |
| r1 | 10.252.18.10 |
| r2 | 10.252.18.11 |


**Transporte entel5g — VLAN 203 — wanA.**

| Rol de entrega | Dirección |
| --- | --- |
| network | 10.252.18.16/29 |
| cpe | 10.252.18.17 |
| r1 | 10.252.18.18 |
| r2 | 10.252.18.19 |


**Transporte wom4g — VLAN 204 — wanB.**

| Rol de entrega | Dirección |
| --- | --- |
| network | 10.252.18.24/29 |
| cpe | 10.252.18.25 |
| r1 | 10.252.18.26 |
| r2 | 10.252.18.27 |


**Reservas de túneles (numeración según lista de la ficha).**

| Rol / candidato | Dirección |
| --- | --- |
| .1.hub_public_ip | 198.51.100.4 |
| .1.network | 10.253.18.0/30 |
| .1.branch_ip | 10.253.18.1 |
| .1.hub_ip | 10.253.18.2 |
| .2.hub_public_ip | 203.0.113.4 |
| .2.network | 10.253.18.4/30 |
| .2.branch_ip | 10.253.18.5 |
| .2.hub_ip | 10.253.18.6 |
| .3.hub_public_ip | 198.51.100.4 |
| .3.network | 10.253.18.8/30 |
| .3.branch_ip | 10.253.18.9 |
| .3.hub_ip | 10.253.18.10 |
| .4.hub_public_ip | 203.0.113.4 |
| .4.network | 10.253.18.12/30 |
| .4.branch_ip | 10.253.18.13 |
| .4.hub_ip | 10.253.18.14 |
| .5.hub_public_ip | 198.51.100.4 |
| .5.network | 10.253.18.16/30 |
| .5.branch_ip | 10.253.18.17 |
| .5.hub_ip | 10.253.18.18 |
| .6.hub_public_ip | 203.0.113.4 |
| .6.network | 10.253.18.20/30 |
| .6.branch_ip | 10.253.18.21 |
| .6.hub_ip | 10.253.18.22 |
| .7.hub_public_ip | 198.51.100.4 |
| .7.network | 10.253.18.24/30 |
| .7.branch_ip | 10.253.18.25 |
| .7.hub_ip | 10.253.18.26 |
| .8.hub_public_ip | 203.0.113.4 |
| .8.network | 10.253.18.28/30 |
| .8.branch_ip | 10.253.18.29 |
| .8.hub_ip | 10.253.18.30 |
| .9.hub_public_ip | 198.51.100.4 |
| .9.network | 10.253.18.32/30 |
| .9.branch_ip | 10.253.18.33 |
| .9.hub_ip | 10.253.18.34 |
| .10.hub_public_ip | 203.0.113.4 |
| .10.network | 10.253.18.36/30 |
| .10.branch_ip | 10.253.18.37 |
| .10.hub_ip | 10.253.18.38 |
| .11.hub_public_ip | 198.51.100.4 |
| .11.network | 10.253.18.40/30 |
| .11.branch_ip | 10.253.18.41 |
| .11.hub_ip | 10.253.18.42 |
| .12.hub_public_ip | 203.0.113.4 |
| .12.network | 10.253.18.44/30 |
| .12.branch_ip | 10.253.18.45 |
| .12.hub_ip | 10.253.18.46 |
| .13.hub_public_ip | 198.51.100.4 |
| .13.network | 10.253.18.48/30 |
| .13.branch_ip | 10.253.18.49 |
| .13.hub_ip | 10.253.18.50 |
| .14.hub_public_ip | 203.0.113.4 |
| .14.network | 10.253.18.52/30 |
| .14.branch_ip | 10.253.18.53 |
| .14.hub_ip | 10.253.18.54 |
| .15.hub_public_ip | 198.51.100.4 |
| .15.network | 10.253.18.56/30 |
| .15.branch_ip | 10.253.18.57 |
| .15.hub_ip | 10.253.18.58 |
| .16.hub_public_ip | 203.0.113.4 |
| .16.network | 10.253.18.60/30 |
| .16.branch_ip | 10.253.18.61 |
| .16.hub_ip | 10.253.18.62 |

### S19 — Coyhaique

28 PCs y 28 teléfonos existentes.

| Función | ANTES | DESPUÉS |
| --- | --- | --- |
| Routers | 1 × C1121X-8P | 2 × CCR2004-16G-2S+ |
| Switches | 1 × C9200L-48P-4G-E | CRS328-24P-4S+RM + CRS328-24P-4S+RM |
| Firewall | Sin equipo dedicado | Sin appliance remoto; seguridad central |
| Distribución WAN | MPLS y accesos ISP del escenario base | wanA: E50UG; wanB: E50UG |


| Red | VLAN | Subred | Gateway / roles |
| --- | --- | --- | --- |
| users | 10 | 10.70.19.0/25 | 10.70.19.1 |
| voice | 20 | 10.70.83.0/25 | 10.70.83.1 |
| guests | 40 | 10.70.115.0/26 | 10.70.115.1 |
| wifi_users | 110 | 10.81.19.0/25 | 10.81.19.1 |
| wifi_voice | 120 | 10.82.19.0/25 | 10.82.19.1 |
| management | 130 | 10.80.19.0/27 | 10.80.19.1 |


| Gestión | Dirección |
| --- | --- |
| sw1 | 10.80.19.2 |
| sw2 | 10.80.19.3 |
| r1 | 10.80.19.4 |
| r2 | 10.80.19.5 |
| wanA | 10.80.19.6 |
| wanB | 10.80.19.7 |
| ap1 | 10.80.19.24 |
| ap2 | 10.80.19.25 |


| Origen | Puerto | Destino | Puerto | Función | VLAN/red | Mbps | IP / agregado lógico |
| --- | --- | --- | --- | --- | --- | --- | --- |
| cpe:starlink | LAN | wanA | ether1 | WAN_ACCESS | 201 | 1000 | — |
| cpe:entel5g | LAN | wanA | ether2 | WAN_ACCESS | 203 | 1000 | — |
| r1 | ether1 | wanA | ether3 | WAN_TRUNK | 201, 203 | 1000 | — |
| r2 | ether1 | wanA | ether4 | WAN_TRUNK | 201, 203 | 1000 | — |
| wanA | ether5 | sw1 | ether22 | MANAGEMENT_ACCESS | 130 | 1000 | — |
| cpe:leo | LAN | wanB | ether1 | WAN_ACCESS | 202 | 1000 | — |
| cpe:wom4g | LAN | wanB | ether2 | WAN_ACCESS | 204 | 1000 | — |
| r1 | ether2 | wanB | ether3 | WAN_TRUNK | 202, 204 | 1000 | — |
| r2 | ether2 | wanB | ether4 | WAN_TRUNK | 202, 204 | 1000 | — |
| wanB | ether5 | sw2 | ether22 | MANAGEMENT_ACCESS | 130 | 1000 | — |
| r1 | ether3 | sw1 | ether19 | LAN_ROUTED | 172.31.19.0/30 | 1000 | router_ip: 172.31.19.1; stack_ip: 172.31.19.2 |
| r1 | ether4 | sw2 | ether19 | LAN_ROUTED | 172.31.19.4/30 | 1000 | router_ip: 172.31.19.5; stack_ip: 172.31.19.6 |
| r1 | ether5 | sw1 | ether21 | MANAGEMENT_ACCESS | 130 | 1000 | — |
| r2 | ether3 | sw1 | ether20 | LAN_ROUTED | 172.31.19.8/30 | 1000 | router_ip: 172.31.19.9; stack_ip: 172.31.19.10 |
| r2 | ether4 | sw2 | ether20 | LAN_ROUTED | 172.31.19.12/30 | 1000 | router_ip: 172.31.19.13; stack_ip: 172.31.19.14 |
| r2 | ether5 | sw2 | ether21 | MANAGEMENT_ACCESS | 130 | 1000 | — |
| ap1 | LAN | sw1 | ether24 | AP_TRUNK | 40, 110, 120, 130 | 1000 | — |
| ap2 | LAN | sw2 | ether24 | AP_TRUNK | 40, 110, 120, 130 | 1000 | — |
| sw1 | sfp-sfpplus1 | sw2 | sfp-sfpplus2 | STACK | 10, 20, 40, 110, 120, 130 | 10000 | — |
| sw1 | sfp-sfpplus2 | sw2 | sfp-sfpplus1 | STACK | 10, 20, 40, 110, 120, 130 | 10000 | — |


| Puesto | Switch | Puerto | IP PC | IP teléfono | Reserva Wi-Fi PC | Reserva Wi-Fi voz |
| --- | --- | --- | --- | --- | --- | --- |
| s19-pc01 | 1 | 1 | 10.70.19.10 | 10.70.83.10 | 10.81.19.10 | 10.82.19.10 |
| s19-pc02 | 2 | 1 | 10.70.19.11 | 10.70.83.11 | 10.81.19.11 | 10.82.19.11 |
| s19-pc03 | 1 | 2 | 10.70.19.12 | 10.70.83.12 | 10.81.19.12 | 10.82.19.12 |
| s19-pc04 | 2 | 2 | 10.70.19.13 | 10.70.83.13 | 10.81.19.13 | 10.82.19.13 |
| s19-pc05 | 1 | 3 | 10.70.19.14 | 10.70.83.14 | 10.81.19.14 | 10.82.19.14 |
| s19-pc06 | 2 | 3 | 10.70.19.15 | 10.70.83.15 | 10.81.19.15 | 10.82.19.15 |
| s19-pc07 | 1 | 4 | 10.70.19.16 | 10.70.83.16 | 10.81.19.16 | 10.82.19.16 |
| s19-pc08 | 2 | 4 | 10.70.19.17 | 10.70.83.17 | 10.81.19.17 | 10.82.19.17 |
| s19-pc09 | 1 | 5 | 10.70.19.18 | 10.70.83.18 | 10.81.19.18 | 10.82.19.18 |
| s19-pc10 | 2 | 5 | 10.70.19.19 | 10.70.83.19 | 10.81.19.19 | 10.82.19.19 |
| s19-pc11 | 1 | 6 | 10.70.19.20 | 10.70.83.20 | 10.81.19.20 | 10.82.19.20 |
| s19-pc12 | 2 | 6 | 10.70.19.21 | 10.70.83.21 | 10.81.19.21 | 10.82.19.21 |
| s19-pc13 | 1 | 7 | 10.70.19.22 | 10.70.83.22 | 10.81.19.22 | 10.82.19.22 |
| s19-pc14 | 2 | 7 | 10.70.19.23 | 10.70.83.23 | 10.81.19.23 | 10.82.19.23 |
| s19-pc15 | 1 | 8 | 10.70.19.24 | 10.70.83.24 | 10.81.19.24 | 10.82.19.24 |
| s19-pc16 | 2 | 8 | 10.70.19.25 | 10.70.83.25 | 10.81.19.25 | 10.82.19.25 |
| s19-pc17 | 1 | 9 | 10.70.19.26 | 10.70.83.26 | 10.81.19.26 | 10.82.19.26 |
| s19-pc18 | 2 | 9 | 10.70.19.27 | 10.70.83.27 | 10.81.19.27 | 10.82.19.27 |
| s19-pc19 | 1 | 10 | 10.70.19.28 | 10.70.83.28 | 10.81.19.28 | 10.82.19.28 |
| s19-pc20 | 2 | 10 | 10.70.19.29 | 10.70.83.29 | 10.81.19.29 | 10.82.19.29 |
| s19-pc21 | 1 | 11 | 10.70.19.30 | 10.70.83.30 | 10.81.19.30 | 10.82.19.30 |
| s19-pc22 | 2 | 11 | 10.70.19.31 | 10.70.83.31 | 10.81.19.31 | 10.82.19.31 |
| s19-pc23 | 1 | 12 | 10.70.19.32 | 10.70.83.32 | 10.81.19.32 | 10.82.19.32 |
| s19-pc24 | 2 | 12 | 10.70.19.33 | 10.70.83.33 | 10.81.19.33 | 10.82.19.33 |
| s19-pc25 | 1 | 13 | 10.70.19.34 | 10.70.83.34 | 10.81.19.34 | 10.82.19.34 |
| s19-pc26 | 2 | 13 | 10.70.19.35 | 10.70.83.35 | 10.81.19.35 | 10.82.19.35 |
| s19-pc27 | 1 | 14 | 10.70.19.36 | 10.70.83.36 | 10.81.19.36 | 10.82.19.36 |
| s19-pc28 | 2 | 14 | 10.70.19.37 | 10.70.83.37 | 10.81.19.37 | 10.82.19.37 |


**Transporte starlink — VLAN 201 — wanA.**

| Rol de entrega | Dirección |
| --- | --- |
| network | 10.252.19.0/29 |
| cpe | 10.252.19.1 |
| r1 | 10.252.19.2 |
| r2 | 10.252.19.3 |


**Transporte leo — VLAN 202 — wanB.**

| Rol de entrega | Dirección |
| --- | --- |
| network | 10.252.19.8/29 |
| cpe | 10.252.19.9 |
| r1 | 10.252.19.10 |
| r2 | 10.252.19.11 |


**Transporte entel5g — VLAN 203 — wanA.**

| Rol de entrega | Dirección |
| --- | --- |
| network | 10.252.19.16/29 |
| cpe | 10.252.19.17 |
| r1 | 10.252.19.18 |
| r2 | 10.252.19.19 |


**Transporte wom4g — VLAN 204 — wanB.**

| Rol de entrega | Dirección |
| --- | --- |
| network | 10.252.19.24/29 |
| cpe | 10.252.19.25 |
| r1 | 10.252.19.26 |
| r2 | 10.252.19.27 |


**Reservas de túneles (numeración según lista de la ficha).**

| Rol / candidato | Dirección |
| --- | --- |
| .1.hub_public_ip | 198.51.100.4 |
| .1.network | 10.253.19.0/30 |
| .1.branch_ip | 10.253.19.1 |
| .1.hub_ip | 10.253.19.2 |
| .2.hub_public_ip | 203.0.113.4 |
| .2.network | 10.253.19.4/30 |
| .2.branch_ip | 10.253.19.5 |
| .2.hub_ip | 10.253.19.6 |
| .3.hub_public_ip | 198.51.100.4 |
| .3.network | 10.253.19.8/30 |
| .3.branch_ip | 10.253.19.9 |
| .3.hub_ip | 10.253.19.10 |
| .4.hub_public_ip | 203.0.113.4 |
| .4.network | 10.253.19.12/30 |
| .4.branch_ip | 10.253.19.13 |
| .4.hub_ip | 10.253.19.14 |
| .5.hub_public_ip | 198.51.100.4 |
| .5.network | 10.253.19.16/30 |
| .5.branch_ip | 10.253.19.17 |
| .5.hub_ip | 10.253.19.18 |
| .6.hub_public_ip | 203.0.113.4 |
| .6.network | 10.253.19.20/30 |
| .6.branch_ip | 10.253.19.21 |
| .6.hub_ip | 10.253.19.22 |
| .7.hub_public_ip | 198.51.100.4 |
| .7.network | 10.253.19.24/30 |
| .7.branch_ip | 10.253.19.25 |
| .7.hub_ip | 10.253.19.26 |
| .8.hub_public_ip | 203.0.113.4 |
| .8.network | 10.253.19.28/30 |
| .8.branch_ip | 10.253.19.29 |
| .8.hub_ip | 10.253.19.30 |
| .9.hub_public_ip | 198.51.100.4 |
| .9.network | 10.253.19.32/30 |
| .9.branch_ip | 10.253.19.33 |
| .9.hub_ip | 10.253.19.34 |
| .10.hub_public_ip | 203.0.113.4 |
| .10.network | 10.253.19.36/30 |
| .10.branch_ip | 10.253.19.37 |
| .10.hub_ip | 10.253.19.38 |
| .11.hub_public_ip | 198.51.100.4 |
| .11.network | 10.253.19.40/30 |
| .11.branch_ip | 10.253.19.41 |
| .11.hub_ip | 10.253.19.42 |
| .12.hub_public_ip | 203.0.113.4 |
| .12.network | 10.253.19.44/30 |
| .12.branch_ip | 10.253.19.45 |
| .12.hub_ip | 10.253.19.46 |
| .13.hub_public_ip | 198.51.100.4 |
| .13.network | 10.253.19.48/30 |
| .13.branch_ip | 10.253.19.49 |
| .13.hub_ip | 10.253.19.50 |
| .14.hub_public_ip | 203.0.113.4 |
| .14.network | 10.253.19.52/30 |
| .14.branch_ip | 10.253.19.53 |
| .14.hub_ip | 10.253.19.54 |
| .15.hub_public_ip | 198.51.100.4 |
| .15.network | 10.253.19.56/30 |
| .15.branch_ip | 10.253.19.57 |
| .15.hub_ip | 10.253.19.58 |
| .16.hub_public_ip | 203.0.113.4 |
| .16.network | 10.253.19.60/30 |
| .16.branch_ip | 10.253.19.61 |
| .16.hub_ip | 10.253.19.62 |

### S20 — Punta Arenas

28 PCs y 28 teléfonos existentes.

| Función | ANTES | DESPUÉS |
| --- | --- | --- |
| Routers | 1 × C1121X-8P | 2 × CCR2004-16G-2S+ |
| Switches | 1 × C9200L-48P-4G-E | CRS328-24P-4S+RM + CRS328-24P-4S+RM |
| Firewall | Sin equipo dedicado | Sin appliance remoto; seguridad central |
| Distribución WAN | MPLS y accesos ISP del escenario base | wanA: E50UG; wanB: E50UG |


| Red | VLAN | Subred | Gateway / roles |
| --- | --- | --- | --- |
| users | 10 | 10.70.20.0/25 | 10.70.20.1 |
| voice | 20 | 10.70.84.0/25 | 10.70.84.1 |
| guests | 40 | 10.70.116.0/26 | 10.70.116.1 |
| wifi_users | 110 | 10.81.20.0/25 | 10.81.20.1 |
| wifi_voice | 120 | 10.82.20.0/25 | 10.82.20.1 |
| management | 130 | 10.80.20.0/27 | 10.80.20.1 |


| Gestión | Dirección |
| --- | --- |
| sw1 | 10.80.20.2 |
| sw2 | 10.80.20.3 |
| r1 | 10.80.20.4 |
| r2 | 10.80.20.5 |
| wanA | 10.80.20.6 |
| wanB | 10.80.20.7 |
| ap1 | 10.80.20.24 |
| ap2 | 10.80.20.25 |


| Origen | Puerto | Destino | Puerto | Función | VLAN/red | Mbps | IP / agregado lógico |
| --- | --- | --- | --- | --- | --- | --- | --- |
| cpe:starlink | LAN | wanA | ether1 | WAN_ACCESS | 201 | 1000 | — |
| cpe:entel5g | LAN | wanA | ether2 | WAN_ACCESS | 203 | 1000 | — |
| r1 | ether1 | wanA | ether3 | WAN_TRUNK | 201, 203 | 1000 | — |
| r2 | ether1 | wanA | ether4 | WAN_TRUNK | 201, 203 | 1000 | — |
| wanA | ether5 | sw1 | ether22 | MANAGEMENT_ACCESS | 130 | 1000 | — |
| cpe:leo | LAN | wanB | ether1 | WAN_ACCESS | 202 | 1000 | — |
| cpe:wom4g | LAN | wanB | ether2 | WAN_ACCESS | 204 | 1000 | — |
| r1 | ether2 | wanB | ether3 | WAN_TRUNK | 202, 204 | 1000 | — |
| r2 | ether2 | wanB | ether4 | WAN_TRUNK | 202, 204 | 1000 | — |
| wanB | ether5 | sw2 | ether22 | MANAGEMENT_ACCESS | 130 | 1000 | — |
| r1 | ether3 | sw1 | ether19 | LAN_ROUTED | 172.31.20.0/30 | 1000 | router_ip: 172.31.20.1; stack_ip: 172.31.20.2 |
| r1 | ether4 | sw2 | ether19 | LAN_ROUTED | 172.31.20.4/30 | 1000 | router_ip: 172.31.20.5; stack_ip: 172.31.20.6 |
| r1 | ether5 | sw1 | ether21 | MANAGEMENT_ACCESS | 130 | 1000 | — |
| r2 | ether3 | sw1 | ether20 | LAN_ROUTED | 172.31.20.8/30 | 1000 | router_ip: 172.31.20.9; stack_ip: 172.31.20.10 |
| r2 | ether4 | sw2 | ether20 | LAN_ROUTED | 172.31.20.12/30 | 1000 | router_ip: 172.31.20.13; stack_ip: 172.31.20.14 |
| r2 | ether5 | sw2 | ether21 | MANAGEMENT_ACCESS | 130 | 1000 | — |
| ap1 | LAN | sw1 | ether24 | AP_TRUNK | 40, 110, 120, 130 | 1000 | — |
| ap2 | LAN | sw2 | ether24 | AP_TRUNK | 40, 110, 120, 130 | 1000 | — |
| sw1 | sfp-sfpplus1 | sw2 | sfp-sfpplus2 | STACK | 10, 20, 40, 110, 120, 130 | 10000 | — |
| sw1 | sfp-sfpplus2 | sw2 | sfp-sfpplus1 | STACK | 10, 20, 40, 110, 120, 130 | 10000 | — |


| Puesto | Switch | Puerto | IP PC | IP teléfono | Reserva Wi-Fi PC | Reserva Wi-Fi voz |
| --- | --- | --- | --- | --- | --- | --- |
| s20-pc01 | 1 | 1 | 10.70.20.10 | 10.70.84.10 | 10.81.20.10 | 10.82.20.10 |
| s20-pc02 | 2 | 1 | 10.70.20.11 | 10.70.84.11 | 10.81.20.11 | 10.82.20.11 |
| s20-pc03 | 1 | 2 | 10.70.20.12 | 10.70.84.12 | 10.81.20.12 | 10.82.20.12 |
| s20-pc04 | 2 | 2 | 10.70.20.13 | 10.70.84.13 | 10.81.20.13 | 10.82.20.13 |
| s20-pc05 | 1 | 3 | 10.70.20.14 | 10.70.84.14 | 10.81.20.14 | 10.82.20.14 |
| s20-pc06 | 2 | 3 | 10.70.20.15 | 10.70.84.15 | 10.81.20.15 | 10.82.20.15 |
| s20-pc07 | 1 | 4 | 10.70.20.16 | 10.70.84.16 | 10.81.20.16 | 10.82.20.16 |
| s20-pc08 | 2 | 4 | 10.70.20.17 | 10.70.84.17 | 10.81.20.17 | 10.82.20.17 |
| s20-pc09 | 1 | 5 | 10.70.20.18 | 10.70.84.18 | 10.81.20.18 | 10.82.20.18 |
| s20-pc10 | 2 | 5 | 10.70.20.19 | 10.70.84.19 | 10.81.20.19 | 10.82.20.19 |
| s20-pc11 | 1 | 6 | 10.70.20.20 | 10.70.84.20 | 10.81.20.20 | 10.82.20.20 |
| s20-pc12 | 2 | 6 | 10.70.20.21 | 10.70.84.21 | 10.81.20.21 | 10.82.20.21 |
| s20-pc13 | 1 | 7 | 10.70.20.22 | 10.70.84.22 | 10.81.20.22 | 10.82.20.22 |
| s20-pc14 | 2 | 7 | 10.70.20.23 | 10.70.84.23 | 10.81.20.23 | 10.82.20.23 |
| s20-pc15 | 1 | 8 | 10.70.20.24 | 10.70.84.24 | 10.81.20.24 | 10.82.20.24 |
| s20-pc16 | 2 | 8 | 10.70.20.25 | 10.70.84.25 | 10.81.20.25 | 10.82.20.25 |
| s20-pc17 | 1 | 9 | 10.70.20.26 | 10.70.84.26 | 10.81.20.26 | 10.82.20.26 |
| s20-pc18 | 2 | 9 | 10.70.20.27 | 10.70.84.27 | 10.81.20.27 | 10.82.20.27 |
| s20-pc19 | 1 | 10 | 10.70.20.28 | 10.70.84.28 | 10.81.20.28 | 10.82.20.28 |
| s20-pc20 | 2 | 10 | 10.70.20.29 | 10.70.84.29 | 10.81.20.29 | 10.82.20.29 |
| s20-pc21 | 1 | 11 | 10.70.20.30 | 10.70.84.30 | 10.81.20.30 | 10.82.20.30 |
| s20-pc22 | 2 | 11 | 10.70.20.31 | 10.70.84.31 | 10.81.20.31 | 10.82.20.31 |
| s20-pc23 | 1 | 12 | 10.70.20.32 | 10.70.84.32 | 10.81.20.32 | 10.82.20.32 |
| s20-pc24 | 2 | 12 | 10.70.20.33 | 10.70.84.33 | 10.81.20.33 | 10.82.20.33 |
| s20-pc25 | 1 | 13 | 10.70.20.34 | 10.70.84.34 | 10.81.20.34 | 10.82.20.34 |
| s20-pc26 | 2 | 13 | 10.70.20.35 | 10.70.84.35 | 10.81.20.35 | 10.82.20.35 |
| s20-pc27 | 1 | 14 | 10.70.20.36 | 10.70.84.36 | 10.81.20.36 | 10.82.20.36 |
| s20-pc28 | 2 | 14 | 10.70.20.37 | 10.70.84.37 | 10.81.20.37 | 10.82.20.37 |


**Transporte starlink — VLAN 201 — wanA.**

| Rol de entrega | Dirección |
| --- | --- |
| network | 10.252.20.0/29 |
| cpe | 10.252.20.1 |
| r1 | 10.252.20.2 |
| r2 | 10.252.20.3 |


**Transporte leo — VLAN 202 — wanB.**

| Rol de entrega | Dirección |
| --- | --- |
| network | 10.252.20.8/29 |
| cpe | 10.252.20.9 |
| r1 | 10.252.20.10 |
| r2 | 10.252.20.11 |


**Transporte entel5g — VLAN 203 — wanA.**

| Rol de entrega | Dirección |
| --- | --- |
| network | 10.252.20.16/29 |
| cpe | 10.252.20.17 |
| r1 | 10.252.20.18 |
| r2 | 10.252.20.19 |


**Transporte wom4g — VLAN 204 — wanB.**

| Rol de entrega | Dirección |
| --- | --- |
| network | 10.252.20.24/29 |
| cpe | 10.252.20.25 |
| r1 | 10.252.20.26 |
| r2 | 10.252.20.27 |


**Reservas de túneles (numeración según lista de la ficha).**

| Rol / candidato | Dirección |
| --- | --- |
| .1.hub_public_ip | 198.51.100.4 |
| .1.network | 10.253.20.0/30 |
| .1.branch_ip | 10.253.20.1 |
| .1.hub_ip | 10.253.20.2 |
| .2.hub_public_ip | 203.0.113.4 |
| .2.network | 10.253.20.4/30 |
| .2.branch_ip | 10.253.20.5 |
| .2.hub_ip | 10.253.20.6 |
| .3.hub_public_ip | 198.51.100.4 |
| .3.network | 10.253.20.8/30 |
| .3.branch_ip | 10.253.20.9 |
| .3.hub_ip | 10.253.20.10 |
| .4.hub_public_ip | 203.0.113.4 |
| .4.network | 10.253.20.12/30 |
| .4.branch_ip | 10.253.20.13 |
| .4.hub_ip | 10.253.20.14 |
| .5.hub_public_ip | 198.51.100.4 |
| .5.network | 10.253.20.16/30 |
| .5.branch_ip | 10.253.20.17 |
| .5.hub_ip | 10.253.20.18 |
| .6.hub_public_ip | 203.0.113.4 |
| .6.network | 10.253.20.20/30 |
| .6.branch_ip | 10.253.20.21 |
| .6.hub_ip | 10.253.20.22 |
| .7.hub_public_ip | 198.51.100.4 |
| .7.network | 10.253.20.24/30 |
| .7.branch_ip | 10.253.20.25 |
| .7.hub_ip | 10.253.20.26 |
| .8.hub_public_ip | 203.0.113.4 |
| .8.network | 10.253.20.28/30 |
| .8.branch_ip | 10.253.20.29 |
| .8.hub_ip | 10.253.20.30 |
| .9.hub_public_ip | 198.51.100.4 |
| .9.network | 10.253.20.32/30 |
| .9.branch_ip | 10.253.20.33 |
| .9.hub_ip | 10.253.20.34 |
| .10.hub_public_ip | 203.0.113.4 |
| .10.network | 10.253.20.36/30 |
| .10.branch_ip | 10.253.20.37 |
| .10.hub_ip | 10.253.20.38 |
| .11.hub_public_ip | 198.51.100.4 |
| .11.network | 10.253.20.40/30 |
| .11.branch_ip | 10.253.20.41 |
| .11.hub_ip | 10.253.20.42 |
| .12.hub_public_ip | 203.0.113.4 |
| .12.network | 10.253.20.44/30 |
| .12.branch_ip | 10.253.20.45 |
| .12.hub_ip | 10.253.20.46 |
| .13.hub_public_ip | 198.51.100.4 |
| .13.network | 10.253.20.48/30 |
| .13.branch_ip | 10.253.20.49 |
| .13.hub_ip | 10.253.20.50 |
| .14.hub_public_ip | 203.0.113.4 |
| .14.network | 10.253.20.52/30 |
| .14.branch_ip | 10.253.20.53 |
| .14.hub_ip | 10.253.20.54 |
| .15.hub_public_ip | 198.51.100.4 |
| .15.network | 10.253.20.56/30 |
| .15.branch_ip | 10.253.20.57 |
| .15.hub_ip | 10.253.20.58 |
| .16.hub_public_ip | 203.0.113.4 |
| .16.network | 10.253.20.60/30 |
| .16.branch_ip | 10.253.20.61 |
| .16.hub_ip | 10.253.20.62 |

### S21 — Hanga Roa (Isla de Pascua)

17 PCs y 17 teléfonos existentes.

| Función | ANTES | DESPUÉS |
| --- | --- | --- |
| Routers | 1 × C1121X-8P | 2 × CCR2004-16G-2S+ |
| Switches | 1 × C9200L-24P-4G-E | CRS328-24P-4S+RM + CRS328-24P-4S+RM |
| Firewall | Sin equipo dedicado | Sin appliance remoto; seguridad central |
| Distribución WAN | MPLS y accesos ISP del escenario base | wanA: E50UG; wanB: E50UG |


| Red | VLAN | Subred | Gateway / roles |
| --- | --- | --- | --- |
| users | 10 | 10.70.21.0/25 | 10.70.21.1 |
| voice | 20 | 10.70.85.0/25 | 10.70.85.1 |
| guests | 40 | 10.70.117.0/26 | 10.70.117.1 |
| wifi_users | 110 | 10.81.21.0/25 | 10.81.21.1 |
| wifi_voice | 120 | 10.82.21.0/25 | 10.82.21.1 |
| management | 130 | 10.80.21.0/27 | 10.80.21.1 |


| Gestión | Dirección |
| --- | --- |
| sw1 | 10.80.21.2 |
| sw2 | 10.80.21.3 |
| r1 | 10.80.21.4 |
| r2 | 10.80.21.5 |
| wanA | 10.80.21.6 |
| wanB | 10.80.21.7 |
| ap1 | 10.80.21.24 |
| ap2 | 10.80.21.25 |


| Origen | Puerto | Destino | Puerto | Función | VLAN/red | Mbps | IP / agregado lógico |
| --- | --- | --- | --- | --- | --- | --- | --- |
| cpe:starlink | LAN | wanA | ether1 | WAN_ACCESS | 201 | 1000 | — |
| cpe:entel5g | LAN | wanA | ether2 | WAN_ACCESS | 203 | 1000 | — |
| r1 | ether1 | wanA | ether3 | WAN_TRUNK | 201, 203 | 1000 | — |
| r2 | ether1 | wanA | ether4 | WAN_TRUNK | 201, 203 | 1000 | — |
| wanA | ether5 | sw1 | ether22 | MANAGEMENT_ACCESS | 130 | 1000 | — |
| cpe:leo | LAN | wanB | ether1 | WAN_ACCESS | 202 | 1000 | — |
| cpe:wom4g | LAN | wanB | ether2 | WAN_ACCESS | 204 | 1000 | — |
| r1 | ether2 | wanB | ether3 | WAN_TRUNK | 202, 204 | 1000 | — |
| r2 | ether2 | wanB | ether4 | WAN_TRUNK | 202, 204 | 1000 | — |
| wanB | ether5 | sw2 | ether22 | MANAGEMENT_ACCESS | 130 | 1000 | — |
| r1 | ether3 | sw1 | ether19 | LAN_ROUTED | 172.31.21.0/30 | 1000 | router_ip: 172.31.21.1; stack_ip: 172.31.21.2 |
| r1 | ether4 | sw2 | ether19 | LAN_ROUTED | 172.31.21.4/30 | 1000 | router_ip: 172.31.21.5; stack_ip: 172.31.21.6 |
| r1 | ether5 | sw1 | ether21 | MANAGEMENT_ACCESS | 130 | 1000 | — |
| r2 | ether3 | sw1 | ether20 | LAN_ROUTED | 172.31.21.8/30 | 1000 | router_ip: 172.31.21.9; stack_ip: 172.31.21.10 |
| r2 | ether4 | sw2 | ether20 | LAN_ROUTED | 172.31.21.12/30 | 1000 | router_ip: 172.31.21.13; stack_ip: 172.31.21.14 |
| r2 | ether5 | sw2 | ether21 | MANAGEMENT_ACCESS | 130 | 1000 | — |
| ap1 | LAN | sw1 | ether24 | AP_TRUNK | 40, 110, 120, 130 | 1000 | — |
| ap2 | LAN | sw2 | ether24 | AP_TRUNK | 40, 110, 120, 130 | 1000 | — |
| sw1 | sfp-sfpplus1 | sw2 | sfp-sfpplus2 | STACK | 10, 20, 40, 110, 120, 130 | 10000 | — |
| sw1 | sfp-sfpplus2 | sw2 | sfp-sfpplus1 | STACK | 10, 20, 40, 110, 120, 130 | 10000 | — |


| Puesto | Switch | Puerto | IP PC | IP teléfono | Reserva Wi-Fi PC | Reserva Wi-Fi voz |
| --- | --- | --- | --- | --- | --- | --- |
| s21-pc01 | 1 | 1 | 10.70.21.10 | 10.70.85.10 | 10.81.21.10 | 10.82.21.10 |
| s21-pc02 | 2 | 1 | 10.70.21.11 | 10.70.85.11 | 10.81.21.11 | 10.82.21.11 |
| s21-pc03 | 1 | 2 | 10.70.21.12 | 10.70.85.12 | 10.81.21.12 | 10.82.21.12 |
| s21-pc04 | 2 | 2 | 10.70.21.13 | 10.70.85.13 | 10.81.21.13 | 10.82.21.13 |
| s21-pc05 | 1 | 3 | 10.70.21.14 | 10.70.85.14 | 10.81.21.14 | 10.82.21.14 |
| s21-pc06 | 2 | 3 | 10.70.21.15 | 10.70.85.15 | 10.81.21.15 | 10.82.21.15 |
| s21-pc07 | 1 | 4 | 10.70.21.16 | 10.70.85.16 | 10.81.21.16 | 10.82.21.16 |
| s21-pc08 | 2 | 4 | 10.70.21.17 | 10.70.85.17 | 10.81.21.17 | 10.82.21.17 |
| s21-pc09 | 1 | 5 | 10.70.21.18 | 10.70.85.18 | 10.81.21.18 | 10.82.21.18 |
| s21-pc10 | 2 | 5 | 10.70.21.19 | 10.70.85.19 | 10.81.21.19 | 10.82.21.19 |
| s21-pc11 | 1 | 6 | 10.70.21.20 | 10.70.85.20 | 10.81.21.20 | 10.82.21.20 |
| s21-pc12 | 2 | 6 | 10.70.21.21 | 10.70.85.21 | 10.81.21.21 | 10.82.21.21 |
| s21-pc13 | 1 | 7 | 10.70.21.22 | 10.70.85.22 | 10.81.21.22 | 10.82.21.22 |
| s21-pc14 | 2 | 7 | 10.70.21.23 | 10.70.85.23 | 10.81.21.23 | 10.82.21.23 |
| s21-pc15 | 1 | 8 | 10.70.21.24 | 10.70.85.24 | 10.81.21.24 | 10.82.21.24 |
| s21-pc16 | 2 | 8 | 10.70.21.25 | 10.70.85.25 | 10.81.21.25 | 10.82.21.25 |
| s21-pc17 | 1 | 9 | 10.70.21.26 | 10.70.85.26 | 10.81.21.26 | 10.82.21.26 |


**Transporte starlink — VLAN 201 — wanA.**

| Rol de entrega | Dirección |
| --- | --- |
| network | 10.252.21.0/29 |
| cpe | 10.252.21.1 |
| r1 | 10.252.21.2 |
| r2 | 10.252.21.3 |


**Transporte leo — VLAN 202 — wanB.**

| Rol de entrega | Dirección |
| --- | --- |
| network | 10.252.21.8/29 |
| cpe | 10.252.21.9 |
| r1 | 10.252.21.10 |
| r2 | 10.252.21.11 |


**Transporte entel5g — VLAN 203 — wanA.**

| Rol de entrega | Dirección |
| --- | --- |
| network | 10.252.21.16/29 |
| cpe | 10.252.21.17 |
| r1 | 10.252.21.18 |
| r2 | 10.252.21.19 |


**Transporte wom4g — VLAN 204 — wanB.**

| Rol de entrega | Dirección |
| --- | --- |
| network | 10.252.21.24/29 |
| cpe | 10.252.21.25 |
| r1 | 10.252.21.26 |
| r2 | 10.252.21.27 |


**Reservas de túneles (numeración según lista de la ficha).**

| Rol / candidato | Dirección |
| --- | --- |
| .1.hub_public_ip | 198.51.100.4 |
| .1.network | 10.253.21.0/30 |
| .1.branch_ip | 10.253.21.1 |
| .1.hub_ip | 10.253.21.2 |
| .2.hub_public_ip | 203.0.113.4 |
| .2.network | 10.253.21.4/30 |
| .2.branch_ip | 10.253.21.5 |
| .2.hub_ip | 10.253.21.6 |
| .3.hub_public_ip | 198.51.100.4 |
| .3.network | 10.253.21.8/30 |
| .3.branch_ip | 10.253.21.9 |
| .3.hub_ip | 10.253.21.10 |
| .4.hub_public_ip | 203.0.113.4 |
| .4.network | 10.253.21.12/30 |
| .4.branch_ip | 10.253.21.13 |
| .4.hub_ip | 10.253.21.14 |
| .5.hub_public_ip | 198.51.100.4 |
| .5.network | 10.253.21.16/30 |
| .5.branch_ip | 10.253.21.17 |
| .5.hub_ip | 10.253.21.18 |
| .6.hub_public_ip | 203.0.113.4 |
| .6.network | 10.253.21.20/30 |
| .6.branch_ip | 10.253.21.21 |
| .6.hub_ip | 10.253.21.22 |
| .7.hub_public_ip | 198.51.100.4 |
| .7.network | 10.253.21.24/30 |
| .7.branch_ip | 10.253.21.25 |
| .7.hub_ip | 10.253.21.26 |
| .8.hub_public_ip | 203.0.113.4 |
| .8.network | 10.253.21.28/30 |
| .8.branch_ip | 10.253.21.29 |
| .8.hub_ip | 10.253.21.30 |
| .9.hub_public_ip | 198.51.100.4 |
| .9.network | 10.253.21.32/30 |
| .9.branch_ip | 10.253.21.33 |
| .9.hub_ip | 10.253.21.34 |
| .10.hub_public_ip | 203.0.113.4 |
| .10.network | 10.253.21.36/30 |
| .10.branch_ip | 10.253.21.37 |
| .10.hub_ip | 10.253.21.38 |
| .11.hub_public_ip | 198.51.100.4 |
| .11.network | 10.253.21.40/30 |
| .11.branch_ip | 10.253.21.41 |
| .11.hub_ip | 10.253.21.42 |
| .12.hub_public_ip | 203.0.113.4 |
| .12.network | 10.253.21.44/30 |
| .12.branch_ip | 10.253.21.45 |
| .12.hub_ip | 10.253.21.46 |
| .13.hub_public_ip | 198.51.100.4 |
| .13.network | 10.253.21.48/30 |
| .13.branch_ip | 10.253.21.49 |
| .13.hub_ip | 10.253.21.50 |
| .14.hub_public_ip | 203.0.113.4 |
| .14.network | 10.253.21.52/30 |
| .14.branch_ip | 10.253.21.53 |
| .14.hub_ip | 10.253.21.54 |
| .15.hub_public_ip | 198.51.100.4 |
| .15.network | 10.253.21.56/30 |
| .15.branch_ip | 10.253.21.57 |
| .15.hub_ip | 10.253.21.58 |
| .16.hub_public_ip | 203.0.113.4 |
| .16.network | 10.253.21.60/30 |
| .16.branch_ip | 10.253.21.61 |
| .16.hub_ip | 10.253.21.62 |

### S22 — Antártica Chilena

8 PCs y 8 teléfonos existentes.

| Función | ANTES | DESPUÉS |
| --- | --- | --- |
| Routers | 1 × C1121X-8P | 2 × RB5009UG+S+IN |
| Switches | 1 × C9200L-24P-4G-E | CRS328-24P-4S+RM + CRS328-24P-4S+RM |
| Firewall | Sin equipo dedicado | Sin appliance remoto; seguridad central |
| Distribución WAN | MPLS y accesos ISP del escenario base | wanA: E50UG; wanB: E50UG |


| Red | VLAN | Subred | Gateway / roles |
| --- | --- | --- | --- |
| users | 10 | 10.70.22.0/25 | 10.70.22.1 |
| voice | 20 | 10.70.86.0/25 | 10.70.86.1 |
| guests | 40 | 10.70.118.0/26 | 10.70.118.1 |
| wifi_users | 110 | 10.81.22.0/25 | 10.81.22.1 |
| wifi_voice | 120 | 10.82.22.0/25 | 10.82.22.1 |
| management | 130 | 10.80.22.0/27 | 10.80.22.1 |


| Gestión | Dirección |
| --- | --- |
| sw1 | 10.80.22.2 |
| sw2 | 10.80.22.3 |
| r1 | 10.80.22.4 |
| r2 | 10.80.22.5 |
| wanA | 10.80.22.6 |
| wanB | 10.80.22.7 |
| ap1 | 10.80.22.24 |
| ap2 | 10.80.22.25 |


| Origen | Puerto | Destino | Puerto | Función | VLAN/red | Mbps | IP / agregado lógico |
| --- | --- | --- | --- | --- | --- | --- | --- |
| cpe:starlink | LAN | wanA | ether1 | WAN_ACCESS | 201 | 1000 | — |
| cpe:entel5g | LAN | wanA | ether2 | WAN_ACCESS | 203 | 1000 | — |
| r1 | ether1 | wanA | ether3 | WAN_TRUNK | 201, 203 | 1000 | — |
| r2 | ether1 | wanA | ether4 | WAN_TRUNK | 201, 203 | 1000 | — |
| wanA | ether5 | sw1 | ether22 | MANAGEMENT_ACCESS | 130 | 1000 | — |
| cpe:leo | LAN | wanB | ether1 | WAN_ACCESS | 202 | 1000 | — |
| cpe:wom4g | LAN | wanB | ether2 | WAN_ACCESS | 204 | 1000 | — |
| r1 | ether2 | wanB | ether3 | WAN_TRUNK | 202, 204 | 1000 | — |
| r2 | ether2 | wanB | ether4 | WAN_TRUNK | 202, 204 | 1000 | — |
| wanB | ether5 | sw2 | ether22 | MANAGEMENT_ACCESS | 130 | 1000 | — |
| r1 | ether3 | sw1 | ether19 | LAN_ROUTED | 172.31.22.0/30 | 1000 | router_ip: 172.31.22.1; stack_ip: 172.31.22.2 |
| r1 | ether4 | sw2 | ether19 | LAN_ROUTED | 172.31.22.4/30 | 1000 | router_ip: 172.31.22.5; stack_ip: 172.31.22.6 |
| r1 | ether5 | sw1 | ether21 | MANAGEMENT_ACCESS | 130 | 1000 | — |
| r2 | ether3 | sw1 | ether20 | LAN_ROUTED | 172.31.22.8/30 | 1000 | router_ip: 172.31.22.9; stack_ip: 172.31.22.10 |
| r2 | ether4 | sw2 | ether20 | LAN_ROUTED | 172.31.22.12/30 | 1000 | router_ip: 172.31.22.13; stack_ip: 172.31.22.14 |
| r2 | ether5 | sw2 | ether21 | MANAGEMENT_ACCESS | 130 | 1000 | — |
| ap1 | LAN | sw1 | ether24 | AP_TRUNK | 40, 110, 120, 130 | 1000 | — |
| ap2 | LAN | sw2 | ether24 | AP_TRUNK | 40, 110, 120, 130 | 1000 | — |
| sw1 | sfp-sfpplus1 | sw2 | sfp-sfpplus2 | STACK | 10, 20, 40, 110, 120, 130 | 10000 | — |
| sw1 | sfp-sfpplus2 | sw2 | sfp-sfpplus1 | STACK | 10, 20, 40, 110, 120, 130 | 10000 | — |


| Puesto | Switch | Puerto | IP PC | IP teléfono | Reserva Wi-Fi PC | Reserva Wi-Fi voz |
| --- | --- | --- | --- | --- | --- | --- |
| s22-pc01 | 1 | 1 | 10.70.22.10 | 10.70.86.10 | 10.81.22.10 | 10.82.22.10 |
| s22-pc02 | 2 | 1 | 10.70.22.11 | 10.70.86.11 | 10.81.22.11 | 10.82.22.11 |
| s22-pc03 | 1 | 2 | 10.70.22.12 | 10.70.86.12 | 10.81.22.12 | 10.82.22.12 |
| s22-pc04 | 2 | 2 | 10.70.22.13 | 10.70.86.13 | 10.81.22.13 | 10.82.22.13 |
| s22-pc05 | 1 | 3 | 10.70.22.14 | 10.70.86.14 | 10.81.22.14 | 10.82.22.14 |
| s22-pc06 | 2 | 3 | 10.70.22.15 | 10.70.86.15 | 10.81.22.15 | 10.82.22.15 |
| s22-pc07 | 1 | 4 | 10.70.22.16 | 10.70.86.16 | 10.81.22.16 | 10.82.22.16 |
| s22-pc08 | 2 | 4 | 10.70.22.17 | 10.70.86.17 | 10.81.22.17 | 10.82.22.17 |


**Transporte starlink — VLAN 201 — wanA.**

| Rol de entrega | Dirección |
| --- | --- |
| network | 10.252.22.0/29 |
| cpe | 10.252.22.1 |
| r1 | 10.252.22.2 |
| r2 | 10.252.22.3 |


**Transporte leo — VLAN 202 — wanB.**

| Rol de entrega | Dirección |
| --- | --- |
| network | 10.252.22.8/29 |
| cpe | 10.252.22.9 |
| r1 | 10.252.22.10 |
| r2 | 10.252.22.11 |


**Transporte entel5g — VLAN 203 — wanA.**

| Rol de entrega | Dirección |
| --- | --- |
| network | 10.252.22.16/29 |
| cpe | 10.252.22.17 |
| r1 | 10.252.22.18 |
| r2 | 10.252.22.19 |


**Transporte wom4g — VLAN 204 — wanB.**

| Rol de entrega | Dirección |
| --- | --- |
| network | 10.252.22.24/29 |
| cpe | 10.252.22.25 |
| r1 | 10.252.22.26 |
| r2 | 10.252.22.27 |


**Reservas de túneles (numeración según lista de la ficha).**

| Rol / candidato | Dirección |
| --- | --- |
| .1.hub_public_ip | 198.51.100.4 |
| .1.network | 10.253.22.0/30 |
| .1.branch_ip | 10.253.22.1 |
| .1.hub_ip | 10.253.22.2 |
| .2.hub_public_ip | 203.0.113.4 |
| .2.network | 10.253.22.4/30 |
| .2.branch_ip | 10.253.22.5 |
| .2.hub_ip | 10.253.22.6 |
| .3.hub_public_ip | 198.51.100.4 |
| .3.network | 10.253.22.8/30 |
| .3.branch_ip | 10.253.22.9 |
| .3.hub_ip | 10.253.22.10 |
| .4.hub_public_ip | 203.0.113.4 |
| .4.network | 10.253.22.12/30 |
| .4.branch_ip | 10.253.22.13 |
| .4.hub_ip | 10.253.22.14 |
| .5.hub_public_ip | 198.51.100.4 |
| .5.network | 10.253.22.16/30 |
| .5.branch_ip | 10.253.22.17 |
| .5.hub_ip | 10.253.22.18 |
| .6.hub_public_ip | 203.0.113.4 |
| .6.network | 10.253.22.20/30 |
| .6.branch_ip | 10.253.22.21 |
| .6.hub_ip | 10.253.22.22 |
| .7.hub_public_ip | 198.51.100.4 |
| .7.network | 10.253.22.24/30 |
| .7.branch_ip | 10.253.22.25 |
| .7.hub_ip | 10.253.22.26 |
| .8.hub_public_ip | 203.0.113.4 |
| .8.network | 10.253.22.28/30 |
| .8.branch_ip | 10.253.22.29 |
| .8.hub_ip | 10.253.22.30 |
| .9.hub_public_ip | 198.51.100.4 |
| .9.network | 10.253.22.32/30 |
| .9.branch_ip | 10.253.22.33 |
| .9.hub_ip | 10.253.22.34 |
| .10.hub_public_ip | 203.0.113.4 |
| .10.network | 10.253.22.36/30 |
| .10.branch_ip | 10.253.22.37 |
| .10.hub_ip | 10.253.22.38 |
| .11.hub_public_ip | 198.51.100.4 |
| .11.network | 10.253.22.40/30 |
| .11.branch_ip | 10.253.22.41 |
| .11.hub_ip | 10.253.22.42 |
| .12.hub_public_ip | 203.0.113.4 |
| .12.network | 10.253.22.44/30 |
| .12.branch_ip | 10.253.22.45 |
| .12.hub_ip | 10.253.22.46 |
| .13.hub_public_ip | 198.51.100.4 |
| .13.network | 10.253.22.48/30 |
| .13.branch_ip | 10.253.22.49 |
| .13.hub_ip | 10.253.22.50 |
| .14.hub_public_ip | 203.0.113.4 |
| .14.network | 10.253.22.52/30 |
| .14.branch_ip | 10.253.22.53 |
| .14.hub_ip | 10.253.22.54 |
| .15.hub_public_ip | 198.51.100.4 |
| .15.network | 10.253.22.56/30 |
| .15.branch_ip | 10.253.22.57 |
| .15.hub_ip | 10.253.22.58 |
| .16.hub_public_ip | 203.0.113.4 |
| .16.network | 10.253.22.60/30 |
| .16.branch_ip | 10.253.22.61 |
| .16.hub_ip | 10.253.22.62 |
